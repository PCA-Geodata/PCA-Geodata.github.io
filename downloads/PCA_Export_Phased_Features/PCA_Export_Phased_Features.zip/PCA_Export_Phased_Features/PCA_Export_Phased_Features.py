# -*- coding: utf-8 -*-
"""
PCA Export Phased Features

Exports the Features_for_PostEx polygon layer into separate ESRI Shapefiles,
grouped by Period/SubPeriod/Phase values.
"""

from __future__ import annotations

import os
import re
import sys
import shutil
import getpass
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from qgis.PyQt.QtCore import QCoreApplication, QSettings, QTranslator,Qt, QUrl
from qgis.PyQt.QtGui import QIcon, QDesktopServices
from qgis.PyQt.QtWidgets import (
    QAction,
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressDialog,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
)

from qgis.core import (
    Qgis,
    QgsFeature,
    QgsFields,
    QgsGeometry,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .PCA_Export_Phased_Features_dialog import PCAExportPhasedFeaturesDialog

from .pca_menu_helper import (
    get_or_create_plugin_submenu,
    remove_plugin_submenu_if_empty,
    remove_empty_duplicate_pca_menus,
)
    

PLUGIN_TITLE = "PCA Export Phased Features"

TARGET_LAYER_NAME = "Features_for_PostEx"

FIELDS_WITH_NUMBERS = ["Period_no", "Period", "SubPer_no", "SubPeriod", "Phase"]
FIELDS_WITHOUT_NUMBERS = ["Period", "SubPeriod", "Phase"]


@dataclass(frozen=True)
class ExportGroup:
    key: Tuple[str, ...]
    display_name: str
    filename_stem: str
    features: List[QgsFeature]


class PCAExportPhasedFeatures:
    """QGIS plugin implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        locale = QSettings().value("locale/userLocale", "en")
        locale = str(locale)[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            "i18n",
            f"PCAExportPhasedFeatures_{locale}.qm",
        )
        
        

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.plugin_menu = None

        self.actions: List[QAction] = []
        self.menu = self.tr("&PCA Export Phased Features")
        self.dlg: Optional[PCAExportPhasedFeaturesDialog] = None

        self.toolbar = iface.mainWindow().findChild(QToolBar, PLUGIN_TITLE)
        if self.toolbar is None:
            self.toolbar = iface.addToolBar(PLUGIN_TITLE)
            self.toolbar.setObjectName(PLUGIN_TITLE)

        self.plugin_version = self._read_plugin_version()

    def tr(self, message: str) -> str:
        return QCoreApplication.translate("PCAExportPhasedFeatures", message)

    def add_action(
        self,
        icon_path: str,
        text: str,
        callback,
        enabled_flag: bool = True,
        add_to_menu: bool = True,
        add_to_toolbar: bool = True,
        status_tip: Optional[str] = None,
        whats_this: Optional[str] = None,
        parent=None,
    ) -> QAction:
        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)
            
        if add_to_menu and self.plugin_menu is not None:
            self.plugin_menu.addAction(action)

        self.actions.append(action)
        return action

    def initGui(self):
        remove_empty_duplicate_pca_menus(self.iface)

        self.plugin_menu = get_or_create_plugin_submenu(
            self.iface,
            "PCA Export Phased Features",
            "PCA_Export_Phased_Features_Menu",
        )
        
        
        self.add_action(
            icon_path = os.path.join(self.plugin_dir, "icons", "pca_logo_icon.png"),
            text=self.tr(f"PCA Export Phased Features - v.{self.plugin_version}"),
            callback=self.noop,
            parent=self.iface.mainWindow(),
            status_tip=self.tr("Export Features_for_PostEx by phase to Shapefiles"),
        )        
        
        self.add_action(
            icon_path = os.path.join(self.plugin_dir, "icons", "PCA_export_phased_features_icon.png"),
            text=self.tr("PCA Export Phased Features"),
            callback=self.run,
            parent=self.iface.mainWindow(),
            status_tip=self.tr("Export Features_for_PostEx by phase to Shapefiles"),
        )

    def unload(self):
        for action in self.actions:

            if self.plugin_menu is not None:
                self.plugin_menu.removeAction(action)

            if self.toolbar is not None:
                self.toolbar.removeAction(action)

        if self.plugin_menu is not None:
            remove_plugin_submenu_if_empty(
                self.iface,
                self.plugin_menu,
            )

            self.plugin_menu = None

        self.actions.clear()


    def _read_plugin_version(self):
        metadata_path = os.path.join(self.plugin_dir, "metadata.txt")

        if not os.path.exists(metadata_path):
            print("metadata.txt not found!")
            return "unknown"

        version = "unknown"

        try:
            with open(metadata_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                        break
        except Exception as e:
            print(f"Could not read metadata.txt: {e}")

        return version
        
    def run(self):
        self.dlg = PCAExportPhasedFeaturesDialog(parent=self.iface.mainWindow())
        self.dlg.set_layer_status(self._layer_status_text())

        if hasattr(self.dlg, "test_button"):
            self.dlg.test_button.clicked.connect(self.preview_export_groups)
 
        if hasattr(self.dlg, "help_button"):
            self.dlg.help_button.clicked.connect(self.open_help)
    
        if self._exec_dialog(self.dlg):
            self.export_phased_features()

    @staticmethod
    def _exec_dialog(dialog) -> bool:
        """Run dialogs safely in both QGIS 3 (Qt5) and QGIS 4 (Qt6)."""

        result = dialog.exec() if hasattr(dialog, "exec") else dialog.exec_()

        accepted = getattr(QDialog, "Accepted", None)

        if accepted is None and hasattr(QDialog, "DialogCode"):
            accepted = QDialog.DialogCode.Accepted

        return result == accepted

    def _layer_status_text(self) -> str:
        layer = self._get_target_layer(show_message=False)
        if layer is None:
            return f"Required layer not found: {TARGET_LAYER_NAME}"
        return f"Ready to export: {TARGET_LAYER_NAME} ({layer.featureCount()} features)"

    def preview_export_groups(self):
        """Run the full pre-export validation and show a dry-run breakdown.

        This does not require an output folder and does not create any files.
        It uses the same grouping logic as the real Shapefile export so users can
        check the proposed layer names and feature counts before exporting.
        """
        if self.dlg is None:
            return

        include_numbers = self.dlg.numbers_checkBox.isChecked()
        grouping_fields = FIELDS_WITH_NUMBERS if include_numbers else FIELDS_WITHOUT_NUMBERS

        layer = self._get_target_layer(show_message=True)
        if layer is None:
            return

        validation_error = self._validate_layer_for_export(layer, grouping_fields)
        if validation_error:
            self._show_warning(validation_error)
            return

        total_source_features = layer.featureCount()
        progress = self._create_progress("Testing Features_for_PostEx export groups...", total_source_features + 1)

        try:
            invalid_report = self._collect_invalid_geometry_report(layer, progress)
            if progress.wasCanceled():
                self._show_info("Test cancelled. No files were created.")
                return

            if invalid_report:
                self._show_invalid_geometry_message(invalid_report, action_label="test/export")
                return

            progress.setLabelText("Building export preview...")
            progress.setValue(0)
            groups = self._build_export_groups(layer, grouping_fields, progress)

            if progress.wasCanceled():
                self._show_info("Test cancelled. No files were created.")
                return

            if not groups:
                self._show_warning("No features were found in Features_for_PostEx.")
                return

            grouped_count = sum(len(group.features) for group in groups)
            if grouped_count != total_source_features:
                self._show_warning(
                    "The grouped feature count does not match the source layer feature count.\n\n"
                    f"Source layer: {total_source_features}\n"
                    f"Grouped for export: {grouped_count}\n\n"
                    "The test has been stopped to avoid possible data loss."
                )
                return

            self._show_preview_dialog(groups, total_source_features)

        except Exception as exc:  # defensive final catch for production stability
            self._show_warning(
                "The export test failed due to an unexpected error.\n\n"
                f"Details: {exc}\n\n"
                "No files have been created."
            )
        finally:
            progress.close()

    def export_phased_features(self):
        if self.dlg is None:
            return

        base_output_directory = self.dlg.output_folder_mQgsFileWidget.filePath().strip()
        include_numbers = self.dlg.numbers_checkBox.isChecked()
        grouping_fields = FIELDS_WITH_NUMBERS if include_numbers else FIELDS_WITHOUT_NUMBERS

        if not base_output_directory:
            self._show_warning("No output folder was selected. Please select an output folder and try again.")
            return

        if not os.path.isdir(base_output_directory):
            self._show_warning("The selected output folder does not exist or is not accessible.")
            return

        layer = self._get_target_layer(show_message=True)
        if layer is None:
            return

        validation_error = self._validate_layer_for_export(layer, grouping_fields)
        if validation_error:
            self._show_warning(validation_error)
            return

        total_source_features = layer.featureCount()
        progress = self._create_progress("Checking Features_for_PostEx before export...", total_source_features + 1)

        output_directory = None
        temp_output_directory = None

        try:
            invalid_report = self._collect_invalid_geometry_report(layer, progress)
            if progress.wasCanceled():
                self._show_info("Export cancelled before any files were created.")
                return

            if invalid_report:
                self._show_invalid_geometry_message(invalid_report)
                return

            groups = self._build_export_groups(layer, grouping_fields, progress)
            if progress.wasCanceled():
                self._show_info("Export cancelled before any files were created.")
                return

            if not groups:
                self._show_warning("No features were found in Features_for_PostEx.")
                return

            grouped_count = sum(len(group.features) for group in groups)
            if grouped_count != total_source_features:
                self._show_warning(
                    "The grouped feature count does not match the source layer feature count.\n\n"
                    f"Source layer: {total_source_features}\n"
                    f"Grouped for export: {grouped_count}\n\n"
                    "The export has been stopped to avoid possible data loss.\n\n"
                    "NO SHAPEFILES HAVE BEEN CREATED."
                )
                return

            output_directory = self._next_output_directory(base_output_directory)
            temp_output_directory = output_directory + "_TEMP"

            if os.path.exists(temp_output_directory):
                shutil.rmtree(temp_output_directory)

            os.makedirs(temp_output_directory, exist_ok=False)

            progress.setLabelText("Exporting Shapefiles...")
            progress.setMaximum(len(groups))
            progress.setValue(0)

            export_report = self._export_groups_to_shapefiles(
                source_layer=layer,
                groups=groups,
                output_directory=temp_output_directory,
                progress=progress,
            )

            if progress.wasCanceled():
                shutil.rmtree(temp_output_directory, ignore_errors=True)
                self._show_info(
                    "Export cancelled.\n\n"
                    "NO SHAPEFILES HAVE BEEN CREATED."
                )
                return

            exported_count = sum(export_report.values())
            if exported_count != total_source_features:
                raise RuntimeError(
                    "The exported feature count does not match the source layer.\n\n"
                    f"Source layer: {total_source_features}\n"
                    f"Exported features: {exported_count}"
                )

            self._write_export_log(
                output_directory=temp_output_directory,
                source_layer=layer,
                total_source_features=total_source_features,
                export_report=export_report,
            )

            os.rename(temp_output_directory, output_directory)
            temp_output_directory = None

            self._open_folder(output_directory)

            self._show_success_message(
                total_source_features,
                export_report,
                output_directory,
            )

        except Exception as exc:
            if temp_output_directory and os.path.exists(temp_output_directory):
                shutil.rmtree(temp_output_directory, ignore_errors=True)

            self._show_warning(
                "EXPORT CANCELLED\n\n"
                f"{exc}\n\n"
                "The export did not complete successfully.\n"
                "Please fix the reported issue in the source layer and run the export again.\n\n"
                "NO SHAPEFILES HAVE BEEN CREATED."
            )

        finally:
            progress.close()

    def _get_target_layer(self, show_message: bool) -> Optional[QgsVectorLayer]:
        layers = [lyr for lyr in QgsProject.instance().mapLayersByName(TARGET_LAYER_NAME) if isinstance(lyr, QgsVectorLayer)]
        if not layers:
            if show_message:
                self._show_warning(
                    f"The required layer '<strong>{TARGET_LAYER_NAME}</strong>' is not present in the project.\n\n"
                    "Please load the layer and try again."
                )
            return None

        if len(layers) > 1 and show_message:
            self._show_warning(
                f"More than one layer named '<strong>{TARGET_LAYER_NAME}</strong>' was found.\n\n"
                "The first matching layer in the project will be used. To avoid mistakes, consider removing or renaming duplicates."
            )

        return layers[0]

    def _validate_layer_for_export(self, layer: QgsVectorLayer, grouping_fields: Sequence[str]) -> Optional[str]:
        if not layer.isValid():
            return "Features_for_PostEx is not a valid vector layer."

        if layer.featureCount() == 0:
            return "Features_for_PostEx does not contain any features to export."

        geometry_type = QgsWkbTypes.geometryType(layer.wkbType())
        if geometry_type != QgsWkbTypes.PolygonGeometry:
            return "Features_for_PostEx must be a polygon layer. The export has been stopped."

        existing_fields = {field.name() for field in layer.fields()}
        missing_fields = [field_name for field_name in grouping_fields if field_name not in existing_fields]
        if missing_fields:
            return (
                "The following required post-excavation fields are missing from Features_for_PostEx:\n\n"
                + "\n".join(f"- {field_name}" for field_name in missing_fields)
                + "\n\nThe export has been stopped."
            )

        return None

    def _collect_invalid_geometry_report(self, layer: QgsVectorLayer, progress: QProgressDialog) -> List[Tuple[int, str]]:
        invalid_features: List[Tuple[int, str]] = []
        progress.setValue(0)

        for index, feature in enumerate(layer.getFeatures(), start=1):
            if progress.wasCanceled():
                break

            geometry = feature.geometry()
            reason = self._geometry_problem(geometry)
            if reason:
                invalid_features.append((feature.id(), reason))

            if index % 25 == 0:
                progress.setValue(index)
                QCoreApplication.processEvents()

        progress.setValue(layer.featureCount())
        return invalid_features

    @staticmethod
    def _geometry_problem(geometry: QgsGeometry) -> Optional[str]:
        if geometry is None or geometry.isNull():
            return "null geometry"
        if geometry.isEmpty():
            return "empty geometry"
        if not geometry.isGeosValid():
            return "invalid geometry"
        return None

    def _build_export_groups(
        self,
        layer: QgsVectorLayer,
        grouping_fields: Sequence[str],
        progress: QProgressDialog,
    ) -> List[ExportGroup]:
        grouped_features: "OrderedDict[Tuple[str, ...], List[QgsFeature]]" = OrderedDict()
        grouped_display_names: Dict[Tuple[str, ...], str] = {}
        grouped_file_stems: Dict[Tuple[str, ...], str] = {}

        for index, feature in enumerate(layer.getFeatures(), start=1):
            if progress.wasCanceled():
                break

            key, display_name = self._group_key_and_display_name(feature, grouping_fields)
            grouped_features.setdefault(key, []).append(QgsFeature(feature))
            grouped_display_names[key] = display_name
            grouped_file_stems[key] = self._safe_filename(display_name)

            if index % 25 == 0:
                progress.setValue(index)
                QCoreApplication.processEvents()

        groups: List[ExportGroup] = []
        used_names = set()
        for key, features in grouped_features.items():
            stem = self._unique_stem(grouped_file_stems[key], used_names)
            groups.append(
                ExportGroup(
                    key=key,
                    display_name=grouped_display_names[key],
                    filename_stem=stem,
                    features=features,
                )
            )

        return groups

    @staticmethod
    def _group_key_and_display_name(feature: QgsFeature, grouping_fields: Sequence[str]) -> Tuple[Tuple[str, ...], str]:
        values = [PCAExportPhasedFeatures._normalise_value(feature[field]) for field in grouping_fields]
        period_value = PCAExportPhasedFeatures._normalise_value(feature["Period"]) if "Period" in feature.fields().names() else ""

        if period_value.casefold() == "undated" or all(not value for value in values):
            return ("Undated",), "Undated"

        cleaned_values = [value for value in values if value]
        if not cleaned_values:
            return ("Undated",), "Undated"

        return tuple(values), "_".join(cleaned_values)

    @staticmethod
    def _normalise_value(value) -> str:
        if value is None:
            return ""

        text = str(value).strip()

        if not text:
            return ""

        if text.upper() in {"NULL", "<NULL>", "NONE"}:
            return ""

        return text

    @staticmethod
    def _safe_filename(value: str, max_length: int = 80) -> str:
        cleaned = value.strip().replace(".", "_")
        cleaned = re.sub(r"[<>:\"/\\|?*]+", "_", cleaned)
        cleaned = re.sub(r"\s+", "_", cleaned)
        cleaned = re.sub(r"_+", "_", cleaned).strip("_ .")
        if not cleaned:
            cleaned = "Undated"
        return cleaned[:max_length].rstrip("_ .")

    @staticmethod
    def _unique_stem(stem: str, used_names: set) -> str:
        candidate = stem
        suffix = 2
        while candidate.casefold() in used_names:
            candidate = f"{stem}_v{suffix}"
            suffix += 1
        used_names.add(candidate.casefold())
        return candidate

    @staticmethod
    def _next_output_directory(base_output_directory: str) -> str:
        date_part = datetime.now().strftime("%y%m%d")
        base_name = f"PostEx_{date_part}"
        candidate = os.path.join(base_output_directory, base_name)

        if not os.path.exists(candidate):
            return candidate

        suffix = 2
        while True:
            candidate = os.path.join(base_output_directory, f"{base_name}_v{suffix}")
            if not os.path.exists(candidate):
                return candidate
            suffix += 1

    def _export_groups_to_shapefiles(
        self,
        source_layer: QgsVectorLayer,
        groups: Sequence[ExportGroup],
        output_directory: str,
        progress: QProgressDialog,
    ) -> "OrderedDict[str, int]":
        report: "OrderedDict[str, int]" = OrderedDict()

        for index, group in enumerate(groups, start=1):
            if progress.wasCanceled():
                break

            progress.setLabelText(f"Exporting {group.display_name}...")
            output_file_path = os.path.join(output_directory, f"{group.filename_stem}.shp")

            memory_layer = self._create_group_memory_layer(source_layer, group)
            self._write_layer_to_shapefile(memory_layer, output_file_path)
            report[group.display_name] = len(group.features)

            progress.setValue(index)
            QCoreApplication.processEvents()

        return report

    @staticmethod
    def _create_group_memory_layer(source_layer: QgsVectorLayer, group: ExportGroup) -> QgsVectorLayer:
        geometry_name = QgsWkbTypes.displayString(source_layer.wkbType())
        uri = f"{geometry_name}?crs={source_layer.crs().authid()}"
        memory_layer = QgsVectorLayer(uri, group.filename_stem, "memory")

        if not memory_layer.isValid():
            raise RuntimeError(
                f"Could not create temporary export layer for:\n{group.display_name}"
            )

        provider = memory_layer.dataProvider()
        provider.addAttributes(source_layer.fields())
        memory_layer.updateFields()

        field_names = [field.name() for field in memory_layer.fields()]

        for row_number, source_feature in enumerate(group.features, start=1):
            new_feature = QgsFeature(memory_layer.fields())
            new_feature.setGeometry(QgsGeometry(source_feature.geometry()))

            cleaned_attributes = []

            for value in source_feature.attributes():
                if value is None:
                    cleaned_attributes.append(None)
                elif str(value).strip().upper() in {"NULL", "<NULL>", "NONE"}:
                    cleaned_attributes.append(None)
                else:
                    cleaned_attributes.append(value)

            new_feature.setAttributes(cleaned_attributes)

            success, added = provider.addFeatures([new_feature])

            if not success or len(added) != 1:
                problem_values = []

                for field_name, value in zip(field_names, cleaned_attributes):
                    if value is None:
                        problem_values.append(f"{field_name}=NULL")
                    elif isinstance(value, (list, tuple, dict, set)):
                        problem_values.append(
                            f"{field_name}={repr(value)} ({type(value).__name__})"
                        )

                provider_errors = []
                if hasattr(provider, "errors"):
                    try:
                        provider_errors = [str(error) for error in provider.errors()]
                    except Exception:
                        provider_errors = []

                raise RuntimeError(
                    f"A geometry problem was found in the source layer.\n\n"
                    f"Export group: {group.display_name}\n"
                    f"Feature ID: {source_feature.id()}\n\n"
                    f"Feature geometry type: "
                    f"{QgsWkbTypes.displayString(source_feature.geometry().wkbType())}\n"
                    f"Expected export geometry type: "
                    f"{geometry_name}\n\n"
                    "This feature cannot be exported safely as a Shapefile.\n\n"
                    "Please fix the geometry in Features_for_PostEx before retrying. "
                    "For example, use Buffer 0, Make Valid, Fix Geometries, "
                    "or recreate the affected feature if needed.\n\n"
                    "The export has been completely cancelled to prevent incomplete outputs."
                )

        memory_layer.updateExtents()

        expected_count = len(group.features)
        actual_count = memory_layer.featureCount()

        if actual_count != expected_count:
            raise RuntimeError(
                f"Incomplete temporary export layer for:\n{group.display_name}\n\n"
                f"Expected features: {expected_count}\n"
                f"Added features: {actual_count}"
            )

        return memory_layer

    @staticmethod
    def _write_layer_to_shapefile(layer: QgsVectorLayer, output_file_path: str) -> None:
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "ESRI Shapefile"
        options.fileEncoding = "UTF-8"
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        transform_context = QgsProject.instance().transformContext()
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            output_file_path,
            transform_context,
            options,
        )

        error_code, error_message = PCAExportPhasedFeatures._writer_result(result)
        if error_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(
                f"Could not write Shapefile:\n{output_file_path}\n\n{error_message or 'Unknown writer error.'}"
            )

    @staticmethod
    def _writer_result(result) -> Tuple[int, str]:
        """Normalise QgsVectorFileWriter result tuples across QGIS versions."""
        if isinstance(result, tuple):
            error_code = result[0]
            error_message = ""
            if len(result) > 1 and result[1]:
                error_message = str(result[1])
            return error_code, error_message
        return result, ""

    def _create_progress(self, text: str, maximum: int) -> QProgressDialog:
        progress = QProgressDialog(text, "Cancel", 0, max(1, maximum), self.iface.mainWindow())
        progress.setWindowTitle(PLUGIN_TITLE)
        window_modal = getattr(Qt, "WindowModal", None) or Qt.WindowModality.WindowModal
        progress.setWindowModality(window_modal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        return progress

    def _show_invalid_geometry_message(
        self,
        invalid_report: Sequence[Tuple[int, str]],
        action_label: str = "export",
    ) -> None:
        preview = "\n".join(f"- Feature ID {fid}: {reason}" for fid, reason in invalid_report[:20])
        extra = "" if len(invalid_report) <= 20 else f"\n...and {len(invalid_report) - 20} more."
        self._show_warning(
            f"The {action_label} has been stopped because invalid geometries were found in Features_for_PostEx.\n\n"
            f"Invalid/null/empty geometries found: {len(invalid_report)}\n\n"
            f"{preview}{extra}\n\n"
            "Please fix these geometries in QGIS and run the tool again. No Shapefiles have been exported."
        )

    def _show_preview_dialog(self, groups: Sequence[ExportGroup], total_source_features: int) -> None:
        dialog = QDialog(self.iface.mainWindow())
        dialog.setWindowTitle(f"{PLUGIN_TITLE} - Test Result")
        dialog.setMinimumSize(680, 380)

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        total_grouped = sum(len(group.features) for group in groups)

        title = QLabel("Export test completed successfully")
        title.setObjectName("preview_title_label")
        title.setWordWrap(True)
        layout.addWidget(title)

        summary = QLabel(
            "No files have been created. The table below shows the Shapefiles that would be generated "
            "and how many features each one would contain.\n\n"
            f"Source layer features: {total_source_features}    |    "
            f"Grouped features: {total_grouped}    |    "
            f"Output Shapefiles: {len(groups)}"
        )
        summary.setObjectName("preview_summary_label")
        summary.setWordWrap(True)
        layout.addWidget(summary)

        table = QTableWidget(dialog)
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(["Proposed Shapefile", "Category", "Features"])
        table.setRowCount(len(groups))
        table.setAlternatingRowColors(True)
        table.setSortingEnabled(False)
        table.verticalHeader().setVisible(False)

        no_edit_triggers = getattr(QTableWidget, "NoEditTriggers", None)
        if no_edit_triggers is None and hasattr(QTableWidget, "EditTrigger"):
            no_edit_triggers = QTableWidget.EditTrigger.NoEditTriggers
        if no_edit_triggers is not None:
            table.setEditTriggers(no_edit_triggers)

        select_rows = getattr(QTableWidget, "SelectRows", None)
        if select_rows is None and hasattr(QTableWidget, "SelectionBehavior"):
            select_rows = QTableWidget.SelectionBehavior.SelectRows
        if select_rows is not None:
            table.setSelectionBehavior(select_rows)

        align_right = getattr(Qt, "AlignRight", None) or Qt.AlignmentFlag.AlignRight
        align_v_center = getattr(Qt, "AlignVCenter", None) or Qt.AlignmentFlag.AlignVCenter

        for row, group in enumerate(groups):
            count_item = QTableWidgetItem(str(len(group.features)))
            count_item.setTextAlignment(align_right | align_v_center)

            table.setItem(row, 0, QTableWidgetItem(f"{group.filename_stem}.shp"))
            table.setItem(row, 1, QTableWidgetItem(group.display_name))
            table.setItem(row, 2, count_item)

        header = table.horizontalHeader()
        stretch_mode = getattr(QHeaderView, "Stretch", None)
        resize_to_contents_mode = getattr(QHeaderView, "ResizeToContents", None)

        if stretch_mode is None and hasattr(QHeaderView, "ResizeMode"):
            stretch_mode = QHeaderView.ResizeMode.Stretch
            resize_to_contents_mode = QHeaderView.ResizeMode.ResizeToContents

        header.setSectionResizeMode(0, stretch_mode)
        header.setSectionResizeMode(1, stretch_mode)
        header.setSectionResizeMode(2, resize_to_contents_mode)

        table.resizeRowsToContents()
        layout.addWidget(table)

        button_box = QDialogButtonBox(dialog)
        reject_role = getattr(QDialogButtonBox, "RejectRole", None)
        if reject_role is None and hasattr(QDialogButtonBox, "ButtonRole"):
            reject_role = QDialogButtonBox.ButtonRole.RejectRole

        close_button = button_box.addButton("Close", reject_role)
        close_button.clicked.connect(dialog.reject)
        layout.addWidget(button_box)

        dialog.setStyleSheet(
            """
            QDialog {
                font-size: 9pt;
            }
            QLabel#preview_title_label {
                font-size: 13pt;
                font-weight: 700;
            }
            QLabel#preview_summary_label {
                padding: 9px 10px;
                border: 1px solid rgba(76, 132, 102, 120);
                border-left: 4px solid rgba(76, 132, 102, 190);
                border-radius: 8px;
                background-color: rgba(76, 132, 102, 32);
            }
            QTableWidget {
                gridline-color: rgba(127, 127, 127, 70);
                border: 1px solid rgba(127, 127, 127, 80);
                border-radius: 8px;
                alternate-background-color: rgba(76, 132, 102, 20);
            }
            QHeaderView::section {
                padding: 6px;
                font-weight: 650;
                border: 0;
                border-bottom: 1px solid rgba(127, 127, 127, 80);
                background-color: rgba(76, 132, 102, 38);
            }
            """
        )

        self._exec_dialog(dialog)

    def _write_export_log(
        self,
        output_directory: str,
        source_layer: QgsVectorLayer,
        total_source_features: int,
        export_report: "OrderedDict[str, int]",
    ) -> None:
        """
        Create a professional export log for QA and traceability.
        """

        project = QgsProject.instance()

        project_path = project.fileName().strip()
        project_name = (
            os.path.basename(project_path)
            if project_path
            else "Unsaved project"
        )

        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            username = getpass.getuser()
        except Exception:
            username = "Unknown user"

        qgis_version = getattr(Qgis, "QGIS_VERSION", "unknown")

        crs = source_layer.crs()
        crs_text = f"{crs.authid()} - {crs.description()}"

        total_exported = sum(export_report.values())

        lines = [
            "=" * 60,
            "PCA EXPORT PHASED FEATURES - EXPORT LOG",
            "=" * 60,
            "",
            "Export date:",
            current_datetime,
            "",
            "Exported by:",
            username,
            "",
            "QGIS project:",
            project_name,
            "",
            "Project path:",
            project_path if project_path else "Project not saved",
            "",
            "QGIS version:",
            qgis_version,
            "",
            "Plugin version:",
            self.plugin_version,
            "",
            "Source layer:",
            source_layer.name(),
            "",
            "Layer CRS:",
            crs_text,
            "",
            "Total source features:",
            str(total_source_features),
            "",
            "Total exported features:",
            str(total_exported),
            "",
            "Output Shapefiles created:",
            str(len(export_report)),
            "",
            "Output folder:",
            output_directory,
            "",
            "-" * 60,
            "EXPORT BREAKDOWN",
            "-" * 60,
            "",
        ]

        for group_name, count in export_report.items():
            lines.extend([
                f"{group_name}.shp",
                f"    Features: {count}",
                "",
            ])

        lines.extend([
            "-" * 60,
            "VALIDATION",
            "-" * 60,
            "",
            "Geometry validation:",
            "PASSED",
            "",
            "Feature count validation:",
            "PASSED",
            "",
            "Export status:",
            "SUCCESS",
            "",
            "=" * 60,
            "End of log",
            "=" * 60,
        ])

        log_path = os.path.join(output_directory, "export_log.txt")

        with open(log_path, "w", encoding="utf-8") as log_file:
            log_file.write("\n".join(lines))


    def _show_success_message(
        self,
        total_source_features: int,
        export_report: "OrderedDict[str, int]",
        output_directory: str,
    ) -> None:
        lines = [
            "Export completed successfully.",
            "",
            f"Source layer features: {total_source_features}",
            f"Exported features: {sum(export_report.values())}",
            "",
            "Breakdown:",
        ]
        for group_name, count in export_report.items():
            lines.append(f"- {group_name}: {count}")
        lines.extend(["", f"Output folder:\n{output_directory}"])

        QMessageBox.information(self.iface.mainWindow(), PLUGIN_TITLE, "\n".join(lines))

    def _show_warning(self, message: str) -> None:
        QMessageBox.warning(self.iface.mainWindow(), PLUGIN_TITLE, message)

    def _show_info(self, message: str) -> None:
        QMessageBox.information(self.iface.mainWindow(), PLUGIN_TITLE, message)

    @staticmethod
    def _open_folder(path: str) -> None:
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                os.system(f'open "{path}"')
            else:
                os.system(f'xdg-open "{path}"')
        except Exception:
            # Folder opening is a convenience only. Export success should not fail because of this.
            pass

    def open_help(self):
        """Open local help page in the default browser."""
        help_path = os.path.join(self.plugin_dir, "help", "index.html")

        if os.path.exists(help_path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(help_path))
            return

        QMessageBox.information(
            self.iface.mainWindow(),
            self.tr("PCA Export Phased Features"),
            self.tr("Help file not found:\n{}").format(help_path),
        )
                
    def noop(self):
        pass
        
    