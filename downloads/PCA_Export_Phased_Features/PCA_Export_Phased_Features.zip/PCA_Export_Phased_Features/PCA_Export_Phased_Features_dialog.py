# -*- coding: utf-8 -*-
"""Dialog for PCA Export Phased Features."""

import os

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import Qt

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "PCA_Export_Phased_Features_dialog_base.ui")
)


class PCAExportPhasedFeaturesDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self._configure_dialog()
        self._apply_style()

    @staticmethod
    def _button_role(name: str):
        button_box = QtWidgets.QDialogButtonBox
        if hasattr(button_box, "ButtonRole"):
            return getattr(button_box.ButtonRole, name)
        return getattr(button_box, name)

    @staticmethod
    def _standard_button(name: str):
        button_box = QtWidgets.QDialogButtonBox
        if hasattr(button_box, "StandardButton"):
            return getattr(button_box.StandardButton, name)
        return getattr(button_box, name)

    def _configure_dialog(self):
        self.setWindowTitle("PCA Export Phased Features")
        self.setMinimumWidth(640)
        self.resize(700, 320)

        if hasattr(self, "description_label"):
            self.description_label.setWordWrap(True)

        if hasattr(self, "output_folder_mQgsFileWidget"):
            self.output_folder_mQgsFileWidget.setDialogTitle("Select export output folder")

        if hasattr(self, "labels_checkBox"):
            self.labels_checkBox.setChecked(True)
            self.labels_checkBox.setToolTip(
                "Export a matching point Shapefile for each polygon Shapefile, using one internal point per exported feature. The label Shapefile uses the same output name with the suffix _labels."
            )

        if hasattr(self, "button_box"):
            self.help_button = self.button_box.addButton(
                "Help",
                self._button_role("HelpRole"),
            )
            self.help_button.setToolTip(
                "Open the local help page for this tool."
            )

            self.test_button = self.button_box.addButton(
                "Test export",
                self._button_role("ActionRole"),
            )
            self.test_button.setToolTip(
                "Preview the proposed Shapefiles and feature counts without creating any files."
            )

            ok_button = self.button_box.button(self._standard_button("Ok"))
            if ok_button is not None:
                ok_button.setText("Export")

    def set_layer_status(self, text: str):
        if hasattr(self, "layer_status_label"):
            self.layer_status_label.setText(text)

    def _apply_style(self):
        """
        Subtle QGIS-friendly styling.
        Avoids hard-coded global text/background colours so it remains readable
        in both light and dark themes.
        """
        self.setStyleSheet(
            """
            QDialog {
                font-size: 9pt;
            }
            QLabel#title_label {
                font-size: 13pt;
                font-weight: 750;
                padding-bottom: 2px;
            }
            QLabel#description_label {
                padding: 3px 0 7px 0;
            }
            QLabel#layer_status_label {
                padding: 7px 9px;
                border: 1px solid rgba(76, 132, 102, 120);
                border-left: 4px solid rgba(76, 132, 102, 190);
                border-radius: 8px;
                background-color: rgba(76, 132, 102, 32);
            }
            QGroupBox {
                font-weight: 650;
                border: 1px solid rgba(71, 119, 156, 105);
                border-radius: 9px;
                margin-top: 9px;
                padding: 9px;
                background-color: rgba(71, 119, 156, 18);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QCheckBox {
                spacing: 8px;
            }
            QDialogButtonBox QPushButton {
                min-width: 90px;
                padding: 6px 13px;
                border-radius: 7px;
                border: 1px solid rgba(76, 132, 102, 125);
                background-color: rgba(76, 132, 102, 34);
            }
            QDialogButtonBox QPushButton:hover {
                background-color: rgba(76, 132, 102, 58);
                border: 1px solid rgba(76, 132, 102, 175);
            }
            QDialogButtonBox QPushButton:pressed {
                background-color: rgba(76, 132, 102, 82);
            }
            """
        )
