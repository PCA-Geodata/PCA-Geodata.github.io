# -*- coding: utf-8 -*-
"""PCA Fieldwalk Grid Generator plugin."""


def classFactory(iface):  # pylint: disable=invalid-name
    from .pca_fieldwalk_grid_generator import PCAFieldwalkGridGenerator
    return PCAFieldwalkGridGenerator(iface)
