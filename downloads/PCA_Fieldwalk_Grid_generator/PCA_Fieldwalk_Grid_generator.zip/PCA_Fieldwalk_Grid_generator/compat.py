# -*- coding: utf-8 -*-
"""Compatibility helpers for QGIS 3 / QGIS 4 and Qt5 / Qt6."""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QDialog


def dialog_exec(dialog):
    """Execute a dialog safely in Qt5 and Qt6."""
    if hasattr(dialog, "exec"):
        return dialog.exec()

    return dialog.exec_()


def accepted_result():
    """Return QDialog Accepted value safely."""
    try:
        return QDialog.DialogCode.Accepted
    except AttributeError:
        return QDialog.Accepted


def align_left():
    """Return AlignLeft safely in Qt5 and Qt6."""
    if hasattr(Qt, "AlignmentFlag"):
        return Qt.AlignmentFlag.AlignLeft

    return Qt.AlignLeft


def align_vcenter():
    """Return AlignVCenter safely in Qt5 and Qt6."""
    if hasattr(Qt, "AlignmentFlag"):
        return Qt.AlignmentFlag.AlignVCenter

    return Qt.AlignVCenter


def qt_alignment(*flags):
    """Combine Qt alignment flags safely."""
    result = flags[0]

    for flag in flags[1:]:
        result = result | flag

    return result