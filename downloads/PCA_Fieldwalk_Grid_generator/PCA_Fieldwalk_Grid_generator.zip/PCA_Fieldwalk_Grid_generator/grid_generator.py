# -*- coding: utf-8 -*-
"""Grid generation logic for PCA Fieldwalk Grid Generator."""


import os
import math
import warnings

from qgis.PyQt.QtCore import QVariant

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)


class FieldwalkGridError(Exception):
    """Controlled error for user-facing grid generation messages."""


class FieldwalkGridGenerator:
    """Generate PCA fieldwalking grids and save them to the project GeoPackage."""

    TARGET_CRS = QgsCoordinateReferenceSystem("EPSG:27700")

    HECTARE_SIZE = 100
    TEN_METRE_SIZE = 10

    HECTARE_LAYER_NAME = "Grid_Hectares"
    TEN_METRE_LAYER_NAME = "Grid_10m"

    H_FIELD = "H_label"
    E_FIELD = "E_label"
    N_FIELD = "N_label"
    FINAL_LABEL_FIELD = "label"

    H_PREFIX = "H"

    GPKG_FOLDER_NAME = "Geopackages"
    GPKG_NAME = "PCA_site_plan_geodatabase.gpkg"

    HECTARE_STYLE = "Hectars_Grid_style.qml"
    TEN_METRE_STYLE = "10m_Grid_style.qml"

    def __init__(self, plugin_dir):
        self.plugin_dir = plugin_dir
        self.project = QgsProject.instance()

    def run(self, boundary_layer, remove_outside_10m=True):
        """Create the hectare and 10 m grids and save them to the project GeoPackage."""
        if boundary_layer is None:
            raise FieldwalkGridError("No boundary layer selected.")

        if boundary_layer.geometryType() != QgsWkbTypes.PolygonGeometry:
            raise FieldwalkGridError("The selected boundary layer must be a polygon layer.")

        gpkg_path = self._get_project_geopackage_path()

        if not os.path.exists(gpkg_path):
            raise FieldwalkGridError(
                "The project GeoPackage was not found.\n\n"
                f"Expected location:\n{gpkg_path}\n\n"
                "Please check that the project has a 'Geopackages' folder containing "
                "'PCA_site_plan_geodatabase.gpkg'."
            )

        site_geom = self._get_boundary_geometry(boundary_layer)

        hectare_layer, ten_metre_layer = self._create_memory_layers()

        hectare_features, ten_metre_features = self._generate_features(
            site_geom=site_geom,
            hectare_fields=hectare_layer.fields(),
            ten_metre_fields=ten_metre_layer.fields(),
            remove_outside_10m=remove_outside_10m,
        )

        if not hectare_features:
            raise FieldwalkGridError("No hectare grid squares were created.")

        if not ten_metre_features:
            raise FieldwalkGridError("No 10 m grid squares were created.")

        hectare_layer.dataProvider().addFeatures(hectare_features)
        hectare_layer.updateExtents()

        ten_metre_layer.dataProvider().addFeatures(ten_metre_features)
        ten_metre_layer.updateExtents()

        self._remove_existing_output_layers_from_project()

        self._write_layer_to_geopackage(
            layer=hectare_layer,
            gpkg_path=gpkg_path,
            layer_name=self.HECTARE_LAYER_NAME,
        )

        self._write_layer_to_geopackage(
            layer=ten_metre_layer,
            gpkg_path=gpkg_path,
            layer_name=self.TEN_METRE_LAYER_NAME,
        )

        self._refresh_loaded_gpkg_layers(gpkg_path)

        loaded_hectare_layer = self._load_geopackage_layer(
            gpkg_path=gpkg_path,
            layer_name=self.HECTARE_LAYER_NAME,
        )

        loaded_ten_metre_layer = self._load_geopackage_layer(
            gpkg_path=gpkg_path,
            layer_name=self.TEN_METRE_LAYER_NAME,
        )

        self._apply_and_save_style(
            layer=loaded_hectare_layer,
            style_filename=self.HECTARE_STYLE,
            style_name="Hectare Grid Style",
        )

        self._apply_and_save_style(
            layer=loaded_ten_metre_layer,
            style_filename=self.TEN_METRE_STYLE,
            style_name="10 m Grid Style",
        )

        self._insert_layer_above_reference(
            loaded_ten_metre_layer,
            boundary_layer,
        )

        self._insert_layer_above_reference(
            loaded_hectare_layer,
            boundary_layer,
        )

        return len(hectare_features), len(ten_metre_features), gpkg_path

    def _get_project_geopackage_path(self):
        project_home = self.project.homePath()

        if not project_home:
            raise FieldwalkGridError(
                "The QGIS project home path is not available.\n\n"
                "Please save the QGIS project before generating the grid."
            )

        return os.path.join(
            project_home,
            self.GPKG_FOLDER_NAME,
            self.GPKG_NAME,
        )

    def _get_boundary_geometry(self, boundary_layer):
        transform = None

        if boundary_layer.crs() != self.TARGET_CRS:
            transform = QgsCoordinateTransform(
                boundary_layer.crs(),
                self.TARGET_CRS,
                self.project,
            )

        boundary_geometries = []

        for feature in boundary_layer.getFeatures():
            geometry = feature.geometry()

            if not geometry or geometry.isEmpty():
                continue

            geometry = QgsGeometry(geometry)

            if transform is not None:
                geometry.transform(transform)

            if not geometry.isGeosValid():
                geometry = geometry.makeValid()

            if geometry and not geometry.isEmpty():
                boundary_geometries.append(geometry)

        if not boundary_geometries:
            raise FieldwalkGridError(
                "No valid polygon geometry was found in the selected boundary layer."
            )

        site_geom = QgsGeometry.unaryUnion(boundary_geometries)

        if not site_geom or site_geom.isEmpty():
            raise FieldwalkGridError(
                "Could not create a valid combined boundary geometry."
            )

        return site_geom

    def _create_memory_layers(self):
        hectare_layer = QgsVectorLayer(
            f"Polygon?crs={self.TARGET_CRS.authid()}",
            self.HECTARE_LAYER_NAME,
            "memory",
        )

        hectare_provider = hectare_layer.dataProvider()
        hectare_provider.addAttributes(
            [
                self._qgs_field(self.H_FIELD, "string", 50),
                self._qgs_field("row_no", "int"),
                self._qgs_field("col_no", "int"),
            ]
        )
        hectare_layer.updateFields()

        ten_metre_layer = QgsVectorLayer(
            f"Polygon?crs={self.TARGET_CRS.authid()}",
            self.TEN_METRE_LAYER_NAME,
            "memory",
        )

        ten_metre_provider = ten_metre_layer.dataProvider()
        ten_metre_provider.addAttributes(
            [
                self._qgs_field(self.H_FIELD, "string", 50),
                self._qgs_field(self.E_FIELD, "int"),
                self._qgs_field(self.N_FIELD, "int"),
                self._qgs_field(self.FINAL_LABEL_FIELD, "string", 80),
            ]
        )
        ten_metre_layer.updateFields()

        return hectare_layer, ten_metre_layer

    def _generate_features(
        self,
        site_geom,
        hectare_fields,
        ten_metre_fields,
        remove_outside_10m=True,
    ):
        extent = site_geom.boundingBox()

        start_x = math.floor(extent.xMinimum() / self.HECTARE_SIZE) * self.HECTARE_SIZE
        start_y = math.floor(extent.yMinimum() / self.HECTARE_SIZE) * self.HECTARE_SIZE

        end_x = math.ceil(extent.xMaximum() / self.HECTARE_SIZE) * self.HECTARE_SIZE
        end_y = math.ceil(extent.yMaximum() / self.HECTARE_SIZE) * self.HECTARE_SIZE

        hectare_features = []
        ten_metre_features = []

        hectare_counter = 1
        row_no = 1

        y = start_y

        while y < end_y:
            x = start_x
            col_no = 1

            while x < end_x:
                hectare_rectangle = QgsRectangle(
                    x,
                    y,
                    x + self.HECTARE_SIZE,
                    y + self.HECTARE_SIZE,
                )

                hectare_geometry = QgsGeometry.fromRect(hectare_rectangle)

                if hectare_geometry.intersects(site_geom):
                    hectare_label = f"{self.H_PREFIX}{hectare_counter}"

                    hectare_feature = QgsFeature(hectare_fields)
                    hectare_feature.setGeometry(hectare_geometry)
                    hectare_feature[self.H_FIELD] = hectare_label
                    hectare_feature["row_no"] = row_no
                    hectare_feature["col_no"] = col_no

                    hectare_features.append(hectare_feature)

                    self._create_10m_features_for_hectare(
                        ten_metre_features=ten_metre_features,
                        ten_metre_fields=ten_metre_fields,
                        site_geom=site_geom,
                        hectare_x=x,
                        hectare_y=y,
                        hectare_label=hectare_label,
                        remove_outside_10m=remove_outside_10m,
                    )

                    hectare_counter += 1

                x += self.HECTARE_SIZE
                col_no += 1

            y += self.HECTARE_SIZE
            row_no += 1

        return hectare_features, ten_metre_features

    def _create_10m_features_for_hectare(
        self,
        ten_metre_features,
        ten_metre_fields,
        site_geom,
        hectare_x,
        hectare_y,
        hectare_label,
        remove_outside_10m=True,
    ):
        for north_row in range(1, 11):
            north_label = north_row * 10

            for east_label in range(1, 11):
                x_min = hectare_x + ((east_label - 1) * self.TEN_METRE_SIZE)
                y_min = hectare_y + ((north_row - 1) * self.TEN_METRE_SIZE)

                ten_metre_rectangle = QgsRectangle(
                    x_min,
                    y_min,
                    x_min + self.TEN_METRE_SIZE,
                    y_min + self.TEN_METRE_SIZE,
                )

                ten_metre_geometry = QgsGeometry.fromRect(ten_metre_rectangle)

                if remove_outside_10m and not ten_metre_geometry.intersects(site_geom):
                    continue

                ten_metre_feature = QgsFeature(ten_metre_fields)
                ten_metre_feature.setGeometry(ten_metre_geometry)

                ten_metre_feature[self.H_FIELD] = hectare_label
                ten_metre_feature[self.E_FIELD] = east_label
                ten_metre_feature[self.N_FIELD] = north_label
                ten_metre_feature[self.FINAL_LABEL_FIELD] = (
                    f"{hectare_label}-{east_label}-{north_label}"
                )

                ten_metre_features.append(ten_metre_feature)

    def _write_layer_to_geopackage(self, layer, gpkg_path, layer_name):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        options.fileEncoding = "UTF-8"
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

        # Important for rendering performance
        options.layerOptions = [
            "SPATIAL_INDEX=YES",
        ]

        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            gpkg_path,
            self.project.transformContext(),
            options,
        )

        error_code = result[0]
        error_message = result[1] if len(result) > 1 else ""

        if error_code != QgsVectorFileWriter.NoError:
            raise FieldwalkGridError(
                f"Could not write layer '{layer_name}' to the GeoPackage.\n\n"
                f"{error_message}"
            )

    def _load_geopackage_layer(self, gpkg_path, layer_name):
        uri = f"{gpkg_path}|layername={layer_name}"

        layer = QgsVectorLayer(
            uri,
            layer_name,
            "ogr",
        )

        if not layer.isValid():
            raise FieldwalkGridError(
                f"The layer '{layer_name}' was written to the GeoPackage, "
                "but QGIS could not reload it."
            )

        try:
            layer.dataProvider().createSpatialIndex()
        except Exception:
            pass

        return layer

    def _apply_and_save_style(self, layer, style_filename, style_name):
        style_path = os.path.join(
            self.plugin_dir,
            "resources",
            "styles",
            style_filename,
        )

        if not os.path.exists(style_path):
            raise FieldwalkGridError(
                f"The style file was not found:\n\n{style_path}"
            )

        error_message, success = layer.loadNamedStyle(style_path)

        if not success:
            raise FieldwalkGridError(
                f"Could not apply style '{style_filename}'.\n\n"
                f"{error_message}"
            )

        layer.triggerRepaint()

        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                category=DeprecationWarning,
                message=".*saveStyleToDatabase.*",
            )

            save_result = layer.saveStyleToDatabase(
                style_name,
                "Embedded style automatically saved by PCA Fieldwalk Grid Generator.",
                True,
                "",
            )

        if isinstance(save_result, tuple):
            success = save_result[0]
            message = save_result[1] if len(save_result) > 1 else ""

            if not success:
                raise FieldwalkGridError(
                    f"Style was applied but could not be saved into the GeoPackage.\n\n"
                    f"{message}"
                )
                
                
    def _qgs_field(self, name, field_type, length=0, precision=0):
        """
        Create QgsField safely across QGIS 3.28, 3.44 and QGIS 4.

        QGIS 3.38+ prefers QMetaType.Type.
        QGIS 3.28 still works safely with QVariant.
        """

        field_type = field_type.lower().strip()

        try:
            from qgis.PyQt.QtCore import QMetaType

            if field_type == "int":
                return QgsField(name, QMetaType.Type.Int)

            if field_type == "double":
                return QgsField(
                    name,
                    QMetaType.Type.Double,
                    len=length,
                    prec=precision,
                )

            if field_type == "string":
                return QgsField(
                    name,
                    QMetaType.Type.QString,
                    len=length,
                )

        except (ImportError, AttributeError, TypeError):
            pass

        if field_type == "int":
            return QgsField(name, QVariant.Int)

        if field_type == "double":
            return QgsField(
                name,
                QVariant.Double,
                len=length,
                prec=precision,
            )

        if field_type == "string":
            return QgsField(
                name,
                QVariant.String,
                len=length,
            )

        raise ValueError(f"Unsupported field type: {field_type}")

    def _remove_existing_output_layers_from_project(self):
        """Remove existing generated grid layers before overwriting them in the GeoPackage."""
        output_layer_names = {
            self.HECTARE_LAYER_NAME,
            self.TEN_METRE_LAYER_NAME,
        }

        layer_ids_to_remove = []

        for layer in self.project.mapLayers().values():
            if layer.name() in output_layer_names:
                layer_ids_to_remove.append(layer.id())

        if layer_ids_to_remove:
            self.project.removeMapLayers(layer_ids_to_remove)
            
    def _refresh_loaded_gpkg_layers(self, gpkg_path):
        """Refresh layers already loaded from the same GeoPackage."""
        gpkg_path_normalised = os.path.normcase(os.path.abspath(gpkg_path))

        for layer in self.project.mapLayers().values():
            provider = layer.dataProvider()

            if provider is None:
                continue

            source_uri = provider.dataSourceUri()
            source_path = source_uri.split("|")[0]
            source_path_normalised = os.path.normcase(os.path.abspath(source_path))

            if source_path_normalised != gpkg_path_normalised:
                continue

            if hasattr(layer, "reload"):
                layer.reload()
            else:
                with warnings.catch_warnings():
                    warnings.filterwarnings(
                        "ignore",
                        category=DeprecationWarning,
                        message=".*forceReload.*",
                    )

                    if hasattr(provider, "forceReload"):
                        provider.forceReload()

            layer.triggerRepaint()
            
    def _insert_layer_above_reference(
        self,
        layer,
        reference_layer,
    ):
        """
        Insert a layer directly above the reference layer
        inside the same layer tree group.
        """

        root = self.project.layerTreeRoot()

        reference_node = root.findLayer(reference_layer.id())

        if reference_node is None:
            self.project.addMapLayer(layer)
            return

        parent_group = reference_node.parent()

        if parent_group is None:
            self.project.addMapLayer(layer)
            return

        # Add layer without automatic insertion
        self.project.addMapLayer(layer, False)

        reference_index = parent_group.children().index(reference_node)

        parent_group.insertLayer(reference_index, layer)