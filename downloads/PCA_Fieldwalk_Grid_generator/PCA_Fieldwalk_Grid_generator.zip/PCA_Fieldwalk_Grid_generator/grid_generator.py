# -*- coding: utf-8 -*-
"""Grid generation logic for PCA Fieldwalk Grid Generator."""


import os
import math
import warnings

from qgis.PyQt.QtCore import QVariant

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)


class FieldwalkGridError(Exception):
    """Controlled error for user-facing grid generation messages."""


class FieldwalkGridGenerator:
    """Generate PCA fieldwalking grids and save them to the project GeoPackage."""

    TARGET_CRS = QgsCoordinateReferenceSystem("EPSG:27700")

    HECTARE_SIZE = 100
    DEFAULT_CELL_WIDTH = 10
    DEFAULT_CELL_HEIGHT = 10

    HECTARE_LAYER_NAME = "Grid_Hectares"
    COLLECTION_LAYER_NAME_TEMPLATE = "Grid_{width}x{height}m"

    H_FIELD = "H_label"
    E_FIELD = "E_label"
    N_FIELD = "N_label"
    FINAL_LABEL_FIELD = "label"

    H_PREFIX = "H"

    GPKG_FOLDER_NAME = "Geopackages"
    SITE_PLAN_GPKG_NAME = "PCA_site_plan_geodatabase.gpkg"
    FW_RESOURCES_GPKG_NAME = "PCA_FW_resources_geodatabase.gpkg"

    HECTARE_STYLE = "Hectars_Grid_style.qml"
    TEN_METRE_STYLE = "10m_Grid_style.qml"

    def __init__(self, plugin_dir):
        self.plugin_dir = plugin_dir
        self.project = QgsProject.instance()

    def run(
        self,
        boundary_layer,
        remove_outside_10m=True,
        cell_width=DEFAULT_CELL_WIDTH,
        cell_height=DEFAULT_CELL_HEIGHT,
    ):
        """Create the hectare and collection-cell grids and save them to the project GeoPackage."""
        if boundary_layer is None:
            raise FieldwalkGridError("No boundary layer selected.")

        if boundary_layer.geometryType() != QgsWkbTypes.PolygonGeometry:
            raise FieldwalkGridError("The selected boundary layer must be a polygon layer.")

        self._validate_cell_dimensions(cell_width, cell_height)

        gpkg_path = self._get_or_create_project_geopackage_path()
        collection_layer_name = self._collection_layer_name(cell_width, cell_height)

        site_geom = self._get_boundary_geometry(boundary_layer)

        hectare_layer, ten_metre_layer = self._create_memory_layers(collection_layer_name)

        hectare_features, ten_metre_features = self._generate_features(
            site_geom=site_geom,
            hectare_fields=hectare_layer.fields(),
            ten_metre_fields=ten_metre_layer.fields(),
            remove_outside_10m=remove_outside_10m,
            cell_width=cell_width,
            cell_height=cell_height,
        )

        if not hectare_features:
            raise FieldwalkGridError("No hectare grid squares were created.")

        if not ten_metre_features:
            raise FieldwalkGridError("No collection grid cells were created.")

        hectare_layer.dataProvider().addFeatures(hectare_features)
        hectare_layer.updateExtents()

        ten_metre_layer.dataProvider().addFeatures(ten_metre_features)
        ten_metre_layer.updateExtents()

        self._remove_existing_output_layers_from_project(collection_layer_name)

        self._write_layer_to_geopackage(
            layer=hectare_layer,
            gpkg_path=gpkg_path,
            layer_name=self.HECTARE_LAYER_NAME,
        )

        self._write_layer_to_geopackage(
            layer=ten_metre_layer,
            gpkg_path=gpkg_path,
            layer_name=collection_layer_name,
        )

        self._refresh_loaded_gpkg_layers(gpkg_path)

        loaded_hectare_layer = self._load_geopackage_layer(
            gpkg_path=gpkg_path,
            layer_name=self.HECTARE_LAYER_NAME,
        )

        loaded_ten_metre_layer = self._load_geopackage_layer(
            gpkg_path=gpkg_path,
            layer_name=collection_layer_name,
        )

        self._apply_and_save_style(
            layer=loaded_hectare_layer,
            style_filename=self.HECTARE_STYLE,
            style_name="Hectare Grid Style",
        )

        self._apply_and_save_style(
            layer=loaded_ten_metre_layer,
            style_filename=self.TEN_METRE_STYLE,
            style_name=f"{cell_width} x {cell_height} m Grid Style",
        )

        self._insert_layer_above_reference(
            loaded_ten_metre_layer,
            boundary_layer,
        )

        self._insert_layer_above_reference(
            loaded_hectare_layer,
            boundary_layer,
        )

        return len(hectare_features), len(ten_metre_features), gpkg_path, collection_layer_name

    def _validate_cell_dimensions(self, cell_width, cell_height):
        """Validate collection grid cell dimensions against the 100 m hectare grid."""
        try:
            cell_width = int(cell_width)
            cell_height = int(cell_height)
        except (TypeError, ValueError):
            raise FieldwalkGridError("Cell width and height must be whole numbers in metres.")

        if cell_width <= 0 or cell_height <= 0:
            raise FieldwalkGridError("Cell width and height must be greater than 0 m.")

        if cell_width > self.HECTARE_SIZE or cell_height > self.HECTARE_SIZE:
            raise FieldwalkGridError("Cell width and height cannot be greater than 100 m.")

        if self.HECTARE_SIZE % cell_width != 0 or self.HECTARE_SIZE % cell_height != 0:
            raise FieldwalkGridError(
                "Cell width and height must divide exactly into the 100 m hectare grid.\n\n"
                "Valid examples include 5 x 5, 10 x 5, 10 x 10, 10 x 20, "
                "20 x 10, 25 x 25 and 50 x 20."
            )

    def _get_or_create_project_geopackage_path(self):
        """Return the correct project GeoPackage path for fieldwalking grid output.

        If the standard PCA site-plan GeoPackage already exists, the grid is
        written there. If it does not exist, the plugin writes to a dedicated
        fieldwalking resources GeoPackage instead. This avoids creating a new
        PCA_site_plan_geodatabase.gpkg when the main site-plan database is not
        already present.
        """
        project_home = self.project.homePath()

        if not project_home:
            raise FieldwalkGridError(
                "The QGIS project home path is not available.\n\n"
                "Please save the QGIS project before generating the grid."
            )

        gpkg_folder = os.path.join(project_home, self.GPKG_FOLDER_NAME)

        try:
            os.makedirs(gpkg_folder, exist_ok=True)
        except OSError as error:
            raise FieldwalkGridError(
                "Could not create the project GeoPackage folder.\n\n"
                f"Expected folder:\n{gpkg_folder}\n\n"
                f"Error:\n{error}"
            )

        site_plan_gpkg_path = os.path.join(
            gpkg_folder,
            self.SITE_PLAN_GPKG_NAME,
        )

        if os.path.exists(site_plan_gpkg_path):
            return site_plan_gpkg_path

        return os.path.join(
            gpkg_folder,
            self.FW_RESOURCES_GPKG_NAME,
        )

    def _collection_layer_name(self, cell_width, cell_height):
        """Return the output layer name for the selected collection cell size."""
        return self.COLLECTION_LAYER_NAME_TEMPLATE.format(
            width=int(cell_width),
            height=int(cell_height),
        )

    def _get_boundary_geometry(self, boundary_layer):
        transform = None

        if boundary_layer.crs() != self.TARGET_CRS:
            transform = QgsCoordinateTransform(
                boundary_layer.crs(),
                self.TARGET_CRS,
                self.project,
            )

        boundary_geometries = []

        for feature in boundary_layer.getFeatures():
            geometry = feature.geometry()

            if not geometry or geometry.isEmpty():
                continue

            geometry = QgsGeometry(geometry)

            if transform is not None:
                geometry.transform(transform)

            if not geometry.isGeosValid():
                geometry = geometry.makeValid()

            if geometry and not geometry.isEmpty():
                boundary_geometries.append(geometry)

        if not boundary_geometries:
            raise FieldwalkGridError(
                "No valid polygon geometry was found in the selected boundary layer."
            )

        site_geom = QgsGeometry.unaryUnion(boundary_geometries)

        if not site_geom or site_geom.isEmpty():
            raise FieldwalkGridError(
                "Could not create a valid combined boundary geometry."
            )

        return site_geom

    def _create_memory_layers(self, collection_layer_name):
        hectare_layer = QgsVectorLayer(
            f"Polygon?crs={self.TARGET_CRS.authid()}",
            self.HECTARE_LAYER_NAME,
            "memory",
        )

        hectare_provider = hectare_layer.dataProvider()
        hectare_provider.addAttributes(
            [
                self._qgs_field(self.H_FIELD, "string", 50),
                self._qgs_field("row_no", "int"),
                self._qgs_field("col_no", "int"),
            ]
        )
        hectare_layer.updateFields()

        ten_metre_layer = QgsVectorLayer(
            f"Polygon?crs={self.TARGET_CRS.authid()}",
            collection_layer_name,
            "memory",
        )

        ten_metre_provider = ten_metre_layer.dataProvider()
        ten_metre_provider.addAttributes(
            [
                self._qgs_field(self.H_FIELD, "string", 50),
                self._qgs_field(self.E_FIELD, "int"),
                self._qgs_field(self.N_FIELD, "int"),
                self._qgs_field(self.FINAL_LABEL_FIELD, "string", 80),
            ]
        )
        ten_metre_layer.updateFields()

        return hectare_layer, ten_metre_layer

    def _generate_features(
        self,
        site_geom,
        hectare_fields,
        ten_metre_fields,
        remove_outside_10m=True,
        cell_width=DEFAULT_CELL_WIDTH,
        cell_height=DEFAULT_CELL_HEIGHT,
    ):
        extent = site_geom.boundingBox()

        start_x = math.floor(extent.xMinimum() / self.HECTARE_SIZE) * self.HECTARE_SIZE
        start_y = math.floor(extent.yMinimum() / self.HECTARE_SIZE) * self.HECTARE_SIZE

        end_x = math.ceil(extent.xMaximum() / self.HECTARE_SIZE) * self.HECTARE_SIZE
        end_y = math.ceil(extent.yMaximum() / self.HECTARE_SIZE) * self.HECTARE_SIZE

        hectare_features = []
        ten_metre_features = []

        hectare_counter = 1
        row_no = 1

        y = start_y

        while y < end_y:
            x = start_x
            col_no = 1

            while x < end_x:
                hectare_rectangle = QgsRectangle(
                    x,
                    y,
                    x + self.HECTARE_SIZE,
                    y + self.HECTARE_SIZE,
                )

                hectare_geometry = QgsGeometry.fromRect(hectare_rectangle)

                if hectare_geometry.intersects(site_geom):
                    hectare_label = f"{self.H_PREFIX}{hectare_counter}"

                    hectare_feature = QgsFeature(hectare_fields)
                    hectare_feature.setGeometry(hectare_geometry)
                    hectare_feature[self.H_FIELD] = hectare_label
                    hectare_feature["row_no"] = row_no
                    hectare_feature["col_no"] = col_no

                    hectare_features.append(hectare_feature)

                    self._create_10m_features_for_hectare(
                        ten_metre_features=ten_metre_features,
                        ten_metre_fields=ten_metre_fields,
                        site_geom=site_geom,
                        hectare_x=x,
                        hectare_y=y,
                        hectare_label=hectare_label,
                        remove_outside_10m=remove_outside_10m,
                        cell_width=cell_width,
                        cell_height=cell_height,
                    )

                    hectare_counter += 1

                x += self.HECTARE_SIZE
                col_no += 1

            y += self.HECTARE_SIZE
            row_no += 1

        return hectare_features, ten_metre_features

    def _create_10m_features_for_hectare(
        self,
        ten_metre_features,
        ten_metre_fields,
        site_geom,
        hectare_x,
        hectare_y,
        hectare_label,
        remove_outside_10m=True,
        cell_width=DEFAULT_CELL_WIDTH,
        cell_height=DEFAULT_CELL_HEIGHT,
    ):
        column_count = int(self.HECTARE_SIZE / cell_width)
        row_count = int(self.HECTARE_SIZE / cell_height)

        for north_row in range(1, row_count + 1):
            for east_label in range(1, column_count + 1):
                x_min = hectare_x + ((east_label - 1) * cell_width)
                y_min = hectare_y + ((north_row - 1) * cell_height)

                ten_metre_rectangle = QgsRectangle(
                    x_min,
                    y_min,
                    x_min + cell_width,
                    y_min + cell_height,
                )

                ten_metre_geometry = QgsGeometry.fromRect(ten_metre_rectangle)

                if remove_outside_10m and not ten_metre_geometry.intersects(site_geom):
                    continue

                ten_metre_feature = QgsFeature(ten_metre_fields)
                ten_metre_feature.setGeometry(ten_metre_geometry)

                ten_metre_feature[self.H_FIELD] = hectare_label
                ten_metre_feature[self.E_FIELD] = east_label
                north_distance = (north_row - 1) * cell_height

                ten_metre_feature[self.N_FIELD] = north_distance
                ten_metre_feature[self.FINAL_LABEL_FIELD] = (
                    f"{hectare_label}-{east_label}-{north_distance}"
                )

                ten_metre_features.append(ten_metre_feature)

    def _write_layer_to_geopackage(self, layer, gpkg_path, layer_name):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        options.fileEncoding = "UTF-8"
        if os.path.exists(gpkg_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        # Important for rendering performance
        options.layerOptions = [
            "SPATIAL_INDEX=YES",
        ]

        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            gpkg_path,
            self.project.transformContext(),
            options,
        )

        error_code = result[0]
        error_message = result[1] if len(result) > 1 else ""

        if error_code != QgsVectorFileWriter.NoError:
            raise FieldwalkGridError(
                f"Could not write layer '{layer_name}' to the GeoPackage.\n\n"
                f"{error_message}"
            )

    def _load_geopackage_layer(self, gpkg_path, layer_name):
        uri = f"{gpkg_path}|layername={layer_name}"

        layer = QgsVectorLayer(
            uri,
            layer_name,
            "ogr",
        )

        if not layer.isValid():
            raise FieldwalkGridError(
                f"The layer '{layer_name}' was written to the GeoPackage, "
                "but QGIS could not reload it."
            )

        try:
            layer.dataProvider().createSpatialIndex()
        except Exception:
            pass

        return layer

    def _apply_and_save_style(self, layer, style_filename, style_name):
        style_path = os.path.join(
            self.plugin_dir,
            "resources",
            "styles",
            style_filename,
        )

        if not os.path.exists(style_path):
            raise FieldwalkGridError(
                f"The style file was not found:\n\n{style_path}"
            )

        error_message, success = layer.loadNamedStyle(style_path)

        if not success:
            raise FieldwalkGridError(
                f"Could not apply style '{style_filename}'.\n\n"
                f"{error_message}"
            )

        layer.triggerRepaint()

        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                category=DeprecationWarning,
                message=".*saveStyleToDatabase.*",
            )

            save_result = layer.saveStyleToDatabase(
                style_name,
                "Embedded style automatically saved by PCA Fieldwalk Grid Generator.",
                True,
                "",
            )

        if isinstance(save_result, tuple):
            success = save_result[0]
            message = save_result[1] if len(save_result) > 1 else ""

            if not success:
                raise FieldwalkGridError(
                    f"Style was applied but could not be saved into the GeoPackage.\n\n"
                    f"{message}"
                )
                
                
    def _qgs_field(self, name, field_type, length=0, precision=0):
        """
        Create QgsField safely across QGIS 3.28, 3.44 and QGIS 4.

        QGIS 3.38+ prefers QMetaType.Type.
        QGIS 3.28 still works safely with QVariant.
        """

        field_type = field_type.lower().strip()

        try:
            from qgis.PyQt.QtCore import QMetaType

            if field_type == "int":
                return QgsField(name, QMetaType.Type.Int)

            if field_type == "double":
                return QgsField(
                    name,
                    QMetaType.Type.Double,
                    len=length,
                    prec=precision,
                )

            if field_type == "string":
                return QgsField(
                    name,
                    QMetaType.Type.QString,
                    len=length,
                )

        except (ImportError, AttributeError, TypeError):
            pass

        if field_type == "int":
            return QgsField(name, QVariant.Int)

        if field_type == "double":
            return QgsField(
                name,
                QVariant.Double,
                len=length,
                prec=precision,
            )

        if field_type == "string":
            return QgsField(
                name,
                QVariant.String,
                len=length,
            )

        raise ValueError(f"Unsupported field type: {field_type}")

    def _remove_existing_output_layers_from_project(self, collection_layer_name):
        """Remove existing generated grid layers before overwriting them in the GeoPackage."""
        output_layer_names = {
            self.HECTARE_LAYER_NAME,
            collection_layer_name,
            "Grid_10m",  # Legacy layer name from version 1.00.
        }

        layer_ids_to_remove = []

        for layer in self.project.mapLayers().values():
            layer_name = layer.name()

            if layer_name in output_layer_names:
                layer_ids_to_remove.append(layer.id())
                continue

            if layer_name.startswith("Grid_") and layer_name.endswith("m") and "x" in layer_name:
                layer_ids_to_remove.append(layer.id())

        if layer_ids_to_remove:
            self.project.removeMapLayers(layer_ids_to_remove)
            
    def _refresh_loaded_gpkg_layers(self, gpkg_path):
        """Refresh layers already loaded from the same GeoPackage."""
        gpkg_path_normalised = os.path.normcase(os.path.abspath(gpkg_path))

        for layer in self.project.mapLayers().values():
            provider = layer.dataProvider()

            if provider is None:
                continue

            source_uri = provider.dataSourceUri()
            source_path = source_uri.split("|")[0]
            source_path_normalised = os.path.normcase(os.path.abspath(source_path))

            if source_path_normalised != gpkg_path_normalised:
                continue

            if hasattr(layer, "reload"):
                layer.reload()
            else:
                with warnings.catch_warnings():
                    warnings.filterwarnings(
                        "ignore",
                        category=DeprecationWarning,
                        message=".*forceReload.*",
                    )

                    if hasattr(provider, "forceReload"):
                        provider.forceReload()

            layer.triggerRepaint()
            
    def _insert_layer_above_reference(
        self,
        layer,
        reference_layer,
    ):
        """
        Insert a layer directly above the reference layer
        inside the same layer tree group.
        """

        root = self.project.layerTreeRoot()

        reference_node = root.findLayer(reference_layer.id())

        if reference_node is None:
            self.project.addMapLayer(layer)
            return

        parent_group = reference_node.parent()

        if parent_group is None:
            self.project.addMapLayer(layer)
            return

        # Add layer without automatic insertion
        self.project.addMapLayer(layer, False)

        reference_index = parent_group.children().index(reference_node)

        parent_group.insertLayer(reference_index, layer)