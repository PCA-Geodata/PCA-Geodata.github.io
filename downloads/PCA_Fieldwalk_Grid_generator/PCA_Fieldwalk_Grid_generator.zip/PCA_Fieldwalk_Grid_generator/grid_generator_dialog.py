# -*- coding: utf-8 -*-
"""Dialog for PCA Fieldwalk Grid Generator."""

import os
import webbrowser

from qgis.PyQt.QtGui import QPixmap

from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel

from .compat import align_left, align_vcenter, qt_alignment

from .theme import is_dark_theme


class FieldwalkGridGeneratorDialog(QDialog):
    """User interface for selecting the boundary layer and grid options."""

    def __init__(self, plugin_dir, parent=None):
        super().__init__(parent)
        self.plugin_dir = plugin_dir
        self.setWindowTitle("PCA Fieldwalk Grid Generator")
        self.setMinimumWidth(520)
        self.setModal(True)

        self._build_ui()
        self._apply_style()

    def selected_layer(self):
        """Return the selected polygon boundary layer."""
        return self.layer_combo.currentLayer()

    def remove_10m_outside_boundary(self):
        """Return whether 10 m squares outside the boundary should be removed."""
        return self.remove_10m_checkbox.isChecked()

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(14)

        main_layout.addWidget(self._build_header())

        card = QFrame(self)
        card.setObjectName("card")

        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 14, 16, 14)
        card_layout.setSpacing(12)

        layer_label = QLabel("Reference boundary layer", card)
        layer_label.setObjectName("sectionLabel")

        self.layer_combo = QgsMapLayerComboBox(card)
        self.layer_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.layer_combo.setAllowEmptyLayer(False)

        note = QLabel(
            "The selected layer will be transformed internally to EPSG:27700. "
            "The 100 m grid origin is anchored to clean British National Grid "
            "coordinates ending in 00.",
            card,
        )
        note.setWordWrap(True)
        note.setObjectName("hintLabel")

        self.remove_10m_checkbox = QCheckBox(
            "Remove 10 x 10 m squares outside the reference boundary",
            card,
        )
        self.remove_10m_checkbox.setChecked(True)
        self.remove_10m_checkbox.setToolTip(
            "If enabled, only 10 m squares touching or overlapping the boundary "
            "are kept. If disabled, all internal 10 m squares are created "
            "for each retained hectare square."
        )

        summary = QLabel(
            "Output layers will be saved into the project GeoPackage as "
            "'Grid_Hectares' and 'Grid_10m'. Styles will be loaded from the "
            "plugin resources and saved into the GeoPackage.",
            card,
        )
        summary.setWordWrap(True)
        summary.setObjectName("hintLabel")

        card_layout.addWidget(layer_label)
        card_layout.addWidget(self.layer_combo)
        card_layout.addWidget(note)
        card_layout.addSpacing(4)
        card_layout.addWidget(self.remove_10m_checkbox)
        card_layout.addWidget(summary)

        main_layout.addWidget(card)

        self.button_box = QDialogButtonBox(self)

        self.run_button = QPushButton("Generate grids", self)
        self.run_button.setObjectName("primaryButton")

        self.button_box.addButton(
            self.run_button,
            QDialogButtonBox.ButtonRole.AcceptRole,
        )
        self.button_box.addButton(QDialogButtonBox.StandardButton.Cancel)

        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        main_layout.addWidget(self.button_box)

    def _build_header(self):
        header = QWidget(self)

        layout = QHBoxLayout(header)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        icon = QLabel(header)
        icon.setObjectName("headerIcon")
        icon.setAlignment(qt_alignment(align_left(), align_vcenter()))

        icon_path = os.path.join(
            os.path.dirname(__file__),
            "icons",
            "PCA_Fieldwalk_Grid_generator_icon.png",
        )

        pixmap = QPixmap(icon_path)

        if not pixmap.isNull():
            pixmap = pixmap.scaled(
                52,
                52,
            )

            icon.setPixmap(pixmap)

        text_container = QWidget(header)

        text_layout = QVBoxLayout(text_container)
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(2)

        title = QLabel("Fieldwalk Grid Generator", text_container)
        title.setObjectName("titleLabel")

        subtitle = QLabel(
            "Create PCA 100 m hectare and 10 m fieldwalking grids",
            text_container,
        )
        subtitle.setObjectName("subtitleLabel")
        subtitle.setWordWrap(True)

        text_layout.addWidget(title)
        text_layout.addWidget(subtitle)

        help_button = QToolButton(header)
        help_button.setText("Help")
        help_button.setObjectName("helpButton")
        help_button.setToolTip("Open help")
        help_button.clicked.connect(self.help_show)

        layout.addWidget(icon)
        layout.addWidget(text_container, 1)
        layout.addWidget(help_button)

        return header

    def help_show(self):
        """Open local HTML help."""
        help_path = os.path.join(
            self.plugin_dir,
            "help",
            "help.html",
        )

        if not os.path.exists(help_path):
            QMessageBox.about(
                self,
                "PCA Fieldwalk Grid Generator",
                "Help file not found. Please check the plugin installation.",
            )
            return

        webbrowser.open(help_path)
    
    def _apply_style(self):
        if is_dark_theme():
            text = "rgba(245, 245, 245, 235)"
            muted = "rgba(210, 210, 210, 200)"
            title = "rgba(245, 245, 245, 245)"
            card_bg = "rgba(95, 130, 95, 42)"
            card_border = "rgba(140, 180, 140, 120)"
            input_bg = "rgba(70, 70, 70, 230)"
            input_text = "rgba(255, 255, 255, 240)"
        else:
            text = "palette(text)"
            muted = "rgba(85, 100, 90, 210)"
            title = "palette(text)"
            card_bg = "rgba(130, 170, 120, 28)"
            card_border = "rgba(120, 150, 120, 90)"
            input_bg = "rgba(255, 255, 255, 240)"
            input_text = "rgba(20, 30, 25, 240)"

        self.setStyleSheet(
            f"""
            QDialog {{
                background-color: palette(window);
            }}

            QLabel#headerIcon {{
                padding: 2px 8px 2px 2px;
                background: transparent;
            }}

            QLabel#titleLabel {{
                color: {title};
                font-size: 15pt;
                font-weight: 700;
            }}

            QLabel#subtitleLabel {{
                color: {muted};
                font-size: 9.5pt;
            }}

            QFrame#card {{
                background-color: {card_bg};
                border: 1px solid {card_border};
                border-radius: 12px;
            }}

            QLabel#sectionLabel {{
                color: {text};
                font-size: 10.5pt;
                font-weight: 700;
            }}

            QLabel#hintLabel {{
                color: {muted};
                font-size: 9pt;
            }}

            QgsMapLayerComboBox {{
                min-height: 28px;
                padding: 3px 6px;
                color: {input_text};
                background-color: {input_bg};
            }}

            QCheckBox {{
                color: {text};
                spacing: 9px;
                font-size: 10pt;
            }}

            QPushButton#primaryButton {{
                background-color: rgba(70, 135, 85, 230);
                color: white;
                border: 1px solid rgba(45, 105, 60, 220);
                border-radius: 8px;
                padding: 7px 14px;
                font-weight: 700;
            }}

            QPushButton#primaryButton:hover {{
                background-color: rgba(80, 150, 95, 240);
            }}

            QToolButton#helpButton {{
                background-color: rgba(70, 135, 85, 45);
                border: 1px solid rgba(70, 135, 85, 110);
                border-radius: 14px;
                color: {text};
                font-size: 12pt;
                font-weight: 700;
                min-width: 28px;
                max-width: 28px;
                min-height: 28px;
                max-height: 28px;
                padding: 0px;
            }}

            QToolButton#helpButton:hover {{
                background-color: rgba(70, 135, 85, 85);
            }}
            """
        )