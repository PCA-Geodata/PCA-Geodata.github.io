# -*- coding: utf-8 -*-
"""Add generated grid layers to all project map themes."""

from qgis.core import QgsProject, QgsMapThemeCollection


class MapThemeGridUpdaterError(Exception):
    """Controlled user-facing error."""


class MapThemeGridUpdater:
    """Ensure fieldwalking grid layers are visible in all map themes."""

    DEFAULT_LAYER_NAMES = [
        "Grid_10m",
        "Grid_Hectares",
    ]

    def __init__(self):
        self.project = QgsProject.instance()

    def run(self, layer_names=None):
        layer_names = layer_names or self.DEFAULT_LAYER_NAMES

        mtc = self.project.mapThemeCollection()
        theme_names = mtc.mapThemes()

        if not theme_names:
            raise MapThemeGridUpdaterError(
                "No map themes were found in the current project."
            )

        layers_by_name = {}

        for layer in self.project.mapLayers().values():
            if layer.name() in layer_names and layer.name() not in layers_by_name:
                layers_by_name[layer.name()] = layer

        missing_layers = [
            layer_name for layer_name in layer_names
            if layer_name not in layers_by_name
        ]

        if missing_layers:
            raise MapThemeGridUpdaterError(
                "The following grid layer(s) were not found in the project:\n\n"
                + "\n".join(f"• {name}" for name in missing_layers)
                + "\n\nPlease generate or load the grid layers before updating map themes."
            )

        target_layers = list(layers_by_name.values())

        updated_count = 0

        for theme_name in theme_names:
            state = mtc.mapThemeState(theme_name)
            records = list(state.layerRecords())

            records_by_layer_id = {}

            for record in records:
                layer = record.layer()
                if layer is not None:
                    records_by_layer_id[layer.id()] = record

            changed = False

            for layer in target_layers:
                if layer.id() in records_by_layer_id:
                    record = records_by_layer_id[layer.id()]

                    if not record.isVisible:
                        record.isVisible = True
                        changed = True

                else:
                    new_record = QgsMapThemeCollection.MapThemeLayerRecord(layer)
                    new_record.isVisible = True
                    records.append(new_record)
                    changed = True

            if changed:
                state.setLayerRecords(records)
                mtc.update(theme_name, state)
                updated_count += 1

        return updated_count, len(theme_names), layer_names