# -*- coding: utf-8 -*-
"""Confirmation dialog for updating map themes."""

from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFrame,
    QLabel,
    QVBoxLayout,
)

from .theme import is_dark_theme

class MapThemeGridUpdaterDialog(QDialog):
    """Simple confirmation dialog before updating all map themes."""

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Add Grid Layers to Map Themes")
        self.setMinimumWidth(520)
        self.setModal(True)

        self._build_ui()
        self._apply_style()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        title = QLabel("Add fieldwalking grids to all map themes", self)
        title.setObjectName("titleLabel")

        description = QLabel(
            "This tool will add the generated fieldwalking grid layers to every "
            "map theme in the current QGIS project and set them as visible.",
            self,
        )
        description.setWordWrap(True)
        description.setObjectName("descriptionLabel")

        card = QFrame(self)
        card.setObjectName("card")

        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(14, 14, 14, 14)
        card_layout.setSpacing(8)

        layers = QLabel(
            "The following layers will be added to all map themes if they exist:\n\n"
            "• Grid_Hectares\n"
            "• Grid_10m",
            card,
        )
        layers.setObjectName("infoLabel")

        warning = QLabel(
            "Existing map themes will be updated. This does not change the layer data, "
            "but it changes which layers are visible in each map theme.",
            card,
        )
        warning.setWordWrap(True)
        warning.setObjectName("warningLabel")

        card_layout.addWidget(layers)
        card_layout.addWidget(warning)

        self.button_box = QDialogButtonBox(self)
        self.button_box.setStandardButtons(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )

        ok_button = self.button_box.button(QDialogButtonBox.StandardButton.Ok)
        if ok_button is not None:
            ok_button.setText("Update map themes")
            ok_button.setObjectName("primaryButton")

        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        layout.addWidget(title)
        layout.addWidget(description)
        layout.addWidget(card)
        layout.addWidget(self.button_box)

    def _apply_style(self):
        if is_dark_theme():
            title = "rgba(120, 190, 135, 240)"
            text = "rgba(245, 245, 245, 235)"
            muted = "rgba(210, 210, 210, 200)"
            card_bg = "rgba(95, 130, 95, 42)"
            card_border = "rgba(140, 180, 140, 120)"
        else:
            title = "rgba(70, 135, 85, 230)"
            text = "palette(text)"
            muted = "rgba(85, 100, 90, 210)"
            card_bg = "rgba(130, 170, 120, 28)"
            card_border = "rgba(120, 150, 120, 90)"

        self.setStyleSheet(
            f"""
            QDialog {{
                background-color: palette(window);
            }}

            QLabel#titleLabel {{
                color: {title};
                font-size: 15pt;
                font-weight: 700;
            }}

            QLabel#descriptionLabel {{
                color: {text};
                font-size: 10pt;
            }}

            QFrame#card {{
                background-color: {card_bg};
                border: 1px solid {card_border};
                border-radius: 12px;
            }}

            QLabel#infoLabel {{
                color: {text};
                font-size: 10pt;
            }}

            QLabel#warningLabel {{
                color: {muted};
                font-size: 9pt;
                font-style: italic;
            }}

            QPushButton#primaryButton {{
                background-color: rgba(70, 135, 85, 230);
                color: white;
                border: 1px solid rgba(45, 105, 60, 220);
                border-radius: 8px;
                padding: 7px 14px;
                font-weight: 700;
            }}

            QPushButton#primaryButton:hover {{
                background-color: rgba(80, 150, 95, 240);
            }}
            """
        )