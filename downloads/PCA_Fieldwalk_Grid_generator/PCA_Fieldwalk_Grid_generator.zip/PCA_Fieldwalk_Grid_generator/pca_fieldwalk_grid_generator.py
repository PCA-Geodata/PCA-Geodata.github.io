# -*- coding: utf-8 -*-
"""Main plugin class for PCA Fieldwalk Grid Generator."""

import os

from qgis.PyQt.QtGui import QIcon

from qgis.core import QgsProject

try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction

from qgis.PyQt.QtWidgets import QMessageBox, QToolBar

from .compat import accepted_result, dialog_exec
from .grid_generator import FieldwalkGridGenerator, FieldwalkGridError
from .grid_generator_dialog import FieldwalkGridGeneratorDialog
from .pca_menu_helper import (
    get_or_create_plugin_submenu,
    remove_empty_duplicate_pca_menus,
    remove_plugin_submenu_if_empty,
)

from .map_theme_grid_updater import (
    MapThemeGridUpdater,
    MapThemeGridUpdaterError,
)
from .map_theme_grid_updater_dialog import MapThemeGridUpdaterDialog

class PCAFieldwalkGridGenerator:
    """QGIS plugin entry point."""

    TOOLBAR_NAME = "PCA Fieldwalk Grid Generator Toolbar"
    TOOLBAR_OBJECT_NAME = "PCA_Fieldwalk_Grid_Generator_Toolbar"

    MENU_TITLE = "PCA Fieldwalk Grid Generator"
    MENU_OBJECT_NAME = "PCA_Fieldwalk_Grid_Generator_Menu"

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        self.actions = []
        self.toolbar = None
        self.plugin_menu = None
        
        self.plugin_version = self._read_plugin_version()

        self.first_start = None

    def initGui(self):  # pylint: disable=invalid-name
        self._remove_existing_toolbars()
        remove_empty_duplicate_pca_menus(self.iface)

        self.toolbar = self.iface.addToolBar(self.TOOLBAR_NAME)
        self.toolbar.setObjectName(self.TOOLBAR_OBJECT_NAME)

        self.plugin_menu = get_or_create_plugin_submenu(
            self.iface,
            self.MENU_TITLE,
            self.MENU_OBJECT_NAME,
        )

        self.add_action(
            icon_path=os.path.join(self.plugin_dir, "icons", "pca_logo_icon.png"),
            text=f"PCA Fieldwalk Grid Generator - (v.{self.plugin_version})",
            callback=self.noop,
            status_tip="",
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=os.path.join(
                self.plugin_dir,
                "icons",
                "PCA_Fieldwalk_Grid_generator_icon.png",
            ),
            text="Generate Fieldwalk Grid",
            callback=self.run,
            status_tip="Generate PCA fieldwalking 100 m and 10 m grids",
            parent=self.iface.mainWindow(),
        )
        
        self.add_action(
            icon_path=os.path.join(
                self.plugin_dir,
                "icons",
                "PCA_Fieldwalk_Grid_map_theme_updater_icon.png",
            ),
            text="Add Grid Layers to All Map Themes",
            callback=self.run_map_theme_updater,
            status_tip="Add Grid_Hectares and Grid_10m to all project map themes",
            add_to_toolbar=False,
            parent=self.iface.mainWindow(),
        )

        self.first_start = True

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None,
    ):
        """Create an action and add it to the plugin toolbar and PCA submenu."""
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)
            action.setToolTip(status_tip)

        if whats_this:
            action.setWhatsThis(whats_this)

        if add_to_toolbar and self.toolbar is not None:
            self.toolbar.addAction(action)

        if add_to_menu and self.plugin_menu is not None:
            self.plugin_menu.addAction(action)

        self.actions.append(action)
        return action

    def unload(self):
        """Remove plugin menu items and custom toolbar."""
        if self.plugin_menu is not None:
            for action in self.actions:
                self.plugin_menu.removeAction(action)

            remove_plugin_submenu_if_empty(
                self.iface,
                self.plugin_menu,
            )

            self.plugin_menu = None

        if self.toolbar is not None:
            for action in self.actions:
                self.toolbar.removeAction(action)

        self._remove_existing_toolbars()

        self.actions = []
        self.toolbar = None

        remove_empty_duplicate_pca_menus(self.iface)

    def _read_plugin_version(self):
        metadata_path = os.path.join(self.plugin_dir, "metadata.txt")

        if not os.path.exists(metadata_path):
            print("metadata.txt not found!")
            return "unknown"

        version = "unknown"

        try:
            with open(metadata_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                        break
        except Exception as e:
            print(f"Could not read metadata.txt: {e}")

        return version
        
    def _remove_existing_toolbars(self):
        """Remove stale toolbar instances left by plugin reloads."""
        main_window = self.iface.mainWindow()

        for toolbar in main_window.findChildren(QToolBar):
            if toolbar.objectName() == self.TOOLBAR_OBJECT_NAME:
                toolbar.clear()
                main_window.removeToolBar(toolbar)
                toolbar.setParent(None)
                toolbar.deleteLater()

    def run(self):
        dialog = FieldwalkGridGeneratorDialog(
            self.plugin_dir,
            self.iface.mainWindow(),
        )

        if dialog_exec(dialog) != accepted_result():
            return

        boundary_layer = dialog.selected_layer()
        remove_outside_10m = dialog.remove_10m_outside_boundary()

        try:
            generator = FieldwalkGridGenerator(self.plugin_dir)

            hectare_count, ten_metre_count, gpkg_path = generator.run(
                boundary_layer=boundary_layer,
                remove_outside_10m=remove_outside_10m,
            )

            QMessageBox.information(
                self.iface.mainWindow(),
                "PCA Fieldwalk Grid Generator",
                (
                    "Grid generation completed successfully.\n\n"
                    f"Hectare grid squares: {hectare_count}\n"
                    f"10 m grid squares: {ten_metre_count}\n\n"
                    f"Saved to:\n{gpkg_path}"
                ),
            )
            
            self.iface.mapCanvas().clearCache()
            self.iface.mapCanvas().refresh()

        except FieldwalkGridError as error:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "PCA Fieldwalk Grid Generator",
                str(error),
            )

        except Exception as error:  # pylint: disable=broad-exception-caught
            QMessageBox.critical(
                self.iface.mainWindow(),
                "PCA Fieldwalk Grid Generator",
                f"Unexpected error:\n\n{error}",
            )

    def run_map_theme_updater(self):
        dialog = MapThemeGridUpdaterDialog(self.iface.mainWindow())

        if dialog_exec(dialog) != accepted_result():
            return

        try:
            updater = MapThemeGridUpdater()

            updated_count, total_themes, layer_names = updater.run()

            QMessageBox.information(
                self.iface.mainWindow(),
                "PCA Fieldwalk Grid Generator",
                (
                    "Map themes updated successfully.\n\n"
                    f"Updated themes: {updated_count} of {total_themes}\n\n"
                    "Grid layers added/set visible:\n"
                    + "\n".join(f"• {name}" for name in layer_names)
                ),
            )

        except MapThemeGridUpdaterError as error:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "PCA Fieldwalk Grid Generator",
                str(error),
            )

        except Exception as error:  # pylint: disable=broad-exception-caught
            QMessageBox.critical(
                self.iface.mainWindow(),
                "PCA Fieldwalk Grid Generator",
                f"Unexpected error while updating map themes:\n\n{error}",
            )
















           
    def noop(self):
        pass