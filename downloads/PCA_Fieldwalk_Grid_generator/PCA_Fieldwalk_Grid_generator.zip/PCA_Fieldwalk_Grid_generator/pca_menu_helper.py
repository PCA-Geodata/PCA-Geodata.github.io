# -*- coding: utf-8 -*-
"""Reusable PCA menu helper for QGIS plugins."""

from qgis.PyQt.QtWidgets import QMenu


PCA_MENU_TITLE = "PCA"
PCA_MENU_OBJECT_NAME = "PCA_Menu"


def clean_menu_text(text):
    return text.replace("&", "").strip()


def get_or_create_pca_menu(iface):
    """Return the shared top-level PCA menu, creating it if needed."""
    main_window = iface.mainWindow()
    menu_bar = main_window.menuBar()

    existing_pca_menus = []

    for action in menu_bar.actions():
        menu = action.menu()

        if menu is None:
            continue

        if (
            menu.objectName() == PCA_MENU_OBJECT_NAME
            or clean_menu_text(menu.title()) == PCA_MENU_TITLE
            or clean_menu_text(action.text()) == PCA_MENU_TITLE
        ):
            existing_pca_menus.append(menu)

    if existing_pca_menus:
        primary_menu = existing_pca_menus[0]
        primary_menu.setObjectName(PCA_MENU_OBJECT_NAME)
        primary_menu.setTitle(PCA_MENU_TITLE)

        for duplicate_menu in existing_pca_menus[1:]:
            if not duplicate_menu.actions():
                menu_bar.removeAction(duplicate_menu.menuAction())
                duplicate_menu.deleteLater()

        return primary_menu

    pca_menu = QMenu(PCA_MENU_TITLE, main_window)
    pca_menu.setObjectName(PCA_MENU_OBJECT_NAME)

    plugins_action = None

    for action in menu_bar.actions():
        if clean_menu_text(action.text()) == "Plugins":
            plugins_action = action
            break

    if plugins_action is not None:
        menu_bar.insertMenu(plugins_action, pca_menu)
    else:
        menu_bar.addMenu(pca_menu)

    return pca_menu


def get_or_create_plugin_submenu(iface, submenu_title, object_name):
    """Return a plugin submenu under PCA, creating it if needed."""
    pca_menu = get_or_create_pca_menu(iface)

    for action in pca_menu.actions():
        submenu = action.menu()

        if submenu is None:
            continue

        if submenu.objectName() == object_name or submenu.title() == submenu_title:
            submenu.setObjectName(object_name)
            submenu.setTitle(submenu_title)
            return submenu

    submenu = QMenu(submenu_title, pca_menu)
    submenu.setObjectName(object_name)
    pca_menu.addMenu(submenu)

    return submenu


def remove_plugin_submenu_if_empty(iface, submenu):
    """Remove a plugin submenu if empty, then remove PCA menu if empty."""
    if submenu is None:
        return

    if submenu.actions():
        return

    pca_menu = get_or_create_pca_menu(iface)
    pca_menu.removeAction(submenu.menuAction())
    submenu.deleteLater()

    remove_pca_menu_if_empty(iface)


def remove_pca_menu_if_empty(iface):
    """Remove empty PCA menus."""
    menu_bar = iface.mainWindow().menuBar()

    for action in list(menu_bar.actions()):
        menu = action.menu()

        if menu is None:
            continue

        if (
            menu.objectName() == PCA_MENU_OBJECT_NAME
            or clean_menu_text(menu.title()) == PCA_MENU_TITLE
            or clean_menu_text(action.text()) == PCA_MENU_TITLE
        ):
            if not menu.actions():
                menu_bar.removeAction(menu.menuAction())
                menu.deleteLater()


def remove_empty_duplicate_pca_menus(iface):
    """Clean empty duplicate PCA menus left by plugin reloads."""
    get_or_create_pca_menu(iface)
    remove_pca_menu_if_empty(iface)