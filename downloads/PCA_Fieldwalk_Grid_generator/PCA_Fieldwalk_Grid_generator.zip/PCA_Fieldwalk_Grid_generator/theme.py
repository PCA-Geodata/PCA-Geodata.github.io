# -*- coding: utf-8 -*-
"""Theme helpers for QGIS light/dark mode compatibility."""

from qgis.PyQt.QtGui import QPalette
from qgis.PyQt.QtWidgets import QApplication


def _window_role():
    if hasattr(QPalette, "ColorRole"):
        return QPalette.ColorRole.Window

    return QPalette.Window


def is_dark_theme():
    app = QApplication.instance()

    if app is None:
        return False

    colour = app.palette().color(_window_role())

    brightness = (
        colour.red() * 0.299
        + colour.green() * 0.587
        + colour.blue() * 0.114
    )

    return brightness < 128