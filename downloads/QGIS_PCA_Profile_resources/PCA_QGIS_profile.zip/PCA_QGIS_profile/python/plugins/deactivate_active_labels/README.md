# Deactivate Active Labels
This Plugin create one Button to on/off layer’s label and other Button to deactivate all labels and Active all labels that have been deactivate before.

# Contact
carlos.cagna@yahoo.com.br