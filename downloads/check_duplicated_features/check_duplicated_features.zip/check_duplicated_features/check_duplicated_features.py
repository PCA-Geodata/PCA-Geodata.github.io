# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CheckDuplicatedFeatures
                                 A QGIS plugin
 This plugin checks for duplicated features on a layer. Optionally, it can
 also compare a selected attribute field together with the geometry.
 ***************************************************************************/
"""

import os

from qgis.PyQt.QtCore import QCoreApplication, QSettings, Qt, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

from qgis.core import (
    QgsFeatureRequest,
    QgsMapLayerProxyModel,
    QgsVectorLayer,
)

from .resources import *
from .check_duplicated_features_dockwidget import CheckDuplicatedFeaturesDockWidget


class CheckDuplicatedFeatures:
    """Main plugin class."""

    def __init__(self, iface):
        """
        Plugin constructor.

        Parameters
        ----------
        iface : QgsInterface
            QGIS interface instance provided by QGIS at runtime.
        """
        # Store a reference to the QGIS interface so it can be reused
        # throughout the plugin instead of relying on the global iface.
        self.iface = iface

        # Absolute path to the plugin folder.
        self.plugin_dir = os.path.dirname(__file__)

        # Load translator file for the current user locale if available.
        # Fallback to English if the setting is missing or empty.
        locale = (QSettings().value('locale/userLocale') or 'en')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'CheckDuplicatedFeatures_{}.qm'.format(locale)
        )

        self.translator = None
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            if self.translator.load(locale_path):
                QCoreApplication.installTranslator(self.translator)

        # Store plugin actions so they can be removed cleanly on unload.
        self.actions = []

        # Menu and toolbar names shown in QGIS.
        self.menu = self.tr('&Check Duplicated Features')
        self.toolbar = self.iface.addToolBar('CheckDuplicatedFeatures')
        self.toolbar.setObjectName('CheckDuplicatedFeatures')

        # Internal plugin state.
        self.pluginIsActive = False
        
        # Read plugin version from metadata
        self.plugin_version = self._read_plugin_version()

        # Create the dock widget once and reuse it.
        # Reusing the same dock widget avoids unnecessary recreation and
        # reduces the chance of duplicate signal connections.
        self.dockwidget = CheckDuplicatedFeaturesDockWidget()
        
        self._apply_dock_style()

        # Restrict the layer combobox to layers with geometry only.
        # This plugin is designed for spatial vector layers.
        self.dockwidget.mMapLayerComboBox.setFilters(QgsMapLayerProxyModel.HasGeometry)

        # Field comparison is optional, so disable the field combobox until
        # the checkbox is checked.
        self.dockwidget.mFieldComboBox.setEnabled(False)

        # Track whether widget signals have already been connected.
        self._signals_connected = False
        self._connect_signals()

    def tr(self, message):
        """
        Translate a string using Qt translation API.

        Parameters
        ----------
        message : str
            Text to translate.

        Returns
        -------
        str
            Translated text.
        """
        return QCoreApplication.translate('CheckDuplicatedFeatures', message)

    def _connect_signals(self):
        """
        Connect widget signals once only.

        Reconnecting the same signals every time the plugin is opened can
        cause slots to fire multiple times, so this method guards against that.
        """
        if self._signals_connected:
            return

        self.dockwidget.closingPlugin.connect(self.onClosePlugin)
        self.dockwidget.mMapLayerComboBox.layerChanged.connect(self.update_field_combobox_layer)
        self.dockwidget.checkBox.stateChanged.connect(self.check_for_field)
        self.dockwidget.pushButton.clicked.connect(self.check_duplicated)

        self._signals_connected = True

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None
    ):
        """
        Add an action to the plugin menu and/or toolbar.

        Parameters
        ----------
        icon_path : str
            Path to the action icon.
        text : str
            Text shown in menu/toolbar.
        callback : callable
            Function called when the action is triggered.
        enabled_flag : bool, optional
            Whether the action is enabled by default.
        add_to_menu : bool, optional
            Whether to add the action to the QGIS plugin menu.
        add_to_toolbar : bool, optional
            Whether to add the action to the plugin toolbar.
        status_tip : str, optional
            Status bar hint.
        whats_this : str, optional
            Additional descriptive text.
        parent : QWidget, optional
            Parent widget.

        Returns
        -------
        QAction
            The created action.
        """
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create plugin menu entry and toolbar button."""

        icon_path = ':/plugins/check_duplicated_features/icons/check_duplicated_icon.png'

        self.add_action(
            icon_path,
            text=self.tr(f'Check duplicated features - – version {self.plugin_version}'),
            callback=self.run,
            parent=self.iface.mainWindow() )

    def onClosePlugin(self):
        """
        Handle dock widget closing.

        The dock widget itself is kept alive and reused, but the plugin active
        flag is reset so the plugin can be opened again cleanly.
        """
        self.pluginIsActive = False

    def unload(self):
        """
        Remove plugin menu items and toolbar icons from QGIS.

        This is called when the plugin is unloaded from QGIS.
        """
        for action in self.actions:
            self.iface.removePluginMenu(self.tr('&Check Duplicated Features'), action)
            self.iface.removeToolBarIcon(action)

        if self.dockwidget is not None:
            self.dockwidget.close()

        del self.toolbar
        
    def _apply_dock_style(self):
        """Apply a clean, compact style to the dock widget."""
        self.dockwidget.setStyleSheet("""
            QDockWidget {
                font-size: 9pt;
            }

            QLabel#titleLabel {
                font-size: 13pt;
                font-weight: bold;
                color: #2f3b2f;
            }

            QLabel#descriptionLabel {
                color: #555555;
            }

            QLabel#layerLabel,
            QLabel#fieldLabel {
                font-weight: bold;
                color: #333333;
            }

            QFrame#infoFrame {
                background-color: #f4f7f4;
                border: 1px solid #d6dfd6;
                border-radius: 6px;
            }

            QFrame#optionsFrame {
                background-color: #ffffff;
                border: 1px solid #dddddd;
                border-radius: 6px;
            }

            QgsMapLayerComboBox,
            QgsFieldComboBox,
            QComboBox {
                min-height: 28px;
                padding: 2px 6px;
                border: 1px solid #b8b8b8;
                border-radius: 4px;
                background-color: #ffffff;
                color: #1f1f1f;
                selection-background-color: #4f7f52;
                selection-color: #ffffff;
            }

            QgsMapLayerComboBox QAbstractItemView,
            QgsFieldComboBox QAbstractItemView,
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #1f1f1f;
                selection-background-color: #4f7f52;
                selection-color: #ffffff;
            }

            QgsMapLayerComboBox:disabled,
            QgsFieldComboBox:disabled,
            QComboBox:disabled {
                color: #777777;
                background-color: #eeeeee;
            }

            QCheckBox {
                spacing: 6px;
                color: #1f1f1f;
            }

            QPushButton#pushButton {
                min-height: 36px;
                font-weight: bold;
                color: white;
                background-color: #4f7f52;
                border: 1px solid #3d673f;
                border-radius: 6px;
                padding: 6px 12px;
            }

            QPushButton#pushButton:hover {
                background-color: #5f9362;
            }

            QPushButton#pushButton:pressed {
                background-color: #3d673f;
            }

            QPushButton#pushButton:disabled {
                background-color: #b7b7b7;
                border-color: #999999;
            }
        """)
        
    def _read_plugin_version(self):
        """
        Read plugin version directly from metadata.txt.
        Safe and works in QGIS 3 and QGIS 4.
        """
        metadata_path = os.path.join(self.plugin_dir, 'metadata.txt')

        if not os.path.exists(metadata_path):
            print("metadata.txt not found!")
            return "unknown"

        version = "unknown"

        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                        break
        except Exception as e:
            print(f"Could not read metadata.txt: {e}")

        return version

    def run(self):
        """
        Show the dock widget and preselect the current active layer if valid.
        """
        active_layer = self.iface.activeLayer()

        # Add the dock widget to the QGIS interface only the first time the
        # plugin is opened in the current session.
        if not self.pluginIsActive:
            self.pluginIsActive = True
            # QT5 obsolete
            ##self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dockwidget)
            # QT6 compatible
            self.iface.addDockWidget(self._left_dock_area(), self.dockwidget)

        self.dockwidget.show()
        self.dockwidget.raise_()

        # If the active layer is a spatial vector layer, preselect it in the UI
        # to make the workflow faster for the user.
        if isinstance(active_layer, QgsVectorLayer) and active_layer.isSpatial():
            self.dockwidget.mMapLayerComboBox.setLayer(active_layer)
            self.update_field_combobox_layer(active_layer)

    def update_field_combobox_layer(self, layer):
        """
        Update the field combobox to reflect the currently selected layer.

        Parameters
        ----------
        layer : QgsMapLayer
            Newly selected layer.
        """
        self.dockwidget.mFieldComboBox.setLayer(layer)

        # Only enable the field combobox if:
        # 1. the checkbox is checked
        # 2. a valid layer is currently selected
        self.dockwidget.mFieldComboBox.setEnabled(
            self.dockwidget.checkBox.isChecked() and layer is not None
        )

    def _build_feature_request(self, layer, field_name=None):
        """
        Build a feature request optimized for the current duplicate check.

        Geometry is always needed for this plugin. Attribute fetching is reduced:
        - geometry-only mode: fetch no attributes
        - geometry + field mode: fetch only the selected field
        """
        request = QgsFeatureRequest()

        if field_name:
            request.setSubsetOfAttributes([field_name], layer.fields())
        else:
            request.setNoAttributes()

        return request

    def _feature_duplicate_key(self, feature, field_name=None):
        """
        Build a hashable key used to detect duplicate features.

        For QGIS 3.x compatibility, geometry comparison is based on WKB bytes.
        This provides a strict binary representation of the geometry.

        Parameters
        ----------
        feature : QgsFeature
            Feature to analyse.
        field_name : str, optional
            Attribute field name to include in the duplicate check.

        Returns
        -------
        object
            A hashable key:
            - geometry only, or
            - (geometry, attribute value) tuple
        """
        geom = feature.geometry()

        # Distinguish null and empty geometries explicitly.
        # A null geometry also reports isEmpty() == True in QGIS, so the null
        # check must come first.
        if geom.isNull():
            geom_key = ("NULL_GEOMETRY",)
        elif geom.isEmpty():
            geom_key = ("EMPTY_GEOMETRY",)
        else:
            geom_key = bytes(geom.asWkb())

        # If no field is being used, the duplicate key is based on geometry only.
        if not field_name:
            return geom_key

        # When field comparison is enabled, combine geometry and attribute.
        return (geom_key, feature[field_name])

    def _collect_duplicate_ids(self, layer, field_name=None):
        """
        Collect ids of duplicate features from the layer.

        Duplicate detection is based on:
        - geometry only, or
        - geometry + one attribute field

        A set is used for fast lookups, which scales much better than a list
        on larger datasets.
        """
        seen_keys = set()
        duplicate_ids = []

        request = self._build_feature_request(layer, field_name)

        for feature in layer.getFeatures(request):
            key = self._feature_duplicate_key(feature, field_name)

            if key in seen_keys:
                duplicate_ids.append(feature.id())
            else:
                seen_keys.add(key)

        return duplicate_ids

    def _delete_feature_ids(self, layer, feature_ids):
        """
        Delete the given feature ids from the layer safely.

        The deletion is left as an unsaved edit so the user can manually
        save or roll back the changes from QGIS.

        Returns
        -------
        tuple[bool, str]
            (success, error_message)
        """
        if not feature_ids:
            return True, ""

        # If the layer is already editable, delete within the current edit session.
        # The user remains in control of saving or rolling back.
        if layer.isEditable():
            ok = layer.deleteFeatures(feature_ids)
            if not ok:
                return False, "Failed to delete duplicate features from the current edit session."

            return True, ""

        # Start an edit session, but do not commit automatically.
        if not layer.startEditing():
            return False, (
                "The selected layer could not be put into edit mode. "
                "It may be read-only or its data provider may not support editing."
            )

        ok = layer.deleteFeatures(feature_ids)

        if not ok:
            layer.rollBack()
            return False, "Failed to delete duplicate features."

        # Important:
        # Do not call commitChanges().
        # The layer is intentionally left editable with unsaved changes.
        return True, ""

    def check_for_field(self):
        """
        Enable or disable the field combobox when the checkbox changes.
        """
        enabled = self.dockwidget.checkBox.isChecked()
        self.dockwidget.mFieldComboBox.setEnabled(
            enabled and self.dockwidget.mMapLayerComboBox.currentLayer() is not None
        )
        
    def check_duplicated(self):
        """
        Find duplicated features in the selected layer.

        Duplicates are detected by:
        - geometry only, or
        - geometry + selected field value

        Matching duplicate feature ids are selected. The user is then given
        the option to delete them or review them in the attribute table.
        """
        layer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not isinstance(layer, QgsVectorLayer):
            QMessageBox.warning(
                self.iface.mainWindow(),
                'Check Duplicated Features',
                'Please select a valid vector layer.'
            )
            return

        use_field = self.dockwidget.checkBox.isChecked()
        field_name = self.dockwidget.mFieldComboBox.currentField() if use_field else None

        if use_field and not field_name:
            QMessageBox.warning(
                self.iface.mainWindow(),
                'Check Duplicated Features',
                'Please select a field for the combined geometry and attribute check.'
            )
            return

        # Keep the previous selection only so it can be restored if no duplicates
        # are found. If duplicates are found, the duplicate selection is kept.
        previous_selection = layer.selectedFeatureIds()

        duplicated_feature_ids = self._collect_duplicate_ids(layer, field_name)

        if use_field:
            check_description = 'same geometry and same attribute value'
        else:
            check_description = 'same geometry'

        duplicate_count = len(duplicated_feature_ids)

        if duplicate_count == 0:
            layer.selectByIds(previous_selection)

            QMessageBox.information(
                self.iface.mainWindow(),
                'No Duplicates Found',
                (
                    '<b>Duplicate check complete</b><br><br>'
                    'No duplicate features were found in the selected layer.'
                )
            )
            return

        # Select duplicate features so the user can inspect them.
        layer.selectByIds(duplicated_feature_ids)

        # Zoom to the selected duplicates.
        bbox = layer.boundingBoxOfSelected()
        if not bbox.isEmpty():
            self.iface.mapCanvas().setExtent(bbox.buffered(0.3))
            self.iface.mapCanvas().refresh()

        feature_word = 'feature' if duplicate_count == 1 else 'features'
        pronoun = 'it' if duplicate_count == 1 else 'them'

        yes_button, no_button = self._message_box_buttons()

        reply = QMessageBox.question(
            self.iface.mainWindow(),
            'Duplicate Features Detected',
            (
                f'<b>{duplicate_count} duplicate {feature_word} found</b><br><br>'
                f'The selected duplicate {feature_word} have the {check_description}.<br><br>'
                f'They are now selected in the layer so you can review them.<br><br>'
                f'<b>Do you want to delete {pronoun} now?</b><br><br>'
                '<span style="color:#666666;">'
                'The deletion will remain as an unsaved edit, so you can still '
                'save or roll back the changes from QGIS.'
                '</span>'
            ),
            yes_button | no_button,
            no_button
        )

        if reply != yes_button:
            self.iface.showAttributeTable(layer)
            return

        success, error_message = self._delete_feature_ids(layer, duplicated_feature_ids)

        if not success:
            QMessageBox.critical(
                self.iface.mainWindow(),
                'Check Duplicated Features',
                error_message
            )
            return

        QMessageBox.information(
            self.iface.mainWindow(),
            'Duplicates Deleted',
            (
                '<b>Duplicate features deleted</b><br><br>'
                'The duplicate features were removed from the layer.<br><br>'
                '<span style="color:#666666;">'
                'The changes have not been saved yet. You can still save or roll back '
                'the edit session from QGIS.'
                '</span>'
            )
        )

        self.iface.mapCanvas().refresh()
        
        
        
    def _left_dock_area(self):
        """
        Return the left dock widget area in a way that works with both
        Qt 5 / QGIS 3 and Qt 6 / QGIS 4.
        """
        try:
            return Qt.DockWidgetArea.LeftDockWidgetArea
        except AttributeError:
            return Qt.LeftDockWidgetArea
            
            
    def _message_box_buttons(self):
        try:
            return QMessageBox.StandardButton.Yes, QMessageBox.StandardButton.No
        except AttributeError:
            return QMessageBox.Yes, QMessageBox.No