# -*- coding: utf-8 -*-
"""
/***************************************************************************
 EvalTrenchGenerator
                                 A QGIS plugin
 This plugin generates evaluation trenches for archaeological evaluations.

 Professional refactor notes:
 - No QGIS Processing dependency.
 - Uses direct PyQGIS geometry and vector layer APIs.
 - Uses ESRI Shapefile output in a project Shapefiles subfolder.
 - Inherits CRS from input layers where possible.
 - Keeps trench distribution as a deterministic grid for now.
 - Adds safer layer validation, logging, output management and edit handling.
 - Adds progress feedback.
 - Keeps the original plugin actions and general workflow.

 Target:
 - QGIS 3.x
 - Prepared as far as practical for QGIS 4 / Qt6 compatibility.

 **************************************************************************/
"""

import csv
import math
import os
from configparser import ConfigParser
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from qgis.PyQt.QtCore import QCoreApplication, QSettings, QTranslator, QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QProgressDialog, QToolBar, QInputDialog

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsMapLayer,
    QgsMapLayerProxyModel,
    QgsMessageLog,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
    edit,
)

# Initialize Qt resources from file resources.py
from .resources import *  # noqa: F401,F403

# Import plugin dialogs
from .eval_trench_gener_dialog import EvalTrenchGeneratorDialog
from .eval_trench_route_numbers_dialog import EvalTrenchRouteNumbersDialog
from .eval_trench_stakeout_points_dialog import EvalTrenchGenerateStakeOutPointsDialog
from .eval_trench_stakeout_route_CSV_dialog import EvalTrenchStakeOutRouteCSVDialog


@dataclass(frozen=True)
class PluginDefaults:
    """Centralised plugin defaults."""

    fallback_crs_authid: str = "EPSG:27700"
    inward_boundary_buffer: float = -10.0
    excavation_point_interval: float = 30.0
    route_match_buffer: float = 1.5

    # User requested Shapefile output in a project subfolder called Shapefiles.
    output_folder_name: str = "Shapefiles"
    output_format: str = "ESRI Shapefile"

    trench_layer_base_name: str = "Trench_LOE"
    stakeout_layer_base_name: str = "StakeOut_Points"
    csv_base_name: str = "Setout_CSV"


class EvalTrenchGenerator:
    """Main QGIS plugin implementation."""

    PLUGIN_TITLE = "Evaluation Trench Generator"
    TOOLBAR_NAME = "Evaluation Trench Generator"
    LOG_TAG = "Evaluation Trench Generator"

    def __init__(self, iface):
        """
        Constructor.

        :param iface: QGIS interface instance.
        :type iface: QgsInterface
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.defaults = PluginDefaults()

        self.actions: List[QAction] = []
        self.menu = self.tr("&Evaluation Trench Generator")

        self.translator = None
        self._install_translation()

        self.toolbar = self.iface.mainWindow().findChild(QToolBar, self.TOOLBAR_NAME)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(self.TOOLBAR_NAME)
            self.toolbar.setObjectName(self.TOOLBAR_NAME)

        self.plugin_version = self._read_plugin_version()

        # Dialogs are kept separate. This avoids the old shared first_start flag
        # issue and prevents repeated signal connections.
        self.dlg: Optional[EvalTrenchGeneratorDialog] = None
        self.route_dlg: Optional[EvalTrenchRouteNumbersDialog] = None
        self.stakeout_dlg: Optional[EvalTrenchGenerateStakeOutPointsDialog] = None
        self.csv_dlg: Optional[EvalTrenchStakeOutRouteCSVDialog] = None

    # ------------------------------------------------------------------
    # Qt / plugin lifecycle helpers
    # ------------------------------------------------------------------

    def _install_translation(self):
        """Install plugin translation file if available."""
        locale = QSettings().value("locale/userLocale", "en")
        locale = str(locale)[0:2]

        locale_path = os.path.join(
            self.plugin_dir,
            "i18n",
            f"EvalTrenchGenerator_{locale}.qm",
        )

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            if self.translator.load(locale_path):
                QCoreApplication.installTranslator(self.translator)

    def tr(self, message: str) -> str:
        """Translate plugin strings."""
        return QCoreApplication.translate("EvalTrenchGenerator", message)

    def _read_plugin_version(self) -> str:
        """Read plugin version from metadata.txt."""
        metadata_path = os.path.join(self.plugin_dir, "metadata.txt")
        if not os.path.exists(metadata_path):
            return "unknown"

        parser = ConfigParser()
        try:
            parser.read(metadata_path, encoding="utf-8")
            if parser.has_section("general") and parser.has_option("general", "version"):
                return parser.get("general", "version").strip()
        except Exception as error:
            self._log(f"Could not parse metadata.txt with ConfigParser: {error}", Qgis.Warning)

        try:
            with open(metadata_path, "r", encoding="utf-8") as metadata_file:
                for line in metadata_file:
                    if line.strip().lower().startswith("version="):
                        return line.split("=", 1)[1].strip()
        except Exception as error:
            self._log(f"Could not read metadata.txt: {error}", Qgis.Warning)

        return "unknown"

    def add_action(
        self,
        icon_path: str,
        text: str,
        callback,
        enabled_flag: bool = True,
        add_to_menu: bool = True,
        add_to_toolbar: bool = True,
        status_tip: Optional[str] = None,
        whats_this: Optional[str] = None,
        parent=None,
    ) -> QAction:
        """Create a QAction and add it to the plugin menu / toolbar."""
        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)

        if whats_this:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create plugin menu entries and toolbar icons."""
        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/pca_logo_icon.png",
            text=self.tr(f"PCA Evaluation Trench Generator - QGIS Plugin version {self.plugin_version}"),
            callback=self.noop,
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/trench_generator_icon.png",
            text=self.tr("Generate the evaluation trenches"),
            callback=self.generate_trenches,
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/trench_counterclock_rotation_icon.png",
            text=self.tr("Rotate the trench counterclockwise"),
            callback=self.rotateTrench_counterclockwise,
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/trench_clock_rotation_icon.png",
            text=self.tr("Rotate the trench clockwise"),
            callback=self.rotateTrench_clockwise,
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/trench_route_numbers_icon.png",
            text=self.tr("Update the trench numeration according to a path"),
            callback=self.routeNumeration,
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/trench_points_icon.png",
            text=self.tr("Generate stake out points"),
            callback=self.generate_stakeout_points,
            parent=self.iface.mainWindow(),
        )

        self.add_action(
            icon_path=":/plugins/eval_trench_gener/icons/trench_CSV_icon.png",
            text=self.tr("Generate CSV file for stake out"),
            callback=self.generateCSV,
            parent=self.iface.mainWindow(),
        )

    def unload(self):
        """Remove plugin actions from the QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.toolbar.removeAction(action)

        self.actions.clear()

    def noop(self):
        """Dummy callback for logo/version button."""
        return None

    def _exec_dialog(self, dialog):
        """Run a dialog in a way compatible with Qt5/QGIS 3 and Qt6/QGIS 4."""
        if hasattr(dialog, "exec"):
            return dialog.exec()
        return dialog.exec_()

    def _apply_dialog_style(self, dialog):
        """Apply shared QSS style to any plugin dialog."""
        style_path = os.path.join(self.plugin_dir, "styles", "dialogs.qss")

        if not os.path.exists(style_path):
            self._log(f"Dialog style file not found: {style_path}", Qgis.Warning)
            return

        try:
            with open(style_path, "r", encoding="utf-8") as style_file:
                dialog.setStyleSheet(style_file.read())
        except Exception as error:
            self._log(f"Could not apply dialog style: {error}", Qgis.Warning)

    # ------------------------------------------------------------------
    # Messaging and logging
    # ------------------------------------------------------------------

    def _log(self, message: str, level=Qgis.Info):
        """Write to QGIS message log."""
        QgsMessageLog.logMessage(str(message), self.LOG_TAG, level)

    def _info(self, message: str):
        QMessageBox.information(self.iface.mainWindow(), self.PLUGIN_TITLE, message)

    def _warning(self, message: str):
        QMessageBox.warning(self.iface.mainWindow(), self.PLUGIN_TITLE, message)

    def _critical(self, message: str):
        QMessageBox.critical(self.iface.mainWindow(), self.PLUGIN_TITLE, message)

    def _bar_info(self, message: str, duration: int = 5):
        self.iface.messageBar().pushMessage(
            self.PLUGIN_TITLE,
            message,
            level=Qgis.Info,
            duration=duration,
        )

    def _bar_warning(self, message: str, duration: int = 5):
        self.iface.messageBar().pushMessage(
            self.PLUGIN_TITLE,
            message,
            level=Qgis.Warning,
            duration=duration,
        )

    def _progress(self, title: str, maximum: int) -> QProgressDialog:
        """Create a modal progress dialog for longer tasks."""
        progress = QProgressDialog(
            title,
            "Cancel",
            0,
            max(1, maximum),
            self.iface.mainWindow(),
        )
        progress.setWindowTitle(self.PLUGIN_TITLE)
        progress.setMinimumDuration(500)
        progress.setAutoClose(True)
        progress.setAutoReset(True)
        return progress

    # ------------------------------------------------------------------
    # Layer and output helpers
    # ------------------------------------------------------------------

    def _fallback_crs(self) -> QgsCoordinateReferenceSystem:
        return QgsCoordinateReferenceSystem(self.defaults.fallback_crs_authid)

    def _layer_crs_or_fallback(self, layer: Optional[QgsVectorLayer]) -> QgsCoordinateReferenceSystem:
        if layer is not None and layer.crs().isValid():
            return layer.crs()
        return self._fallback_crs()

    def _crs_uri(self, crs: QgsCoordinateReferenceSystem) -> str:
        authid = crs.authid()
        return authid if authid else self.defaults.fallback_crs_authid

    def _vector_layers(self, geometry_type: Optional[QgsWkbTypes.GeometryType] = None) -> List[QgsVectorLayer]:
        """Return project vector layers, optionally filtered by geometry type."""
        layers = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() != QgsMapLayer.VectorLayer:
                continue
            if geometry_type is not None and layer.geometryType() != geometry_type:
                continue
            layers.append(layer)
        return layers

    def _populate_combo_with_layers(self, combo_box, geometry_type: QgsWkbTypes.GeometryType, empty_message: str):
        """Populate a standard QComboBox with vector layer names."""
        combo_box.clear()
        layers = self._vector_layers(geometry_type)
        combo_box.addItems([layer.name() for layer in layers])

        if not layers:
            self._bar_warning(empty_message)

    def _get_layer_by_name(self, layer_name: str, geometry_type: Optional[QgsWkbTypes.GeometryType] = None) -> Optional[QgsVectorLayer]:
        """Safely retrieve a vector layer by name and optional geometry type."""
        if not layer_name:
            return None

        matches = QgsProject.instance().mapLayersByName(layer_name)
        if not matches:
            return None

        layer = matches[0]
        if layer.type() != QgsMapLayer.VectorLayer:
            return None

        if geometry_type is not None and layer.geometryType() != geometry_type:
            return None

        return layer

    def _style_path(self, filename: str) -> str:
        return os.path.join(self.plugin_dir, "qml", filename)

    def _project_is_saved(self) -> bool:
        return bool(QgsProject.instance().fileName())

    def _project_output_folder(self) -> str:
        """
        Return/create the project Shapefiles folder.

        Output layers are saved as ESRI Shapefiles in a Shapefiles subfolder
        inside the QGIS project home folder.
        """
        folder = os.path.join(QgsProject.instance().homePath(), self.defaults.output_folder_name)
        os.makedirs(folder, exist_ok=True)
        return folder

    def _clean_output_base_name(self, name: str, fallback: str) -> str:
        """Return a safe Shapefile base name."""
        cleaned = "".join(
            char if char.isalnum() or char in ("_", "-") else "_"
            for char in str(name).strip()
        )

        cleaned = cleaned.strip("_")

        if not cleaned:
            cleaned = fallback

        return cleaned

    def _next_available_path(self, folder: str, base_name: str, extension: str) -> Tuple[str, str]:
        """Return a filename/path that does not already exist, using 01, 02, etc."""
        os.makedirs(folder, exist_ok=True)

        base_name = self._clean_output_base_name(base_name, self.defaults.trench_layer_base_name)

        counter = 0
        while True:
            suffix = "" if counter == 0 else f"_{counter:02d}"
            filename = f"{base_name}{suffix}{extension}"
            path = os.path.join(folder, filename)

            if not os.path.exists(path):
                return filename, path

            counter += 1

    def _stakeout_base_name_from_loe_layer(self, loe_layer: QgsVectorLayer) -> str:
        """Build stake-out point layer name from selected LOE layer name."""
        loe_name = os.path.splitext(loe_layer.name())[0]

        return self._clean_output_base_name(
            f"{loe_name}_SO_pt",
            self.defaults.stakeout_layer_base_name,
        )

    def _ask_output_layer_name(self, default_name: str) -> Optional[str]:
        """Ask the user for an output Shapefile name."""
        name, accepted = QInputDialog.getText(
            self.iface.mainWindow(),
            self.PLUGIN_TITLE,
            "Enter output file name:",
            text=default_name,
        )

        if not accepted:
            return None

        return self._clean_output_base_name(name, default_name)
        
    def _new_memory_layer(self, geometry: str, name: str, crs: QgsCoordinateReferenceSystem) -> QgsVectorLayer:
        """Create a memory vector layer with the requested geometry and CRS."""
        crs_part = self._crs_uri(crs)
        return QgsVectorLayer(f"{geometry}?crs={crs_part}", name, "memory")

    def _save_layer_to_shapefile(self, layer: QgsVectorLayer, output_path: str) -> bool:
        """
        Save a vector layer to ESRI Shapefile.

        Uses QgsVectorFileWriter.writeAsVectorFormatV3(), which is the current
        non-deprecated writer API for QGIS 3.20+ and QGIS 4.
        """
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "ESRI Shapefile"
        options.fileEncoding = "UTF-8"

        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            output_path,
            QgsProject.instance().transformContext(),
            options,
        )

        error_code = result[0]
        error_message = result[3] if len(result) > 3 else "Unknown writer error."

        if error_code != QgsVectorFileWriter.NoError:
            self._critical(f"Could not save output layer:\n{error_message}")
            self._log(f"Layer save failed: {error_message}", Qgis.Critical)
            return False

        return True

    def _load_shapefile_layer(self, output_path: str, display_name: str) -> Optional[QgsVectorLayer]:
        """Load a Shapefile layer from disk."""
        layer = QgsVectorLayer(output_path, display_name, "ogr")

        if not layer.isValid():
            self._critical("The output was created but could not be loaded into QGIS.")
            self._log(f"Could not load Shapefile from {output_path}", Qgis.Critical)
            return None

        return layer

    def _add_layer_to_mapping_group(self, layer: QgsVectorLayer):
        """Move layer into the Mapping group if that group exists."""
        if layer is None or not layer.isValid():
            return

        root = QgsProject.instance().layerTreeRoot()
        node = root.findLayer(layer.id())
        mapping_group = root.findGroup("Mapping")

        if node is None or mapping_group is None:
            return

        clone = node.clone()
        mapping_group.insertChildNode(1, clone)

        parent = node.parent()
        if parent is not None:
            parent.removeChildNode(node)

        clone.setExpanded(True)

    def _ensure_fields(self, layer: QgsVectorLayer, fields: Sequence[QgsField]) -> bool:
        """Add missing fields to a vector layer.

        Returns True when all fields are present/created.
        """
        existing_names = {field.name() for field in layer.fields()}
        missing = [field for field in fields if field.name() not in existing_names]

        if not missing:
            return True

        provider = layer.dataProvider()
        if not provider.addAttributes(missing):
            self._critical("Could not add required fields to the selected layer.")
            return False

        layer.updateFields()
        return True

    # ------------------------------------------------------------------
    # Geometry helpers
    # ------------------------------------------------------------------

    def _layer_total_area(self, polygon_layer: QgsVectorLayer) -> float:
        """Return total area of all valid polygon geometries."""
        total = 0.0
        for feature in polygon_layer.getFeatures():
            geometry = feature.geometry()
            if geometry and not geometry.isNull() and not geometry.isEmpty():
                total += geometry.area()
        return total

    def _combined_layer_geometry(self, layer: QgsVectorLayer) -> Optional[QgsGeometry]:
        """Combine all feature geometries from a layer into one geometry."""
        combined = None

        for feature in layer.getFeatures():
            geometry = feature.geometry()
            if geometry is None or geometry.isNull() or geometry.isEmpty():
                continue

            if combined is None:
                combined = QgsGeometry(geometry)
            else:
                combined = combined.combine(geometry)

        return combined

    def _create_trench_polygon(
        self,
        centre_point: QgsPointXY,
        trench_length: float,
        trench_width: float,
        angle_degrees: float = 0.0
    ) -> QgsGeometry:
        """Create a rotated rectangular trench polygon around a centre point."""
        x = centre_point.x()
        y = centre_point.y()

        half_length = trench_length / 2.0
        half_width = trench_width / 2.0

        # Rectangle aligned along Y axis before rotation
        local_points = [
            (-half_width,  half_length),
            ( half_width,  half_length),
            ( half_width, -half_length),
            (-half_width, -half_length),
            (-half_width,  half_length),
        ]

        angle = math.radians(angle_degrees)
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)

        rotated_points = []
        for px, py in local_points:
            rx = x + (px * cos_a - py * sin_a)
            ry = y + (px * sin_a + py * cos_a)
            rotated_points.append(QgsPointXY(rx, ry))

        return QgsGeometry.fromPolygonXY([rotated_points])

    def _generate_candidate_points_in_polygon(self, polygon_geometry: QgsGeometry, count: int, spacing_hint: float) -> List[QgsPointXY]:
        """
        Generate evenly distributed trench centre points using a rotated staggered grid.

        The method tests several grid orientations and keeps the one that gives
        the best internal point coverage. This gives a more regular trench
        distribution than the previous simple grid/filter approach, especially
        inside irregular site boundary polygons.
        """
        if polygon_geometry is None or polygon_geometry.isNull() or polygon_geometry.isEmpty():
            return []

        count = max(1, int(count))
        spacing = max(float(spacing_hint), 1.0)

        centre_geometry = polygon_geometry.centroid()
        if centre_geometry is None or centre_geometry.isNull() or centre_geometry.isEmpty():
            return []

        centre = QgsPointXY(centre_geometry.asPoint())

        # 0-90 degrees is enough for a repeating grid pattern.
        # Smaller steps give better fitting but take slightly longer.
        candidate_angles = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]

        best_points = []
        best_score = -1

        for angle in candidate_angles:
            rotated_polygon = QgsGeometry(polygon_geometry)
            rotated_polygon.rotate(angle, centre)

            rotated_points = self._generate_staggered_points_for_geometry(
                rotated_polygon,
                spacing,
            )

            if not rotated_points:
                continue

            # Rotate points back to the original geometry space and keep only
            # points that are still inside the original polygon.
            final_points = []
            for point in rotated_points:
                final_point = self._rotate_point(point, centre, -angle)

                if polygon_geometry.contains(QgsGeometry.fromPointXY(final_point)):
                    final_points.append(final_point)

            # Prefer orientations that can provide the requested number of
            # points. If several can, prefer the one with more candidates,
            # because it gives the selector better spatial options.
            score = min(len(final_points), count) * 100000 + len(final_points)

            if score > best_score:
                best_score = score
                best_points = final_points

        if not best_points:
            return []

        return self._select_evenly_spread_points(best_points, count)

    def _generate_staggered_points_for_geometry(
        self,
        polygon_geometry: QgsGeometry,
        spacing: float,
    ) -> List[QgsPointXY]:
        """
        Generate staggered grid points inside a polygon geometry.

        This is a hex-like grid: alternate rows are offset by half spacing.
        It produces cleaner and more uniform distribution than random points
        or a simple square grid.
        """
        if polygon_geometry is None or polygon_geometry.isNull() or polygon_geometry.isEmpty():
            return []

        bbox = polygon_geometry.boundingBox()

        if bbox.width() <= 0 or bbox.height() <= 0:
            return []

        dx = max(spacing, 1.0)
        dy = dx * math.sqrt(3) / 2.0

        points = []
        row = 0
        y = bbox.yMinimum()

        while y <= bbox.yMaximum():
            offset = dx / 2.0 if row % 2 else 0.0
            x = bbox.xMinimum() + offset

            while x <= bbox.xMaximum():
                point = QgsPointXY(x, y)
                point_geom = QgsGeometry.fromPointXY(point)

                if polygon_geometry.contains(point_geom):
                    points.append(point)

                x += dx

            y += dy
            row += 1

        return points

    def _rotate_point(self, point: QgsPointXY, centre: QgsPointXY, angle_degrees: float) -> QgsPointXY:
        """Rotate a point around a centre point using plain Python math."""
        angle_radians = math.radians(angle_degrees)
        cos_a = math.cos(angle_radians)
        sin_a = math.sin(angle_radians)

        translated_x = point.x() - centre.x()
        translated_y = point.y() - centre.y()

        rotated_x = translated_x * cos_a - translated_y * sin_a
        rotated_y = translated_x * sin_a + translated_y * cos_a

        return QgsPointXY(rotated_x + centre.x(), rotated_y + centre.y())

    def _select_evenly_spread_points(self, points: List[QgsPointXY], count: int) -> List[QgsPointXY]:
        """
        Select the requested number of points while keeping them spread out.

        The candidate points are sorted spatially before sampling. This avoids
        selecting only one side of the generated grid when too many candidate
        points are available.
        """
        if not points:
            return []

        count = max(1, int(count))

        if len(points) <= count:
            return points

        if count == 1:
            return [points[len(points) // 2]]

        # Sort by Y then X so the down-sampling walks through the full grid
        # instead of following the raw generation order too closely.
        ordered_points = sorted(points, key=lambda point: (point.y(), point.x()))

        selected = []
        used_indexes = set()
        step = (len(ordered_points) - 1) / float(count - 1)

        for i in range(count):
            index = int(round(i * step))
            if index not in used_indexes:
                selected.append(ordered_points[index])
                used_indexes.add(index)

        return selected[:count]

    def _single_line_geometry_from_layer(self, line_layer: QgsVectorLayer) -> Optional[QgsGeometry]:
        """Return the first valid line geometry from a line layer."""
        for feature in line_layer.getFeatures():
            geometry = feature.geometry()
            if geometry is not None and not geometry.isNull() and not geometry.isEmpty():
                return QgsGeometry(geometry)
        return None

    def _polygon_boundary_segments(self, polygon_geometry: QgsGeometry) -> List[Tuple[QgsPointXY, QgsPointXY, float]]:
        """Return all polygon boundary segments as start/end/length tuples."""
        if polygon_geometry is None or polygon_geometry.isNull() or polygon_geometry.isEmpty():
            return []

        segments = []
        polygons = polygon_geometry.asMultiPolygon() if polygon_geometry.isMultipart() else [polygon_geometry.asPolygon()]

        for polygon in polygons:
            for ring in polygon:
                if len(ring) < 2:
                    continue

                for i in range(len(ring) - 1):
                    start = QgsPointXY(ring[i])
                    end = QgsPointXY(ring[i + 1])
                    length = math.hypot(end.x() - start.x(), end.y() - start.y())
                    if length > 0:
                        segments.append((start, end, length))

        return segments

    def _point_along_segment(self, start: QgsPointXY, end: QgsPointXY, distance_from_start: float) -> QgsPointXY:
        """Return a point at a distance along a segment."""
        total_length = math.hypot(end.x() - start.x(), end.y() - start.y())
        if total_length <= 0:
            return QgsPointXY(start)

        ratio = max(0.0, min(1.0, distance_from_start / total_length))
        x = start.x() + (end.x() - start.x()) * ratio
        y = start.y() + (end.y() - start.y()) * ratio
        return QgsPointXY(x, y)

    def _distance_along_route(self, route_geometry: QgsGeometry, point_geometry: QgsGeometry) -> Optional[float]:
        """Return distance along route to the point projection."""
        if route_geometry is None or route_geometry.isNull() or route_geometry.isEmpty():
            return None
        if point_geometry is None or point_geometry.isNull() or point_geometry.isEmpty():
            return None

        distance = route_geometry.lineLocatePoint(point_geometry)
        if distance is None or distance < 0:
            return None
        return distance

    # ------------------------------------------------------------------
    # Dialog setup helpers
    # ------------------------------------------------------------------

    def get_sb_layer(self):
        self._populate_combo_with_layers(
            self.dlg.sb_comboBox,
            QgsWkbTypes.PolygonGeometry,
            "No polygon layers available. Please add a valid site boundary layer and retry.",
        )

    def get_route_layer(self):
        self._populate_combo_with_layers(
            self.route_dlg.routelayer_comboBox,
            QgsWkbTypes.LineGeometry,
            "No line layers available. Please add a valid route layer and retry.",
        )

    def get_loe_layer(self, dialog):
        self._populate_combo_with_layers(
            dialog.trenchLOE_layer_comboBox,
            QgsWkbTypes.PolygonGeometry,
            "No polygon layers available. Please add a valid LOE layer and retry.",
        )

    def check_trench_calc_type_number(self):
        self.dlg.tr_num_spinBox.setEnabled(True)
        self.dlg.tr_no_label.setEnabled(True)
        self.dlg.tr_area_perc_spinBox_2.setEnabled(False)
        self.dlg.tr_area_label.setEnabled(False)
        self.dlg.sb_layer_label.setEnabled(True)
        self.dlg.sb_comboBox.setEnabled(True)
        self.dlg.button_box.setEnabled(True)

    def check_trench_calc_type_area(self):
        self.dlg.tr_num_spinBox.setEnabled(False)
        self.dlg.tr_no_label.setEnabled(False)
        self.dlg.tr_area_perc_spinBox_2.setEnabled(True)
        self.dlg.tr_area_label.setEnabled(True)
        self.dlg.sb_layer_label.setEnabled(True)
        self.dlg.sb_comboBox.setEnabled(True)
        self.dlg.button_box.setEnabled(True)

    def check_eval_site(self):
        self.stakeout_dlg.trenchLOE_layer_comboBox.setEnabled(True)
        self.stakeout_dlg.button_box.setEnabled(True)
        self.stakeout_dlg.LOE_label.setEnabled(True)
        self.stakeout_dlg.LOE_label.setText("Trench LOE layer")

    def check_exc_site(self):
        self.stakeout_dlg.trenchLOE_layer_comboBox.setEnabled(True)
        self.stakeout_dlg.button_box.setEnabled(True)
        self.stakeout_dlg.LOE_label.setEnabled(True)
        self.stakeout_dlg.LOE_label.setText("Excavation LOE layer")

    def check_csv_type_site(self):
        self.csv_dlg.label.setEnabled(True)
        self.csv_dlg.label_2.setEnabled(True)
        self.csv_dlg.label_4.setEnabled(True)
        self.csv_dlg.so_point_first_num_spinBox.setEnabled(True)
        self.csv_dlg.stakeout_points_layer_comboBox.setEnabled(True)
        self.csv_dlg.stakeout_survey_path_layer_comboBox.setEnabled(True)
        self.csv_dlg.button_box.setEnabled(True)

    # ------------------------------------------------------------------
    # Main tool: generate trenches
    # ------------------------------------------------------------------

    def generate_trenches(self):
        """Generate rectangular evaluation trench LOE polygons."""
        if self.dlg is None:
            self.dlg = EvalTrenchGeneratorDialog()
            self._apply_dialog_style(self.dlg)
            self.dlg.trench_by_number_checkBox.stateChanged.connect(self.check_trench_calc_type_number)
            self.dlg.trench_by_area_checkBox.stateChanged.connect(self.check_trench_calc_type_area)
            self.dlg.add_empty_layer_pushButton.clicked.connect(self.add_empty_LOE_layer)

        self.get_sb_layer()

        self.dlg.tr_num_spinBox.setEnabled(False)
        self.dlg.tr_area_perc_spinBox_2.setEnabled(False)
        self.dlg.tr_no_label.setEnabled(False)
        self.dlg.tr_area_label.setEnabled(False)
        self.dlg.sb_layer_label.setEnabled(False)
        self.dlg.sb_comboBox.setEnabled(False)
        self.dlg.button_box.setEnabled(False)

        self.dlg.show()
        if not self._exec_dialog(self.dlg):
            return

        trench_length = self.dlg.tr_l_doubleSpinBox.value()
        trench_width = self.dlg.tr_w_doubleSpinBox.value()
        trench_by_number = self.dlg.tr_num_spinBox.value()
        area_to_cover_percentage = self.dlg.tr_area_perc_spinBox_2.value()
        by_number = self.dlg.trench_by_number_checkBox.isChecked()
        by_area = self.dlg.trench_by_area_checkBox.isChecked()
        site_boundary_name = self.dlg.sb_comboBox.currentText()

        if trench_length <= 0 or trench_width <= 0:
            self._warning("Trench length and width must be greater than zero.")
            return

        if by_number == by_area:
            self._warning("Please select only one method: number of trenches or percentage of area.")
            return

        site_boundary_layer = self._get_layer_by_name(site_boundary_name, QgsWkbTypes.PolygonGeometry)
        if site_boundary_layer is None:
            self._warning("No valid site boundary polygon layer was selected.")
            return

        if site_boundary_layer.featureCount() == 0:
            self._warning("The selected site boundary layer is empty. Draw a valid site boundary and retry.")
            return

        crs = self._layer_crs_or_fallback(site_boundary_layer)
        site_area = self._layer_total_area(site_boundary_layer)
        trench_area = trench_length * trench_width

        if site_area <= 0:
            self._warning("The selected site boundary has no valid polygon area.")
            return

        trench_count = int(trench_by_number) if by_number else max(
            1,
            int(round((site_area * (area_to_cover_percentage / 100.0)) / trench_area)),
        )

        if trench_count <= 0:
            self._warning("The calculated number of trenches is zero. Please check the input values.")
            return

        progress = self._progress("Generating trenches...", trench_count + 4)
        progress.setValue(0)

        try:
            combined_boundary = self._combined_layer_geometry(site_boundary_layer)
            progress.setValue(1)
            if progress.wasCanceled():
                return

            if combined_boundary is None or combined_boundary.isNull() or combined_boundary.isEmpty():
                self._warning("Could not create a valid combined site boundary geometry.")
                return

            inward_boundary = combined_boundary.buffer(self.defaults.inward_boundary_buffer, 8)
            progress.setValue(2)

            if inward_boundary is None or inward_boundary.isNull() or inward_boundary.isEmpty():
                self._warning(
                    "The inward 10 m buffer is empty. The site boundary may be too small for the selected trench settings."
                )
                return

            spacing_hint = max(trench_length, trench_width) * 1.2
            centre_points = self._generate_candidate_points_in_polygon(inward_boundary, trench_count, spacing_hint)
            progress.setValue(3)

            if not centre_points:
                self._warning("Could not generate valid trench positions inside the site boundary.")
                return

            if len(centre_points) < trench_count:
                self._bar_warning(
                    f"Only {len(centre_points)} suitable trench positions could be generated from the requested {trench_count}.",
                    duration=8,
                )

            layer_name = self.defaults.trench_layer_base_name
            output_path = None

            if self._project_is_saved():
                requested_name = self._ask_output_layer_name(self.defaults.trench_layer_base_name)

                if requested_name is None:
                    self._bar_warning("Trench generation cancelled.")
                    return

                folder = self._project_output_folder()
                filename, output_path = self._next_available_path(folder, requested_name, ".shp")
                layer_name = os.path.splitext(filename)[0]

            trench_layer = self._new_memory_layer("Polygon", layer_name, crs)
            provider = trench_layer.dataProvider()
            provider.addAttributes([
                QgsField("id", QVariant.Int),
                QgsField("loe_no", QVariant.Int),
                QgsField("surv_type", QVariant.String, len=254),
                QgsField("surv_notes", QVariant.String, len=254),
            ])
            trench_layer.updateFields()

            features = []
            for index, point in enumerate(centre_points, start=1):
                if progress.wasCanceled():
                    self._bar_warning("Trench generation cancelled.")
                    return

                angle = 0 if index % 2 else 90
                geometry = self._create_trench_polygon(
                    point,
                    trench_length,
                    trench_width,
                    angle
)
                feature = QgsFeature(trench_layer.fields())
                feature.setGeometry(geometry)
                feature.setAttributes([index, 0, "trench", ""])
                features.append(feature)
                progress.setValue(min(progress.maximum(), 3 + index))

            provider.addFeatures(features)
            trench_layer.updateExtents()

            if output_path:
                if not self._save_layer_to_shapefile(trench_layer, output_path):
                    return
                final_layer = self._load_shapefile_layer(output_path, layer_name)
                if final_layer is None:
                    return
            else:
                final_layer = trench_layer

            QgsProject.instance().addMapLayer(final_layer)
            final_layer.loadNamedStyle(self._style_path("Trench_LOE_style_2026.qml"))
            final_layer.triggerRepaint()
            self.iface.mapCanvas().refresh()

            progress.setValue(progress.maximum())

            if output_path:
                self._info(f"{len(features)} trenches successfully added to the map.\n\nOutput:\n{output_path}")
            else:
                self._warning(
                    "Trench_LOE temporary layer successfully added to the map.<br><br>"
                    "<b>Warning:</b> this layer is temporary and will be deleted when the project is closed. "
                    "Save it to disk if you want to preserve the data."
                )

        except Exception as error:
            self._log(f"Trench generation failed: {error}", Qgis.Critical)
            self._critical(f"Trench generation failed:\n{error}")

    # ------------------------------------------------------------------
    # Rotation tools
    # ------------------------------------------------------------------

    def rotate_selected_trenches(self, angle: float):
        """Rotate selected polygon features in the active layer."""
        layer = self.iface.activeLayer()

        if layer is None:
            self._warning("No active layer selected.")
            return

        if layer.type() != QgsMapLayer.VectorLayer:
            self._warning("The active layer is not a vector layer.")
            return

        if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._warning("The active layer must be a polygon trench layer.")
            return

        selected_features = list(layer.selectedFeatures())
        if not selected_features:
            self._warning("No trench features selected.")
            return

        if not layer.isEditable() and not layer.startEditing():
            self._critical("Could not start editing on the selected layer.")
            return

        layer.beginEditCommand("Rotate Selected Trenches")

        try:
            for feature in selected_features:
                geometry = QgsGeometry(feature.geometry())
                if geometry.isNull() or geometry.isEmpty():
                    continue

                centre = geometry.centroid().asPoint()
                geometry.rotate(angle, centre)
                layer.changeGeometry(feature.id(), geometry)

            layer.endEditCommand()
            layer.triggerRepaint()
            self.iface.mapCanvas().refresh()

        except Exception as error:
            layer.destroyEditCommand()
            self._log(f"Rotation failed: {error}", Qgis.Critical)
            self._critical(f"Could not rotate selected trenches:\n{error}")

    def rotateTrench_counterclockwise(self):
        self.rotate_selected_trenches(-10)

    def rotateTrench_clockwise(self):
        self.rotate_selected_trenches(10)

    # ------------------------------------------------------------------
    # Route numbering
    # ------------------------------------------------------------------

    def routeNumeration(self):
        """Update trench LOE numbers according to their order along a route line."""
        if self.route_dlg is None:
            self.route_dlg = EvalTrenchRouteNumbersDialog()
            self._apply_dialog_style(self.route_dlg)

        self.get_route_layer()
        self.get_loe_layer(self.route_dlg)

        self.route_dlg.show()
        if not self._exec_dialog(self.route_dlg):
            return

        first_number = self.route_dlg.tr_first_num_spinBox.value()
        route_layer_name = self.route_dlg.routelayer_comboBox.currentText()
        loe_layer_name = self.route_dlg.trenchLOE_layer_comboBox.currentText()

        route_layer = self._get_layer_by_name(route_layer_name, QgsWkbTypes.LineGeometry)
        loe_layer = self._get_layer_by_name(loe_layer_name, QgsWkbTypes.PolygonGeometry)

        if route_layer is None:
            self._warning("No valid route line layer was selected.")
            return

        if loe_layer is None:
            self._warning("No valid trench LOE polygon layer was selected.")
            return

        route_geometry = self._single_line_geometry_from_layer(route_layer)
        if route_geometry is None:
            self._warning("The route layer does not contain any valid line. Draw the numbering route and retry.")
            return

        required_fields = [
            QgsField("id", QVariant.Int),
            QgsField("loe_no", QVariant.Int),
            QgsField("surv_type", QVariant.String, len=254),
            QgsField("surv_notes", QVariant.String, len=254),
        ]
        if not self._ensure_fields(loe_layer, required_fields):
            return

        sortable = []
        for feature in loe_layer.getFeatures():
            geometry = feature.geometry()
            if geometry is None or geometry.isNull() or geometry.isEmpty():
                continue

            centre_geom = geometry.centroid()
            distance = self._distance_along_route(route_geometry, centre_geom)
            if distance is not None:
                sortable.append((distance, feature.id()))

        if not sortable:
            self._warning("No trench features could be located along the selected route.")
            return

        sortable.sort(key=lambda item: item[0])

        loe_no_idx = loe_layer.fields().indexFromName("loe_no")
        if loe_no_idx < 0:
            self._critical("The loe_no field could not be created or found.")
            return

        try:
            with edit(loe_layer):
                for offset, (_, feature_id) in enumerate(sortable):
                    loe_layer.changeAttributeValue(feature_id, loe_no_idx, first_number + offset)
        except Exception as error:
            self._log(f"Route numbering failed: {error}", Qgis.Critical)
            self._critical(f"Route numbering failed:\n{error}")
            return

        loe_layer.triggerRepaint()
        self.iface.mapCanvas().refresh()
        self._info(f"Updated numbering for {len(sortable)} trench features.")

    # ------------------------------------------------------------------
    # Stake-out point generation
    # ------------------------------------------------------------------

    def _order_eval_stakeout_points_by_trench_route(self, trench_points: List[Dict]) -> List[Dict]:
        """
        Order evaluation stake-out points by trench number and shortest route.

        Expected input item:
        {
            "loe_no": int,
            "point": QgsPointXY
        }

        Logic:
        - Start from the lowest loe_no, normally trench 1.
        - For each trench, choose the point closest to the previous point.
        - Add the second point of the same trench immediately after.
        - Move to the next trench number and repeat.
        """
        if not trench_points:
            return []

        grouped = {}

        for item in trench_points:
            loe_no = item.get("loe_no")

            if loe_no is None:
                continue

            try:
                loe_no = int(loe_no)
            except (TypeError, ValueError):
                continue

            grouped.setdefault(loe_no, []).append(item)

        if not grouped:
            return trench_points

        ordered = []
        previous_point = None

        for loe_no in sorted(grouped.keys()):
            points_for_trench = grouped[loe_no]

            if not points_for_trench:
                continue

            if previous_point is None:
                # First trench: start from the point with lowest Y, then lowest X.
                points_for_trench.sort(
                    key=lambda item: (item["point"].y(), item["point"].x())
                )
            else:
                # Next trench: start from the point closest to previous trench.
                points_for_trench.sort(
                    key=lambda item: self._point_distance(previous_point, item["point"])
                )

            for item in points_for_trench:
                ordered.append(item)

            previous_point = ordered[-1]["point"]

        return ordered

    def _point_distance(self, point_a: QgsPointXY, point_b: QgsPointXY) -> float:
        """Return straight-line distance between two QgsPointXY objects."""
        return math.hypot(
            point_a.x() - point_b.x(),
            point_a.y() - point_b.y(),
        )

    def generate_stakeout_points(self):
        """Generate stake-out points from evaluation or excavation LOE polygons."""
        if self.stakeout_dlg is None:
            self.stakeout_dlg = EvalTrenchGenerateStakeOutPointsDialog()
            self._apply_dialog_style(self.stakeout_dlg)
            self.stakeout_dlg.eval_checkBox.stateChanged.connect(self.check_eval_site)
            self.stakeout_dlg.excavation_checkBox.stateChanged.connect(self.check_exc_site)

        self.get_loe_layer(self.stakeout_dlg)

        self.stakeout_dlg.trenchLOE_layer_comboBox.setEnabled(False)
        self.stakeout_dlg.button_box.setEnabled(False)
        self.stakeout_dlg.LOE_label.setText("LOE layer")
        self.stakeout_dlg.LOE_label.setEnabled(False)

        self.stakeout_dlg.show()
        if not self._exec_dialog(self.stakeout_dlg):
            return

        is_eval = self.stakeout_dlg.eval_checkBox.isChecked()
        is_excavation = self.stakeout_dlg.excavation_checkBox.isChecked()

        if is_eval == is_excavation:
            self._warning("Please select either Evaluation or Excavation.")
            return

        loe_layer_name = self.stakeout_dlg.trenchLOE_layer_comboBox.currentText()
        loe_layer = self._get_layer_by_name(loe_layer_name, QgsWkbTypes.PolygonGeometry)

        if loe_layer is None:
            self._warning("No valid LOE polygon layer was selected.")
            return

        crs = self._layer_crs_or_fallback(loe_layer)

        base_name = self._stakeout_base_name_from_loe_layer(loe_layer)
        layer_name = base_name
        output_path = None

        if self._project_is_saved():
            folder = self._project_output_folder()
            filename, output_path = self._next_available_path(folder, base_name, ".shp")
            layer_name = os.path.splitext(filename)[0]

        point_layer = self._new_memory_layer("Point", layer_name, crs)
        provider = point_layer.dataProvider()
        provider.addAttributes([
            QgsField("id", QVariant.Int),
            QgsField("X", QVariant.Double),
            QgsField("Y", QVariant.Double),
        ])
        point_layer.updateFields()

        total_features = max(1, loe_layer.featureCount())
        progress = self._progress("Generating stake-out points...", total_features)

        features = []

        try:
            eval_point_items = []
            excavation_points = []

            has_loe_no = "loe_no" in loe_layer.fields().names()

            for feature_index, polygon_feature in enumerate(loe_layer.getFeatures(), start=1):
                if progress.wasCanceled():
                    self._bar_warning("Stake-out point generation cancelled.")
                    return

                polygon_geometry = polygon_feature.geometry()
                if polygon_geometry is None or polygon_geometry.isNull() or polygon_geometry.isEmpty():
                    progress.setValue(feature_index)
                    continue

                segments = self._polygon_boundary_segments(polygon_geometry)
                if not segments:
                    progress.setValue(feature_index)
                    continue

                if is_eval:
                    loe_no = polygon_feature["loe_no"] if has_loe_no else polygon_feature.id()

                    if loe_no is None or loe_no == "":
                        loe_no = polygon_feature.id()

                    segments_sorted = sorted(segments, key=lambda item: item[2])

                    for start, end, length in segments_sorted[:2]:
                        eval_point_items.append({
                            "loe_no": loe_no,
                            "point": self._point_along_segment(start, end, length / 2.0),
                        })

                elif is_excavation:
                    for start, end, length in segments:
                        distance = 0.0

                        while distance <= length:
                            excavation_points.append(
                                self._point_along_segment(start, end, distance)
                            )
                            distance += self.defaults.excavation_point_interval

                progress.setValue(feature_index)

            if is_eval:
                ordered_items = self._order_eval_stakeout_points_by_trench_route(eval_point_items)

                for point_id, item in enumerate(ordered_items, start=1):
                    point = item["point"]

                    new_feature = QgsFeature(point_layer.fields())
                    new_feature.setGeometry(QgsGeometry.fromPointXY(point))
                    new_feature.setAttributes([point_id, point.x(), point.y()])
                    features.append(new_feature)

            elif is_excavation:
                for point_id, point in enumerate(excavation_points, start=1):
                    new_feature = QgsFeature(point_layer.fields())
                    new_feature.setGeometry(QgsGeometry.fromPointXY(point))
                    new_feature.setAttributes([point_id, point.x(), point.y()])
                    features.append(new_feature)

            if not features:
                self._warning("No stake-out points could be generated from the selected LOE layer.")
                return

            provider.addFeatures(features)
            point_layer.updateExtents()

            if output_path:
                if not self._save_layer_to_shapefile(point_layer, output_path):
                    return

                final_layer = self._load_shapefile_layer(output_path, layer_name)
                if final_layer is None:
                    return
            else:
                final_layer = point_layer

            QgsProject.instance().addMapLayer(final_layer)
            final_layer.loadNamedStyle(self._style_path("StakeOut_Points_style.qml"))
            final_layer.triggerRepaint()
            self._add_layer_to_mapping_group(final_layer)
            self.iface.mapCanvas().refresh()

            if output_path:
                self._info(f"{len(features)} stake-out points successfully added to the map.\n\nOutput:\n{output_path}")
            else:
                self._warning(
                    "StakeOut_Points temporary layer successfully added to the map.<br><br>"
                    "<b>Warning:</b> this layer is temporary and will be deleted when the project is closed. "
                    "Save it to disk if you want to preserve the data."
                )

        except Exception as error:
            self._log(f"Stake-out point generation failed: {error}", Qgis.Critical)
            self._critical(f"Stake-out point generation failed:\n{error}")

    # ------------------------------------------------------------------
    # CSV generation
    # ------------------------------------------------------------------

    def generateCSV(self):
        """Number stake-out points along a survey path and export CSV."""
        if self.csv_dlg is None:
            self.csv_dlg = EvalTrenchStakeOutRouteCSVDialog()
            self._apply_dialog_style(self.csv_dlg)
            self.csv_dlg.stakeout_points_layer_comboBox.setFilters(QgsMapLayerProxyModel.PointLayer)
            self.csv_dlg.stakeout_survey_path_layer_comboBox.setFilters(QgsMapLayerProxyModel.LineLayer)
            self.csv_dlg.evaluation_csv_check.stateChanged.connect(self.check_csv_type_site)
            self.csv_dlg.excavation_csv_check.stateChanged.connect(self.check_csv_type_site)

        self.csv_dlg.label.setEnabled(False)
        self.csv_dlg.label_2.setEnabled(False)
        self.csv_dlg.label_4.setEnabled(False)
        self.csv_dlg.so_point_first_num_spinBox.setEnabled(False)
        self.csv_dlg.stakeout_points_layer_comboBox.setEnabled(False)
        self.csv_dlg.stakeout_survey_path_layer_comboBox.setEnabled(False)
        self.csv_dlg.button_box.setEnabled(False)

        self.csv_dlg.show()
        if not self._exec_dialog(self.csv_dlg):
            return

        first_number = self.csv_dlg.so_point_first_num_spinBox.value()
        is_eval = self.csv_dlg.evaluation_csv_check.isChecked()
        is_excavation = self.csv_dlg.excavation_csv_check.isChecked()

        if is_eval == is_excavation:
            self._warning("Please select either Evaluation or Excavation CSV type.")
            return

        points_layer_name = self.csv_dlg.stakeout_points_layer_comboBox.currentText()
        route_layer_name = self.csv_dlg.stakeout_survey_path_layer_comboBox.currentText()

        points_layer = self._get_layer_by_name(points_layer_name, QgsWkbTypes.PointGeometry)
        route_layer = self._get_layer_by_name(route_layer_name, QgsWkbTypes.LineGeometry)

        if points_layer is None:
            self._warning("No valid stake-out point layer was selected.")
            return

        if route_layer is None:
            self._warning("No valid stake-out survey path layer was selected.")
            return

        route_geometry = self._single_line_geometry_from_layer(route_layer)
        if route_geometry is None:
            self._warning("The stake-out path layer does not contain any valid line. Draw the suggested survey path and retry.")
            return

        required_fields = [
            QgsField("id", QVariant.Int),
            QgsField("X", QVariant.Double),
            QgsField("Y", QVariant.Double),
        ]
        if not self._ensure_fields(points_layer, required_fields):
            return

        id_idx = points_layer.fields().indexFromName("id")
        x_idx = points_layer.fields().indexFromName("X")
        y_idx = points_layer.fields().indexFromName("Y")

        if min(id_idx, x_idx, y_idx) < 0:
            self._critical("Could not create or find required id, X and Y fields.")
            return

        sortable = []
        progress = self._progress("Preparing CSV...", max(1, points_layer.featureCount()))

        try:
            for feature_index, feature in enumerate(points_layer.getFeatures(), start=1):
                if progress.wasCanceled():
                    self._bar_warning("CSV generation cancelled.")
                    return

                geometry = feature.geometry()
                if geometry is None or geometry.isNull() or geometry.isEmpty():
                    progress.setValue(feature_index)
                    continue

                point = geometry.asPoint()
                point_geometry = QgsGeometry.fromPointXY(QgsPointXY(point))

                if is_eval and not point_geometry.buffer(self.defaults.route_match_buffer, 5).intersects(route_geometry):
                    progress.setValue(feature_index)
                    continue

                distance = self._distance_along_route(route_geometry, point_geometry)
                if distance is not None:
                    sortable.append((distance, feature.id(), point.x(), point.y()))

                progress.setValue(feature_index)

            if not sortable:
                self._warning("No stake-out points could be matched to the selected route.")
                return

            sortable.sort(key=lambda item: item[0])

            with edit(points_layer):
                for offset, (_, feature_id, x, y) in enumerate(sortable):
                    points_layer.changeAttributeValue(feature_id, id_idx, first_number + offset)
                    points_layer.changeAttributeValue(feature_id, x_idx, x)
                    points_layer.changeAttributeValue(feature_id, y_idx, y)

            points_layer.triggerRepaint()

            records = [
                {"id": first_number + offset, "X": x, "Y": y}
                for offset, (_, _, x, y) in enumerate(sortable)
            ]

            csv_layer = self._create_ordered_csv_memory_layer(records, self._layer_crs_or_fallback(points_layer))
            QgsProject.instance().addMapLayer(csv_layer)

            csv_path = None
            if self._project_is_saved():
                folder = self._project_output_folder()
                _, csv_path = self._next_available_path(folder, self.defaults.csv_base_name, ".csv")
                self._write_records_to_csv(csv_path, records)

            self.iface.mapCanvas().refresh()

            if csv_path:
                self._info(f"CSV generated successfully:\n{csv_path}")
            else:
                self._warning(
                    "Setout_CSV memory layer generated.<br><br>"
                    "<b>Warning:</b> the project is not saved, so no CSV file was written to disk."
                )

        except Exception as error:
            self._log(f"CSV generation failed: {error}", Qgis.Critical)
            self._critical(f"CSV generation failed:\n{error}")

    def _create_ordered_csv_memory_layer(self, records: Sequence[Dict[str, float]], crs: QgsCoordinateReferenceSystem) -> QgsVectorLayer:
        """Create a memory point layer containing ordered CSV records."""
        layer = self._new_memory_layer("Point", "Setout_CSV", crs)
        provider = layer.dataProvider()
        provider.addAttributes([
            QgsField("id", QVariant.Int),
            QgsField("X", QVariant.Double),
            QgsField("Y", QVariant.Double),
        ])
        layer.updateFields()

        features = []
        for record in records:
            point = QgsPointXY(record["X"], record["Y"])
            feature = QgsFeature(layer.fields())
            feature.setGeometry(QgsGeometry.fromPointXY(point))
            feature.setAttributes([record["id"], record["X"], record["Y"]])
            features.append(feature)

        provider.addFeatures(features)
        layer.updateExtents()
        return layer

    def _write_records_to_csv(self, csv_path: str, records: Sequence[Dict[str, float]]):
        """Write id/X/Y records to CSV."""
        with open(csv_path, "w", newline="", encoding="utf-8") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=["id", "X", "Y"])
            writer.writeheader()
            for record in records:
                writer.writerow(record)

    # ------------------------------------------------------------------
    # Empty LOE layer
    # ------------------------------------------------------------------

    def add_empty_LOE_layer(self):
        """Create an empty Trench LOE polygon layer."""
        crs = self._fallback_crs()
        layer_name = self.defaults.trench_layer_base_name
        output_path = None

        # If there is an active vector layer, inherit its CRS for convenience.
        active_layer = self.iface.activeLayer()
        if active_layer and active_layer.type() == QgsMapLayer.VectorLayer:
            crs = self._layer_crs_or_fallback(active_layer)

        if self._project_is_saved():
            folder = self._project_output_folder()
            filename, output_path = self._next_available_path(folder, layer_name, ".shp")
            layer_name = os.path.splitext(filename)[0]

        temp_layer = self._new_memory_layer("Polygon", layer_name, crs)
        provider = temp_layer.dataProvider()
        provider.addAttributes([
            QgsField("id", QVariant.Int),
            QgsField("loe_no", QVariant.Int),
            QgsField("surv_type", QVariant.String, len=254),
            QgsField("surv_notes", QVariant.String, len=254),
        ])
        temp_layer.updateFields()

        if output_path:
            if not self._save_layer_to_shapefile(temp_layer, output_path):
                return
            final_layer = self._load_shapefile_layer(output_path, layer_name)
            if final_layer is None:
                return
        else:
            final_layer = temp_layer

        QgsProject.instance().addMapLayer(final_layer)
        final_layer.loadNamedStyle(self._style_path("Trench_LOE_style_colour_size.qml"))
        final_layer.triggerRepaint()
        self.iface.mapCanvas().refresh()

        if output_path:
            self._info(f"Empty Trench LOE layer successfully added to the map.\n\nOutput:\n{output_path}")
        else:
            self._warning(
                "Trench_LOE temporary layer successfully added to the map.<br><br>"
                "<b>Warning:</b> this layer is temporary and will be deleted when the project is closed. "
                "Save it to disk if you want to preserve the data."
            )
