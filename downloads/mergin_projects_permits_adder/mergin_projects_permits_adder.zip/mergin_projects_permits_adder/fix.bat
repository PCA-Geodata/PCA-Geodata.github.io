@echo off
call "C:\Program Files\QGIS 3.28.8\bin\o4w_env.bat"


@echo on
pyrcc5 -o resources.py C:\Users\vpinna\AppData\Roaming\QGIS\QGIS4\profiles\PCA_Default\python\plugins\mergin_projects_permits_adder\resources.qrc

