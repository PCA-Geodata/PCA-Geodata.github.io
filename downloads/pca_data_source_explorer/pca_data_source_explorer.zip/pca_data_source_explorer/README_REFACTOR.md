# PCA Data Source Explorer 2.00

This refactor changes the plugin from a source browser into a project data manager.

## Main additions

- Dashboard with project source metrics
- Sources and Health tabs
- Duplicate source detection
- Missing and external source checks
- Risky user-local folder detection
- Active editing and read-only status
- Project/layer CRS comparison
- GeoPackage content inspection and unused-layer reporting
- File size and last-modified metadata
- Context actions for navigation, selection, visibility, reload and repair
- HTML, CSV, Markdown and text report export
- Qt5/QGIS 3 and Qt6/QGIS 4 compatibility helpers

## Installation

Extract the `pca_data_source_explorer` folder into the active QGIS profile's `python/plugins` directory, or install the packaged ZIP through **Plugins > Manage and Install Plugins > Install from ZIP**.

## Important test note

The code has been syntax-compiled outside QGIS. It should be tested in the target QGIS versions against representative projects before production deployment, especially the missing-source repair operation and provider-specific URIs.


## Version 2.11
- Sources tree starts collapsed.
- GeoPackage tables are grouped below one main GeoPackage file node.
- Other file-based layers are grouped by their physical source file.
- Duplicate detection remains table/source-specific and starts collapsed.
