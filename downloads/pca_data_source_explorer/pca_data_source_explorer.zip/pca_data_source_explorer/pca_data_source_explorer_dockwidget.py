# -*- coding: utf-8 -*-
"""Dock interface for PCA Data Source Explorer."""

import os

from qgis.PyQt.QtCore import Qt, QTimer, QUrl, pyqtSignal
from qgis.PyQt.QtGui import QColor, QBrush, QDesktopServices, QPalette
from qgis.PyQt.QtWidgets import (
    QApplication, QAbstractItemView, QCheckBox, QDockWidget, QFileDialog,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMenu, QMessageBox,
    QPushButton, QTabWidget, QToolButton, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget
)
from qgis.core import QgsProject, QgsRectangle
from qgis.utils import iface

from .reporting import write_report
from .source_model import (
    IssueSeverity, SourceStatus, build_health_issues, collect_project_model,
    display_path, storage_label
)


class Role:
    ITEM_TYPE = 1001
    PATH = 1002
    LAYER_IDS = 1003
    SOURCE_KEY = 1004
    FILTER_TEXT = 1005
    STATUS = 1006
    URI = 1007


def _header_mode(name):
    try:
        return getattr(QHeaderView.ResizeMode, name)
    except AttributeError:
        return getattr(QHeaderView, name)


def _wait_cursor():
    try:
        return Qt.CursorShape.WaitCursor
    except AttributeError:
        return Qt.WaitCursor


def _custom_context_menu():
    try:
        return Qt.ContextMenuPolicy.CustomContextMenu
    except AttributeError:
        return Qt.CustomContextMenu


def _selection_mode(name):
    """Return a QAbstractItemView selection enum on Qt5 and Qt6."""
    try:
        return getattr(QAbstractItemView.SelectionMode, name)
    except AttributeError:
        return getattr(QAbstractItemView, name)


def _user_role():
    try:
        return int(Qt.ItemDataRole.UserRole.value)
    except AttributeError:
        return int(Qt.UserRole)


USER_ROLE = _user_role()


class PCADataSourceExplorerDockWidget(QDockWidget):
    closingPlugin = pyqtSignal()

    LIGHT_STATUS_COLOURS = {
        SourceStatus.PROJECT: ("#e7f5ea", "#183b20"),
        SourceStatus.NETWORK: ("#fff0cf", "#4a3500"),
        SourceStatus.LOCAL: ("#f9d8d8", "#561d1d"),
        SourceStatus.MISSING: ("#f5bfc3", "#591a20"),
        SourceStatus.DATABASE: ("#e8eef9", "#203554"),
        SourceStatus.SERVICE: ("#e8f4fb", "#183c53"),
        SourceStatus.MEMORY: ("#f1ecfa", "#3c2858"),
        SourceStatus.OTHER: ("#f0f0f0", "#303030"),
        IssueSeverity.ERROR: ("#f9d8d8", "#561d1d"),
        IssueSeverity.WARNING: ("#fff0cf", "#4a3500"),
        IssueSeverity.INFO: ("#e8f4fb", "#183c53"),
        IssueSeverity.OK: ("#e7f5ea", "#183b20"),
    }

    DARK_STATUS_COLOURS = {
        SourceStatus.PROJECT: ("#244a31", "#e7f5ea"),
        SourceStatus.NETWORK: ("#584316", "#fff2cf"),
        SourceStatus.LOCAL: ("#5a2929", "#ffe2e2"),
        SourceStatus.MISSING: ("#67262d", "#ffe0e3"),
        SourceStatus.DATABASE: ("#2b3d5b", "#e7efff"),
        SourceStatus.SERVICE: ("#25465a", "#e2f5ff"),
        SourceStatus.MEMORY: ("#45345c", "#f4eaff"),
        SourceStatus.OTHER: ("#404040", "#f1f1f1"),
        IssueSeverity.ERROR: ("#5a2929", "#ffe2e2"),
        IssueSeverity.WARNING: ("#584316", "#fff2cf"),
        IssueSeverity.INFO: ("#25465a", "#e2f5ff"),
        IssueSeverity.OK: ("#244a31", "#e7f5ea"),
    }


    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("PCADataSourceExplorerDockWidget")
        self.setWindowTitle("PCA Data Source Explorer")
        self.setMinimumWidth(420)
        self.model = None
        self._dark_theme = self._is_dark_theme()
        self._status_colours = self._build_status_colours()
        self.issues = []
        self._project_signals_connected = False
        self._build_ui()
        self._connect_ui()
        self._connect_project_signals()
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.setInterval(300)
        self._refresh_timer.timeout.connect(self.refresh)
        self.refresh()

    @staticmethod
    def _is_dark_theme():
        """Return True when the active Qt/QGIS palette uses a dark base."""
        palette = QApplication.palette()
        try:
            base = palette.color(QPalette.ColorRole.Base)
        except AttributeError:  # Qt5
            base = palette.color(QPalette.Base)
        return base.lightness() < 128

    def _build_status_colours(self):
        definitions = self.DARK_STATUS_COLOURS if self._dark_theme else self.LIGHT_STATUS_COLOURS
        return {
            key: (QColor(background), QColor(foreground))
            for key, (background, foreground) in definitions.items()
        }

    def _build_ui(self):
        body = QWidget(self)
        main = QVBoxLayout(body)
        main.setContentsMargins(8, 8, 8, 8)
        main.setSpacing(7)

        toolbar = QHBoxLayout()
        self.btnRefresh = QPushButton("Refresh")
        self.btnExport = QPushButton("Export report")
        self.btnExpand = QToolButton(); self.btnExpand.setText("Expand")
        self.btnCollapse = QToolButton(); self.btnCollapse.setText("Collapse")
        toolbar.addWidget(self.btnRefresh)
        toolbar.addWidget(self.btnExport)
        toolbar.addStretch(1)
        toolbar.addWidget(self.btnExpand)
        toolbar.addWidget(self.btnCollapse)
        main.addLayout(toolbar)

        self.tabs = QTabWidget()
        main.addWidget(self.tabs, 1)

        # Sources tab
        sources_page = QWidget()
        source_layout = QVBoxLayout(sources_page)
        source_layout.setContentsMargins(0, 5, 0, 0)
        self.filterEdit = QLineEdit()
        self.filterEdit.setPlaceholderText("Filter layer, file, folder, storage, provider, CRS or path…")
        source_layout.addWidget(self.filterEdit)
        options = QHBoxLayout()
        self.chkProblems = QCheckBox("Problems only")
        self.chkOutside = QCheckBox("Outside project folder only")
        options.addWidget(self.chkProblems)
        options.addWidget(self.chkOutside)
        options.addStretch(1)
        source_layout.addLayout(options)
        self.treeSources = QTreeWidget()
        self.treeSources.setHeaderLabels(["Source / Layer", "Provider", "CRS", "Storage / Status"])
        self.treeSources.setAlternatingRowColors(True)
        self.treeSources.setSelectionMode(_selection_mode("ExtendedSelection"))
        self.treeSources.setContextMenuPolicy(_custom_context_menu())
        self.treeSources.setUniformRowHeights(True)
        self.treeSources.header().setSectionResizeMode(0, _header_mode("Stretch"))
        for col in (1, 2, 3):
            self.treeSources.header().setSectionResizeMode(col, _header_mode("ResizeToContents"))
        source_layout.addWidget(self.treeSources, 1)
        self.tabs.addTab(sources_page, "Sources")

        # Duplicates tab
        duplicates_page = QWidget()
        duplicates_layout = QVBoxLayout(duplicates_page)
        duplicates_layout.setContentsMargins(0, 5, 0, 0)
        duplicates_help = QLabel("Only layers pointing to the exact same data source are shown. Different tables in the same GeoPackage are not treated as duplicates.")
        duplicates_help.setWordWrap(True)
        duplicates_layout.addWidget(duplicates_help)
        self.duplicateFilter = QLineEdit()
        self.duplicateFilter.setPlaceholderText("Filter duplicated layer names or source paths…")
        duplicates_layout.addWidget(self.duplicateFilter)
        self.treeDuplicates = QTreeWidget()
        self.treeDuplicates.setHeaderLabels(["Duplicated source / Layer", "Provider", "CRS", "Details"])
        self.treeDuplicates.setAlternatingRowColors(True)
        self.treeDuplicates.setContextMenuPolicy(_custom_context_menu())
        self.treeDuplicates.header().setSectionResizeMode(0, _header_mode("Stretch"))
        for col in (1, 2, 3):
            self.treeDuplicates.header().setSectionResizeMode(col, _header_mode("ResizeToContents"))
        duplicates_layout.addWidget(self.treeDuplicates, 1)
        self.tabs.addTab(duplicates_page, "Duplicates")

        # Health tab
        health_page = QWidget()
        health_layout = QVBoxLayout(health_page)
        health_layout.setContentsMargins(0, 5, 0, 0)
        self.healthFilter = QLineEdit()
        self.healthFilter.setPlaceholderText("Filter health findings…")
        health_layout.addWidget(self.healthFilter)
        self.treeHealth = QTreeWidget()
        self.treeHealth.setHeaderLabels(["Finding", "Severity", "Details"])
        self.treeHealth.setAlternatingRowColors(True)
        self.treeHealth.setContextMenuPolicy(_custom_context_menu())
        self.treeHealth.header().setSectionResizeMode(0, _header_mode("Stretch"))
        self.treeHealth.header().setSectionResizeMode(1, _header_mode("ResizeToContents"))
        self.treeHealth.header().setSectionResizeMode(2, _header_mode("Stretch"))
        health_layout.addWidget(self.treeHealth, 1)
        self.tabs.addTab(health_page, "Health")

        self.lblSummary = QLabel("Ready")
        self.lblSummary.setObjectName("summaryLabel")
        main.addWidget(self.lblSummary)
        self.setWidget(body)
        # Use palette roles instead of fixed light-theme colours so the
        # interface follows both QGIS light and dark themes.
        self.setStyleSheet("""
QLineEdit {padding:5px; border:1px solid palette(mid); border-radius:4px}
QPushButton,QToolButton {padding:5px 9px}
QTreeWidget {border:1px solid palette(mid)}
QLabel#summaryLabel {padding:4px; color:palette(window-text)}
""")

    def _connect_ui(self):
        self.btnRefresh.clicked.connect(self.refresh)
        self.btnExport.clicked.connect(self.export_report)
        self.btnExpand.clicked.connect(lambda: self._current_tree().expandAll())
        self.btnCollapse.clicked.connect(lambda: self._current_tree().collapseAll())
        self.filterEdit.textChanged.connect(self._apply_source_filter)
        self.duplicateFilter.textChanged.connect(self._apply_duplicate_filter)
        self.healthFilter.textChanged.connect(self._apply_health_filter)
        self.chkProblems.toggled.connect(self._apply_source_filter)
        self.chkOutside.toggled.connect(self._apply_source_filter)
        for tree in (self.treeSources, self.treeDuplicates, self.treeHealth):
            tree.customContextMenuRequested.connect(lambda p, t=tree: self._show_context_menu(t, p))
            tree.itemDoubleClicked.connect(self._on_double_click)

    def _connect_project_signals(self):
        if self._project_signals_connected:
            return
        project = QgsProject.instance()
        for name in ("layersAdded", "layersRemoved", "layerWasAdded", "cleared", "readProject"):
            signal = getattr(project, name, None)
            if signal is not None:
                try: signal.connect(self._schedule_refresh)
                except (TypeError, RuntimeError): pass
        self._project_signals_connected = True

    def _disconnect_project_signals(self):
        if not self._project_signals_connected:
            return
        project = QgsProject.instance()
        for name in ("layersAdded", "layersRemoved", "layerWasAdded", "cleared", "readProject"):
            signal = getattr(project, name, None)
            if signal is not None:
                try: signal.disconnect(self._schedule_refresh)
                except (TypeError, RuntimeError): pass
        self._project_signals_connected = False

    def closeEvent(self, event):
        self._disconnect_project_signals()
        self.closingPlugin.emit()
        event.accept()

    def _schedule_refresh(self, *args):
        self._refresh_timer.start()

    def _current_tree(self):
        return (self.treeSources, self.treeDuplicates, self.treeHealth)[self.tabs.currentIndex()]

    def _set_data(self, item, role, value):
        item.setData(0, USER_ROLE + role, value)

    def _data(self, item, role, default=None):
        value = item.data(0, USER_ROLE + role)
        return default if value is None else value

    def _paint(self, item, status):
        colours = self._status_colours.get(status)
        if colours:
            background, foreground = colours
            for col in range(item.columnCount()):
                item.setBackground(col, QBrush(background))
                item.setForeground(col, QBrush(foreground))

    def refresh(self):
        QApplication.setOverrideCursor(_wait_cursor())
        try:
            self.model = collect_project_model(False)
            self.issues = build_health_issues(self.model)
            self._populate_sources()
            self._populate_duplicates()
            self._populate_health()
            self.lblSummary.setText("{} · {} layer(s) · {} distinct source(s) · {} duplicate source group(s)".format(
                self.model["project_name"], self.model["summary"]["layers"],
                self.model["summary"]["sources"], len(self.model["duplicates"])))
        except Exception as error:
            QMessageBox.critical(self, "PCA Data Source Explorer", "The project scan failed:\n\n{}".format(error))
        finally:
            QApplication.restoreOverrideCursor()

    def _populate_sources(self):
        """Populate the Sources tab grouped by storage class and main source.

        File-based layers are grouped by their containing file. This is
        especially important for GeoPackages: all tables from the same GPKG
        appear below a single GeoPackage node, while duplicate detection still
        uses the exact table-level source key.
        """
        self.treeSources.clear()

        grouped = {}
        for record in self.model["records"]:
            status_groups = grouped.setdefault(record["status"], {})
            if record["path"]:
                # Group every table/layer from the same physical file under a
                # single source node. normalised paths are already stored in
                # record["path"].
                container_key = "file:{}".format(record["path"].casefold())
            else:
                # Databases, services and memory layers retain their precise
                # source grouping because there is no containing file.
                container_key = record["source_key"]
            status_groups.setdefault(container_key, []).append(record)

        order = [SourceStatus.MISSING, SourceStatus.LOCAL, SourceStatus.NETWORK, SourceStatus.PROJECT,
                 SourceStatus.DATABASE, SourceStatus.SERVICE, SourceStatus.MEMORY, SourceStatus.OTHER]
        labels = {
            SourceStatus.MISSING: "Missing sources", SourceStatus.LOCAL: "Local computer (not shared)",
            SourceStatus.NETWORK: "Network outside project folder", SourceStatus.PROJECT: "Inside project folder",
            SourceStatus.DATABASE: "Database sources", SourceStatus.SERVICE: "Online services",
            SourceStatus.MEMORY: "Memory layers", SourceStatus.OTHER: "Other sources"
        }

        for status in order:
            sources = grouped.get(status, {})
            if not sources:
                continue

            root = QTreeWidgetItem([
                "{} ({})".format(labels[status], len(sources)), "", "", storage_label(status)
            ])
            self._set_data(root, Role.ITEM_TYPE, "root")
            self._set_data(root, Role.STATUS, status)
            self._paint(root, status)
            self.treeSources.addTopLevelItem(root)

            sorted_sources = sorted(
                sources.items(),
                key=lambda entry: (
                    entry[1][0]["display_path"] or entry[1][0]["layer_name"]
                ).casefold()
            )
            for container_key, records in sorted_sources:
                records = sorted(records, key=lambda r: r["layer_name"].casefold())
                first = records[0]
                source_name = os.path.basename(first["path"]) if first["path"] else first["layer_name"]

                providers = sorted({r["provider"] for r in records})
                crs_values = sorted({r["crs"] for r in records})
                provider_text = providers[0] if len(providers) == 1 else "Mixed"
                crs_text = crs_values[0] if len(crs_values) == 1 else "Mixed"
                layer_count = "{} layer{}".format(len(records), "" if len(records) == 1 else "s")

                item = QTreeWidgetItem([
                    source_name, provider_text, crs_text,
                    "{} · {}".format(storage_label(status), layer_count)
                ])
                self._assign_item(item, "source_container", first, records)
                # The container represents the main file, not one table-level
                # source, so give it a stable container key for context actions.
                self._set_data(item, Role.SOURCE_KEY, container_key)
                self._paint(item, status)
                root.addChild(item)

                for record in records:
                    flags = "read-only" if record["read_only"] else "writable"
                    if record["editable"]:
                        flags += " · EDITING"

                    # For GeoPackages, the QGIS layer name is normally the most
                    # useful label. When it differs from the physical table,
                    # show both values to make the relationship explicit.
                    layer_label = record["layer_name"]
                    gpkg_layer = record.get("gpkg_layer", "")
                    if gpkg_layer and gpkg_layer.casefold() != layer_label.casefold():
                        layer_label = "{}  [{}]".format(layer_label, gpkg_layer)

                    child = QTreeWidgetItem([
                        layer_label, record["provider"], record["crs"], flags
                    ])
                    self._assign_item(child, "layer", record, [record])
                    self._set_data(child, Role.FILTER_TEXT, self._filter_text(record))
                    item.addChild(child)

        self._apply_source_filter()
        # A compact initial state makes the storage structure immediately
        # readable. Users can expand only the source groups they need.
        self.treeSources.collapseAll()

    def _assign_item(self, item, item_type, first, records):
        self._set_data(item, Role.ITEM_TYPE, item_type)
        self._set_data(item, Role.PATH, first["path"])
        self._set_data(item, Role.SOURCE_KEY, first["source_key"])
        self._set_data(item, Role.LAYER_IDS, [r["layer_id"] for r in records])
        self._set_data(item, Role.URI, first["uri"])
        self._set_data(item, Role.STATUS, first["status"])
        self._set_data(item, Role.FILTER_TEXT, " ".join(self._filter_text(r) for r in records))
        item.setToolTip(0, first["path"] or first["uri"])

    @staticmethod
    def _filter_text(record):
        return "{} {} {} {} {} {}".format(record["layer_name"], record["provider"], record["path"], record["status"], record["storage"], record["crs"]).casefold()

    def _populate_duplicates(self):
        self.treeDuplicates.clear()
        duplicates = self.model["duplicates"]
        if not duplicates:
            item = QTreeWidgetItem(["No duplicated data sources found", "", "", ""])
            self._paint(item, IssueSeverity.OK); self.treeDuplicates.addTopLevelItem(item); return
        for key, records in sorted(duplicates.items(), key=lambda x: (x[1][0]["path"] or x[1][0]["uri"]).casefold()):
            first = records[0]
            source = first["path"] or first["uri"] or first["layer_name"]
            if first.get("gpkg_layer"): source += " → " + first["gpkg_layer"]
            root = QTreeWidgetItem([source, first["provider"], first["crs"], "Used by {} QGIS layers".format(len(records))])
            self._assign_item(root, "duplicate_source", first, records)
            self._paint(root, IssueSeverity.WARNING); self.treeDuplicates.addTopLevelItem(root)
            for record in records:
                details = "read-only" if record["read_only"] else "writable"
                child = QTreeWidgetItem([record["layer_name"], record["provider"], record["crs"], details])
                self._assign_item(child, "layer", record, [record]); root.addChild(child)
        self._apply_duplicate_filter()
        self.treeDuplicates.collapseAll()

    def _populate_health(self):
        self.treeHealth.clear(); grouped = {}
        for issue in self.issues: grouped.setdefault(issue["severity"], []).append(issue)
        for severity in (IssueSeverity.ERROR, IssueSeverity.WARNING, IssueSeverity.INFO, IssueSeverity.OK):
            values = grouped.get(severity, [])
            if not values: continue
            root = QTreeWidgetItem(["{} ({})".format(severity, len(values)), severity, ""])
            self._paint(root, severity); self.treeHealth.addTopLevelItem(root)
            for issue in values:
                item = QTreeWidgetItem(["{} · {}".format(issue["category"], issue["title"]), severity, issue["detail"]])
                self._set_data(item, Role.ITEM_TYPE, "issue"); self._set_data(item, Role.PATH, issue["path"])
                self._set_data(item, Role.LAYER_IDS, issue["layer_ids"])
                self._set_data(item, Role.FILTER_TEXT, "{} {} {} {}".format(severity, issue["category"], issue["title"], issue["detail"]).casefold())
                self._paint(item, severity); root.addChild(item)
        self.treeHealth.expandAll(); self._apply_health_filter()

    def _filter_tree(self, tree, text, predicate=None):
        terms = [t for t in text.casefold().split() if t]
        def visit(item):
            child_visible = any(visit(item.child(i)) for i in range(item.childCount()))
            corpus = " ".join(item.text(i) for i in range(item.columnCount())) + " " + self._data(item, Role.FILTER_TEXT, "")
            own = all(term in corpus.casefold() for term in terms)
            if predicate is not None: own = own and predicate(item)
            visible = own or child_visible
            item.setHidden(not visible)
            if visible and (terms or predicate is not None): item.setExpanded(True)
            return visible
        for i in range(tree.topLevelItemCount()): visit(tree.topLevelItem(i))

    def _apply_source_filter(self, *args):
        problems = self.chkProblems.isChecked(); outside = self.chkOutside.isChecked()
        def pred(item):
            if self._data(item, Role.ITEM_TYPE) == "root": return False
            status = self._data(item, Role.STATUS, "")
            if problems and status not in (SourceStatus.MISSING, SourceStatus.LOCAL, SourceStatus.NETWORK): return False
            if outside and status not in (SourceStatus.MISSING, SourceStatus.LOCAL, SourceStatus.NETWORK): return False
            return True
        self._filter_tree(self.treeSources, self.filterEdit.text(), pred if (problems or outside) else None)

    def _apply_duplicate_filter(self, *args):
        self._filter_tree(self.treeDuplicates, self.duplicateFilter.text())

    def _apply_health_filter(self, *args):
        self._filter_tree(self.treeHealth, self.healthFilter.text())

    def _layers_for_item(self, item):
        project = QgsProject.instance()
        return [project.mapLayer(i) for i in self._data(item, Role.LAYER_IDS, []) if project.mapLayer(i) is not None]

    def _open_location(self, path):
        if not path: return
        candidate = path if os.path.isdir(path) else os.path.dirname(path)
        while candidate and not os.path.exists(candidate):
            parent = os.path.dirname(candidate)
            if parent == candidate: return
            candidate = parent
        if candidate: QDesktopServices.openUrl(QUrl.fromLocalFile(candidate))

    def _on_double_click(self, item, column):
        path = self._data(item, Role.PATH, "")
        if path: self._open_location(path)
        else:
            layers = self._layers_for_item(item)
            if len(layers) == 1 and iface is not None: iface.showLayerProperties(layers[0])

    def _show_context_menu(self, tree, position):
        item = tree.itemAt(position)
        if item is None: return
        layers = self._layers_for_item(item); path = self._data(item, Role.PATH, ""); uri = self._data(item, Role.URI, "")
        menu = QMenu(tree)
        if path:
            menu.addAction("Open containing folder", lambda: self._open_location(path))
            menu.addAction("Copy full path", lambda: QApplication.clipboard().setText(path))
            if self.model and self.model["home"]:
                menu.addAction("Copy relative path", lambda: QApplication.clipboard().setText(display_path(path, self.model["home"])))
        if uri: menu.addAction("Copy source URI", lambda: QApplication.clipboard().setText(uri))
        if layers:
            menu.addSeparator()
            menu.addAction("Select in Layers panel", lambda: self._select_layers(layers))
            menu.addAction("Zoom to layer(s)", lambda: self._zoom_to_layers(layers))
            menu.addAction("Show layer(s)", lambda: self._set_visible(layers, True))
            menu.addAction("Hide layer(s)", lambda: self._set_visible(layers, False))
            menu.addAction("Reload layer(s)", lambda: self._reload_layers(layers))
            if len(layers) == 1 and iface is not None:
                menu.addAction("Open attribute table", lambda: iface.showAttributeTable(layers[0]))
                menu.addAction("Layer properties", lambda: iface.showLayerProperties(layers[0]))
            if path and not os.path.exists(path):
                menu.addSeparator(); menu.addAction("Locate and repair missing source…", lambda: self._repair_source(layers, path))
        menu.exec(tree.viewport().mapToGlobal(position))

    def _select_layers(self, layers):
        if iface is not None:
            try: iface.layerTreeView().setCurrentLayer(layers[0])
            except Exception: pass

    def _set_visible(self, layers, visible):
        root = QgsProject.instance().layerTreeRoot()
        for layer in layers:
            node = root.findLayer(layer.id())
            if node: node.setItemVisibilityChecked(visible)

    def _zoom_to_layers(self, layers):
        if iface is None: return
        extent = QgsRectangle(); found = False
        for layer in layers:
            try:
                e = layer.extent()
                if e.isNull() or e.isEmpty(): continue
                if not found: extent = QgsRectangle(e); found = True
                else: extent.combineExtentWith(e)
            except Exception: pass
        if found: iface.mapCanvas().setExtent(extent); iface.mapCanvas().refresh()

    def _reload_layers(self, layers):
        errors = []
        for layer in layers:
            try: layer.reload(); layer.triggerRepaint()
            except Exception as error: errors.append("{}: {}".format(layer.name(), error))
        if errors: QMessageBox.warning(self, "Reload layers", "\n".join(errors))

    def _repair_source(self, layers, old_path):
        filename, _ = QFileDialog.getOpenFileName(self, "Locate replacement source", os.path.dirname(old_path), "All files (*.*)")
        if not filename: return
        failures = []
        for layer in layers:
            try:
                new_source = layer.source().replace(old_path, filename, 1)
                layer.setDataSource(new_source, layer.name(), layer.providerType())
                if not layer.isValid(): failures.append(layer.name())
            except Exception: failures.append(layer.name())
        QgsProject.instance().setDirty(True); self.refresh()
        if failures: QMessageBox.warning(self, "Repair source", "Could not repair: {}".format(", ".join(failures)))

    def export_report(self):
        if not self.model: return
        default_name = "{}_data_source_report.html".format(self.model["project_name"].replace(" ", "_"))
        filename, _ = QFileDialog.getSaveFileName(self, "Export data source report", os.path.join(self.model["home"] or os.path.expanduser("~"), default_name), "HTML report (*.html);;CSV (*.csv);;Markdown (*.md);;Text (*.txt)")
        if not filename: return
        if not os.path.splitext(filename)[1]: filename += ".html"
        try:
            write_report(filename, self.model, self.issues)
            QMessageBox.information(self, "Report exported", "Report saved to:\n{}".format(filename))
        except Exception as error:
            QMessageBox.critical(self, "Report export", str(error))
