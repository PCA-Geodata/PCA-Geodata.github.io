# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PCADataSourceExplorerDockWidget
                                 A QGIS plugin dock widget
 Explore and review project data sources grouped by folder, file and source type.
 ***************************************************************************/
"""

import os
from datetime import datetime

from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt, QTimer, QUrl, pyqtSignal
from qgis.PyQt.QtGui import QColor, QBrush, QDesktopServices
from qgis.PyQt.QtWidgets import (
    QApplication,
    QDockWidget,
    QFileDialog,
    QHeaderView,
    QLineEdit,
    QMenu,
    QMessageBox,
    QTreeWidgetItem,
)
from qgis.core import QgsMapLayer, QgsProject, QgsProviderRegistry


FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "pca_data_source_explorer_dockwidget_base.ui")
)


MULTI_LAYER_EXTENSIONS = {
    ".gpkg",
    ".sqlite",
    ".db",
    ".dxf",
    ".dwg",
}

SINGLE_LAYER_EXTENSIONS = {
    ".shp",
    ".csv",
    ".txt",
    ".geojson",
    ".json",
    ".kml",
    ".gml",
    ".tab",
    ".mif",
    ".tif",
    ".tiff",
    ".vrt",
    ".asc",
    ".dem",
    ".jpg",
    ".jpeg",
    ".png",
    ".ecw",
    ".sid",
}

DATABASE_PROVIDERS = {
    "postgres",
    "postgresraster",
    "mssql",
    "oracle",
    "hana",
}

SERVICE_PROVIDERS = {
    "wms",
    "wmts",
    "xyz",
    "arcgismapserver",
    "arcgisfeatureserver",
    "vectortile",
    "mesh",
}


class SourceStatus:
    """Stable labels used for source classification and UI display."""

    PROJECT = "Project folder"
    EXTERNAL = "External"
    MISSING = "Missing"
    DATABASE = "Database"
    SERVICE = "Online/service"
    MEMORY = "Memory"
    OTHER = "Other non-file"


class SourceKind:
    """Internal source-kind values used to decide display behaviour."""

    MULTI_LAYER_FILE = "multi-layer-file"
    SINGLE_LAYER_FILE = "single-layer-file"
    FILE_UNKNOWN = "file-unknown"
    DATABASE = "database"
    SERVICE = "service"
    MEMORY = "memory"
    OTHER = "other"


class ItemRole:
    """Custom item data roles stored on QTreeWidgetItem objects."""

    PATH = 1001
    STATUS = 1002
    ITEM_TYPE = 1003
    FILTER_TEXT = 1004


def _header_resize_mode(mode_name):
    """Return QHeaderView resize modes safely across Qt5/QGIS 3 and Qt6/QGIS 4."""
    try:
        return getattr(QHeaderView.ResizeMode, mode_name)
    except AttributeError:
        return getattr(QHeaderView, mode_name)


def _item_data_role(role_name):
    """Return Qt item data roles safely across Qt5/QGIS 3 and Qt6/QGIS 4."""
    try:
        role = getattr(Qt.ItemDataRole, role_name)
    except AttributeError:
        role = getattr(Qt, role_name)

    return int(role.value) if hasattr(role, "value") else int(role)


def _context_menu_policy(policy_name):
    """Return Qt context menu policy safely across Qt5/QGIS 3 and Qt6/QGIS 4."""
    try:
        return getattr(Qt.ContextMenuPolicy, policy_name)
    except AttributeError:
        return getattr(Qt, policy_name)


def _normalise_path(path):
    """Return a normalised local path string, preserving UNC compatibility."""
    if not isinstance(path, str) or not path.strip():
        return ""

    cleaned = path.strip().strip('"').strip("'")
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(cleaned)))
    except Exception:
        return cleaned


def _clean_pipe_uri(uri):
    """Remove provider pipe parameters from file URIs."""
    if not uri:
        return uri
    return str(uri).split("|", 1)[0]


def _try_decode_uri(provider_key, uri, registry=None):
    """Extract a file path from a provider URI using QGIS provider registry where possible."""
    if not provider_key or not uri:
        return ""

    try:
        reg = registry or QgsProviderRegistry.instance()
        parts = reg.decodeUri(provider_key, uri) or {}
    except Exception:
        return ""

    for key in ("path", "file", "filepath", "url"):
        value = parts.get(key)
        if isinstance(value, str) and value:
            return value

    return ""


def _is_local_file_path(path):
    """Return True only for plausible local filesystem paths."""
    if not isinstance(path, str) or not path.strip():
        return False

    candidate = path.strip().strip('"').strip("'")
    lower_candidate = candidate.lower()

    if lower_candidate.startswith(
        (
            "http://",
            "https://",
            "ftp://",
            "wms:",
            "wmts:",
            "xyz:",
            "postgres",
            "dbname=",
            "service=",
        )
    ):
        return False

    if os.path.isabs(candidate) or candidate.startswith("\\\\"):
        return True

    if len(candidate) > 2 and candidate[1] == ":" and candidate[2] in ("\\", "/"):
        return True

    return False


def _project_home_path():
    """Return the current QGIS project home path."""
    project = QgsProject.instance()

    try:
        home_path = project.homePath()
    except Exception:
        home_path = ""

    if home_path:
        return _normalise_path(home_path)

    try:
        project_file = project.fileName()
    except Exception:
        project_file = ""

    if project_file:
        return _normalise_path(os.path.dirname(project_file))

    return ""


def _is_inside_project_folder(path, project_home):
    """Return True when path is inside the current QGIS project home folder."""
    if not path or not project_home:
        return False

    normalised_path = _normalise_path(path)
    normalised_home = _normalise_path(project_home)

    try:
        return os.path.commonpath([normalised_path, normalised_home]) == normalised_home
    except (ValueError, OSError):
        return False


def _display_path(path, project_home):
    """Display project-contained paths as relative paths and external paths as full paths."""
    if _is_inside_project_folder(path, project_home):
        try:
            return os.path.relpath(path, project_home)
        except Exception:
            return path
    return path


def _path_exists(path):
    """Check whether a local source exists, safely handling network paths."""
    if not path:
        return False
    try:
        return os.path.exists(path)
    except OSError:
        return False


def _source_kind(provider, path):
    """Classify source type so the tree can display each format appropriately."""
    provider = (provider or "").lower()
    ext = os.path.splitext(path or "")[1].lower()

    if provider in DATABASE_PROVIDERS:
        return SourceKind.DATABASE

    if provider in SERVICE_PROVIDERS:
        return SourceKind.SERVICE

    if provider == "memory":
        return SourceKind.MEMORY

    if ext in MULTI_LAYER_EXTENSIONS:
        return SourceKind.MULTI_LAYER_FILE

    if ext in SINGLE_LAYER_EXTENSIONS:
        return SourceKind.SINGLE_LAYER_FILE

    if path:
        return SourceKind.FILE_UNKNOWN

    return SourceKind.OTHER


def _status_for_path(path, project_home):
    """Classify a local file path as project-contained, external, or missing."""
    if not _path_exists(path):
        return SourceStatus.MISSING

    if _is_inside_project_folder(path, project_home):
        return SourceStatus.PROJECT

    return SourceStatus.EXTERNAL


def _safe_project_name(project_name):
    """Return a filesystem-safe project name for exported reports."""
    safe_name = "".join(
        char if char.isalnum() or char in ("-", "_") else "_"
        for char in (project_name or "")
    ).strip("_")
    return safe_name or "unsaved_project"


def get_project_sources():
    """
    Read the current project layers and return structured source information.

    Returns:
        file_sources[status][folder][path] = file entry
        database_sources = list of database layer entries
        service_sources = list of service layer entries
        other_sources = list of memory/unknown non-file entries
        project_home = project home path
    """
    project = QgsProject.instance()
    project_home = _project_home_path()
    registry = QgsProviderRegistry.instance()

    file_sources = {
        SourceStatus.PROJECT: {},
        SourceStatus.EXTERNAL: {},
        SourceStatus.MISSING: {},
    }
    database_sources = []
    service_sources = []
    other_sources = []

    for layer in list(project.mapLayers().values()):
        if not isinstance(layer, QgsMapLayer):
            continue

        name = layer.name() or "<unnamed layer>"
        provider = (layer.providerType() or "").lower()

        try:
            data_provider = layer.dataProvider()
            uri = data_provider.dataSourceUri() if data_provider is not None else ""
        except Exception:
            other_sources.append(
                {
                    "name": name,
                    "provider": provider or "unknown",
                    "status": SourceStatus.OTHER,
                    "reason": "no data provider or URI",
                }
            )
            continue

        decoded_path = _try_decode_uri(provider, uri, registry=registry)

        if not decoded_path and isinstance(uri, str) and uri:
            candidate = _clean_pipe_uri(uri)
            if _is_local_file_path(candidate):
                decoded_path = candidate

        kind = _source_kind(provider, decoded_path)

        if kind == SourceKind.DATABASE:
            database_sources.append(
                {
                    "name": name,
                    "provider": provider or "database",
                    "status": SourceStatus.DATABASE,
                    "uri": str(uri),
                }
            )
            continue

        if kind == SourceKind.SERVICE:
            service_sources.append(
                {
                    "name": name,
                    "provider": provider or "service",
                    "status": SourceStatus.SERVICE,
                    "uri": str(uri),
                }
            )
            continue

        if kind == SourceKind.MEMORY:
            other_sources.append(
                {
                    "name": name,
                    "provider": provider or "memory",
                    "status": SourceStatus.MEMORY,
                    "reason": "memory layer",
                }
            )
            continue

        if not _is_local_file_path(decoded_path):
            other_sources.append(
                {
                    "name": name,
                    "provider": provider or "unknown",
                    "status": SourceStatus.OTHER,
                    "reason": "not a recognised local file source",
                }
            )
            continue

        original_path = decoded_path.strip().strip('"').strip("'")
        normalised_path = _normalise_path(original_path)
        folder = os.path.dirname(normalised_path) or "<no folder>"
        status = _status_for_path(normalised_path, project_home)
        kind = _source_kind(provider, normalised_path)

        file_entry = file_sources[status].setdefault(folder, {}).setdefault(
            normalised_path,
            {
                "status": status,
                "kind": kind,
                "provider": provider,
                "layers": [],
                "original_path": original_path,
            },
        )
        file_entry["layers"].append(name)

    for status_data in file_sources.values():
        for folder_data in status_data.values():
            for file_data in folder_data.values():
                file_data["layers"] = sorted(file_data["layers"], key=str.casefold)

    database_sources = sorted(database_sources, key=lambda x: x["name"].casefold())
    service_sources = sorted(service_sources, key=lambda x: x["name"].casefold())
    other_sources = sorted(other_sources, key=lambda x: x["name"].casefold())

    return file_sources, database_sources, service_sources, other_sources, project_home


class PCADataSourceExplorerDockWidget(QDockWidget, FORM_CLASS):
    """Dock widget used to inspect project data sources."""

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""
        super().__init__(parent)
        self.setupUi(self)

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.setInterval(250)
        self._refresh_timer.timeout.connect(self.refresh)

        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(150)
        self._filter_timer.timeout.connect(self._apply_filter)

        self._project_signals_connected = False
        self.lineFilter = None

        self._configure_ui()
        self._apply_style()
        self._connect_project_signals()

        self.btnRefresh.clicked.connect(self.refresh)
        self.btnPrint.clicked.connect(self.print_report)

        self.refresh()

    def closeEvent(self, event):
        """Emit a signal when the dock is closed by the user."""
        self._disconnect_project_signals()
        self.closingPlugin.emit()
        event.accept()

    def _configure_ui(self):
        """Configure the tree and static UI behaviour."""
        self.setWindowTitle("PCA Data Source Explorer")

        self._insert_filter_widget()

        self.treeSources.setHeaderLabels(["Location / File / Layer", "Status"])
        self.treeSources.setAlternatingRowColors(True)
        self.treeSources.setUniformRowHeights(True)
        self.treeSources.setRootIsDecorated(True)
        self.treeSources.setAnimated(True)
        self.treeSources.setContextMenuPolicy(_context_menu_policy("CustomContextMenu"))

        header = self.treeSources.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, _header_resize_mode("Stretch"))
        header.setSectionResizeMode(1, _header_resize_mode("ResizeToContents"))

        self.treeSources.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.treeSources.customContextMenuRequested.connect(self._show_context_menu)

        self.lblSummary.setText("Ready")

    def _insert_filter_widget(self):
        """
        Insert the filter box above the source tree without requiring a .ui edit.

        The widget is added programmatically so the Plugin Builder UI can stay simple.
        """
        if self.lineFilter is not None:
            return

        self.lineFilter = QLineEdit(self)
        self.lineFilter.setObjectName("lineFilter")
        self.lineFilter.setPlaceholderText("Filter by layer, file, folder, status, provider or path...")

        try:
            self.lineFilter.setClearButtonEnabled(True)
        except AttributeError:
            pass

        parent_widget = self.treeSources.parentWidget()
        parent_layout = parent_widget.layout() if parent_widget is not None else None

        if parent_layout is not None:
            tree_index = parent_layout.indexOf(self.treeSources)
            insert_index = tree_index if tree_index >= 0 else parent_layout.count()
            parent_layout.insertWidget(insert_index, self.lineFilter)

        self.lineFilter.textChanged.connect(self._schedule_filter)

    def _apply_style(self):
        """Apply a modern, restrained style compatible with light and dark themes."""
        self.setStyleSheet(
            """
            QDockWidget {
                font-size: 9pt;
            }
            QWidget#dockWidgetContents {
                background: palette(window);
            }
            QLabel#lblTitle {
                font-size: 13pt;
                font-weight: 650;
                padding: 2px 0 0 0;
            }
            QLabel#lblSubtitle {
                color: palette(mid);
                padding: 0 0 6px 0;
            }
            QLabel#lblSummary {
                color: palette(mid);
                padding: 4px 2px 0 2px;
            }
            QLineEdit#lineFilter {
                border: 1px solid rgba(120, 140, 150, 90);
                border-radius: 8px;
                padding: 6px 8px;
                margin: 2px 0 6px 0;
                background: palette(base);
                color: palette(text);
                selection-background-color: rgba(100, 160, 190, 110);
            }
            QLineEdit#lineFilter:focus {
                border: 1px solid rgba(100, 160, 190, 150);
                background: palette(base);
            }
            QPushButton {
                border: 1px solid rgba(120, 140, 150, 90);
                border-radius: 8px;
                padding: 6px 10px;
                background: rgba(120, 170, 160, 35);
            }
            QPushButton:hover {
                background: rgba(120, 170, 160, 60);
            }
            QPushButton:pressed {
                background: rgba(120, 170, 160, 85);
            }
            QTreeWidget {
                border: 1px solid rgba(120, 140, 150, 80);
                border-radius: 10px;
                padding: 4px;
                background: palette(base);
                alternate-background-color: rgba(120, 140, 150, 18);
            }
            QTreeWidget::item {
                padding: 4px 2px;
                border-radius: 5px;
            }
            QTreeWidget::item:selected {
                background: rgba(100, 160, 190, 90);
            }
            QHeaderView::section {
                padding: 5px 6px;
                border: none;
                border-bottom: 1px solid rgba(120, 140, 150, 80);
                background: rgba(120, 170, 160, 35);
                font-weight: 600;
            }
            """
        )

    def _connect_project_signals(self):
        """Connect project/layer signals with debounce refresh."""
        if self._project_signals_connected:
            return

        project = QgsProject.instance()

        for signal_name in ("layersAdded", "layersRemoved", "projectSaved", "cleared"):
            signal = getattr(project, signal_name, None)
            if signal is None:
                continue
            try:
                signal.connect(self._schedule_refresh)
            except Exception:
                pass

        self._project_signals_connected = True

    def _disconnect_project_signals(self):
        """Disconnect project signals when the dock is closed."""
        if not self._project_signals_connected:
            return

        project = QgsProject.instance()

        for signal_name in ("layersAdded", "layersRemoved", "projectSaved", "cleared"):
            signal = getattr(project, signal_name, None)
            if signal is None:
                continue
            try:
                signal.disconnect(self._schedule_refresh)
            except Exception:
                pass

        self._project_signals_connected = False

    def _schedule_refresh(self, *args):
        """Debounce refresh requests triggered by QGIS project signals."""
        self._refresh_timer.start()

    def _schedule_filter(self, *args):
        """Debounce filter updates while the user is typing."""
        self._filter_timer.start()

    @staticmethod
    def _brush_for_status(status):
        """Return a subtle background brush for the status column."""
        if status == SourceStatus.PROJECT:
            return QBrush(QColor(203, 239, 220, 120))
        if status == SourceStatus.EXTERNAL:
            return QBrush(QColor(250, 218, 180, 135))
        if status == SourceStatus.MISSING:
            return QBrush(QColor(235, 145, 145, 135))
        if status == SourceStatus.DATABASE:
            return QBrush(QColor(190, 210, 245, 125))
        if status == SourceStatus.SERVICE:
            return QBrush(QColor(185, 185, 185, 90))
        if status == SourceStatus.MEMORY:
            return QBrush(QColor(205, 190, 230, 100))
        return QBrush(QColor(185, 185, 185, 75))

    @staticmethod
    def _foreground_for_status(status):
        """Return a readable foreground brush for status labels."""
        if status == SourceStatus.PROJECT:
            return QBrush(QColor(42, 120, 75))
        if status == SourceStatus.EXTERNAL:
            return QBrush(QColor(150, 93, 25))
        if status == SourceStatus.MISSING:
            return QBrush(QColor(165, 45, 45))
        if status == SourceStatus.DATABASE:
            return QBrush(QColor(60, 95, 160))
        if status == SourceStatus.SERVICE:
            return QBrush(QColor(125, 125, 125))
        if status == SourceStatus.MEMORY:
            return QBrush(QColor(110, 85, 150))
        return QBrush(QColor(125, 125, 125))

    @staticmethod
    def _status_label(status):
        """Return a text-only status marker. No icons are used."""
        return "● {}".format(status)

    def _set_item_metadata(self, item, path="", status="", item_type="", filter_text=""):
        """Store non-visible metadata on tree items."""
        base_role = _item_data_role("UserRole")
        item.setData(0, base_role + ItemRole.PATH, path)
        item.setData(0, base_role + ItemRole.STATUS, status)
        item.setData(0, base_role + ItemRole.ITEM_TYPE, item_type)
        item.setData(0, base_role + ItemRole.FILTER_TEXT, filter_text.casefold())

    def _item_metadata(self, item, metadata_role):
        """Read stored item metadata safely."""
        if item is None:
            return None

        base_role = _item_data_role("UserRole")
        try:
            return item.data(0, base_role + metadata_role)
        except Exception:
            return None

    def _apply_item_status(self, item, status, layer_label=False):
        """Apply consistent status colouring to a tree item."""
        item.setText(1, "Layer" if layer_label else self._status_label(status))
        item.setBackground(1, self._brush_for_status(status))
        item.setForeground(1, self._foreground_for_status(status))

    def _make_root_item(self, label, status):
        """Create a top-level status group item."""
        item = QTreeWidgetItem([label, status])
        self._set_item_metadata(
            item,
            status=status,
            item_type="root",
            filter_text="{} {}".format(label, status),
        )
        self._apply_item_status(item, status)
        item.setExpanded(True)
        return item

    def _make_folder_item(self, folder, status, project_home):
        """Create a folder-level tree item."""
        display_folder = _display_path(folder, project_home)
        item = QTreeWidgetItem([display_folder, status])
        item.setToolTip(0, folder)
        item.setToolTip(1, status)
        self._set_item_metadata(
            item,
            path=folder,
            status=status,
            item_type="folder",
            filter_text="{} {} {}".format(display_folder, folder, status),
        )
        self._apply_item_status(item, status)
        item.setExpanded(True)
        return item

    def _make_file_item(self, file_path, file_data, project_home):
        """Create a file-level tree item."""
        status = file_data["status"]
        layers = file_data["layers"]
        kind = file_data["kind"]
        provider = file_data.get("provider", "")

        display_name = os.path.basename(file_path)

        # Single-layer file formats are displayed inline to avoid redundant nesting.
        if kind == SourceKind.SINGLE_LAYER_FILE and len(layers) == 1:
            display_name = "{}  →  {}".format(display_name, layers[0])

        display_path = _display_path(file_path, project_home)
        item = QTreeWidgetItem([display_name, status])
        item.setToolTip(0, display_path)
        item.setToolTip(1, file_path)
        self._set_item_metadata(
            item,
            path=file_path,
            status=status,
            item_type="file",
            filter_text="{} {} {} {} {} {}".format(
                display_name,
                display_path,
                file_path,
                status,
                kind,
                provider,
            ),
        )
        self._apply_item_status(item, status)

        if kind != SourceKind.SINGLE_LAYER_FILE or len(layers) > 1:
            item.setExpanded(True)

        return item

    def _make_layer_item(self, layer_name, file_path, status):
        """Create a layer-level tree item."""
        item = QTreeWidgetItem([layer_name, "Layer"])
        item.setToolTip(0, file_path)
        item.setToolTip(1, file_path)
        self._set_item_metadata(
            item,
            path=file_path,
            status=status,
            item_type="layer",
            filter_text="{} {} {} layer".format(layer_name, file_path, status),
        )
        self._apply_item_status(item, status, layer_label=True)
        return item

    def _make_non_file_item(self, entry):
        """Create a database/service/memory/other source item."""
        status = entry.get("status", SourceStatus.OTHER)
        provider = entry.get("provider", "unknown")
        reason = entry.get("reason") or entry.get("uri") or provider
        name = entry.get("name", "<unnamed layer>")

        item = QTreeWidgetItem([name, provider])
        item.setToolTip(0, reason)
        item.setToolTip(1, reason)
        self._set_item_metadata(
            item,
            status=status,
            item_type="non-file",
            filter_text="{} {} {} {}".format(name, provider, status, reason),
        )
        self._apply_item_status(item, status)
        item.setText(1, provider)
        return item

    def _add_file_section(self, root_label, status, folders, project_home):
        """Add one file-source section to the tree."""
        if not folders:
            return 0, 0

        root_item = self._make_root_item(root_label, status)
        self.treeSources.addTopLevelItem(root_item)

        file_count = 0
        layer_count = 0

        for folder in sorted(folders.keys(), key=str.casefold):
            folder_item = self._make_folder_item(folder, status, project_home)
            root_item.addChild(folder_item)

            for file_path in sorted(folders[folder].keys(), key=str.casefold):
                file_data = folders[folder][file_path]
                file_item = self._make_file_item(file_path, file_data, project_home)
                folder_item.addChild(file_item)

                file_count += 1
                layer_count += len(file_data["layers"])

                # Multi-layer containers and unknown files keep visible child layers.
                if file_data["kind"] != SourceKind.SINGLE_LAYER_FILE or len(file_data["layers"]) > 1:
                    for layer_name in file_data["layers"]:
                        layer_item = self._make_layer_item(layer_name, file_path, status)
                        file_item.addChild(layer_item)

        return file_count, layer_count

    def _add_non_file_section(self, root_label, status, entries):
        """Add a database/service/memory/other section to the tree."""
        if not entries:
            return 0

        root_item = self._make_root_item(root_label, status)
        self.treeSources.addTopLevelItem(root_item)

        for entry in entries:
            root_item.addChild(self._make_non_file_item(entry))

        return len(entries)

    def refresh(self):
        """Refresh the tree from the current QGIS project."""
        current_filter = self.lineFilter.text() if self.lineFilter is not None else ""

        self.treeSources.clear()

        file_sources, database_sources, service_sources, other_sources, project_home = get_project_sources()

        project_files, project_layers = self._add_file_section(
            "Project folder sources",
            SourceStatus.PROJECT,
            file_sources[SourceStatus.PROJECT],
            project_home,
        )

        external_files, external_layers = self._add_file_section(
            "External file sources",
            SourceStatus.EXTERNAL,
            file_sources[SourceStatus.EXTERNAL],
            project_home,
        )

        missing_files, missing_layers = self._add_file_section(
            "Missing file sources",
            SourceStatus.MISSING,
            file_sources[SourceStatus.MISSING],
            project_home,
        )

        database_count = self._add_non_file_section(
            "Database connections",
            SourceStatus.DATABASE,
            database_sources,
        )

        service_count = self._add_non_file_section(
            "Online / service sources",
            SourceStatus.SERVICE,
            service_sources,
        )

        other_count = self._add_non_file_section(
            "Memory / other non-file sources",
            SourceStatus.OTHER,
            other_sources,
        )

        self.treeSources.expandToDepth(1)

        project_label = project_home if project_home else "Project not saved / no project home path"
        total_layers = project_layers + external_layers + missing_layers + database_count + service_count + other_count

        self.lblSummary.setText(
            "Project folder: {} | Project files: {} | External files: {} | Missing: {} | Database: {} | Online: {} | Other: {} | Layers: {}".format(
                project_label,
                project_files,
                external_files,
                missing_files,
                database_count,
                service_count,
                other_count,
                total_layers,
            )
        )

        if current_filter:
            self.lineFilter.setText(current_filter)
            self._apply_filter()

    def _item_matches_filter(self, item, filter_terms):
        """Return True when the current item text/metadata matches all filter terms."""
        if not filter_terms:
            return True

        filter_text = self._item_metadata(item, ItemRole.FILTER_TEXT) or ""
        visible_text = "{} {}".format(item.text(0), item.text(1)).casefold()
        combined_text = "{} {}".format(filter_text, visible_text)

        return all(term in combined_text for term in filter_terms)

    def _filter_item_recursive(self, item, filter_terms):
        """
        Apply filter to an item and its children.

        A parent remains visible when it matches directly or when at least one
        child matches. Matching branches are expanded so results are visible.
        """
        child_match = False

        for index in range(item.childCount()):
            child = item.child(index)
            if self._filter_item_recursive(child, filter_terms):
                child_match = True

        own_match = self._item_matches_filter(item, filter_terms)
        visible = own_match or child_match
        item.setHidden(not visible)

        if filter_terms and visible:
            item.setExpanded(True)

        return visible

    def _apply_filter(self):
        """Filter the tree without rebuilding it."""
        if self.lineFilter is None:
            return

        filter_text = self.lineFilter.text().strip().casefold()
        filter_terms = [term for term in filter_text.split() if term]

        for index in range(self.treeSources.topLevelItemCount()):
            top_item = self.treeSources.topLevelItem(index)
            self._filter_item_recursive(top_item, filter_terms)

        if not filter_terms:
            self.treeSources.expandToDepth(1)

    def _nearest_existing_location(self, path):
        """Return the nearest existing folder for a file/folder path."""
        if not path:
            return ""

        candidate = path if os.path.isdir(path) else os.path.dirname(path)

        while candidate and not os.path.exists(candidate):
            parent = os.path.dirname(candidate)
            if parent == candidate:
                return ""
            candidate = parent

        return candidate

    def _open_location(self, path):
        """Open the selected file/folder location with the operating system file browser."""
        target = self._nearest_existing_location(path)
        if not target:
            return False

        return QDesktopServices.openUrl(QUrl.fromLocalFile(target))

    def _copy_to_clipboard(self, text):
        """Copy text to the system clipboard."""
        if not text:
            return

        clipboard = QApplication.clipboard()
        if clipboard is not None:
            clipboard.setText(text)

    def _on_item_double_clicked(self, item, column):
        """Open the file/folder location when the user double-clicks an item."""
        path = self._item_metadata(item, ItemRole.PATH)
        if path:
            self._open_location(path)

    def _show_context_menu(self, position):
        """Show a simple text-only context menu for the selected tree item."""
        item = self.treeSources.itemAt(position)
        if item is None:
            return

        path = self._item_metadata(item, ItemRole.PATH)

        menu = QMenu(self)

        open_action = None
        copy_path_action = None

        if path:
            open_action = menu.addAction("Open location")
            copy_path_action = menu.addAction("Copy full path")

        copy_display_action = menu.addAction("Copy displayed text")
        clear_filter_action = None

        if self.lineFilter is not None and self.lineFilter.text().strip():
            clear_filter_action = menu.addAction("Clear filter")

        refresh_action = menu.addAction("Refresh")

        try:
            selected_action = menu.exec(self.treeSources.viewport().mapToGlobal(position))
        except AttributeError:
            selected_action = menu.exec_(self.treeSources.viewport().mapToGlobal(position))

        if selected_action is None:
            return

        if selected_action == open_action and path:
            self._open_location(path)
        elif selected_action == copy_path_action and path:
            self._copy_to_clipboard(path)
        elif selected_action == copy_display_action:
            self._copy_to_clipboard(item.text(0))
        elif selected_action == clear_filter_action and self.lineFilter is not None:
            self.lineFilter.clear()
        elif selected_action == refresh_action:
            self.refresh()

    def print_report(self):
        """Export a text report to file and open it."""
        file_sources, database_sources, service_sources, other_sources, project_home = get_project_sources()
        project = QgsProject.instance()

        try:
            project_file = project.fileName()
        except Exception:
            project_file = ""

        if project_file:
            project_name = os.path.splitext(os.path.basename(project_file))[0]
        else:
            project_name = "unsaved_project"

        export_datetime = datetime.now()
        export_datetime_display = export_datetime.strftime("%Y-%m-%d %H:%M:%S")
        export_datetime_filename = export_datetime.strftime("%Y%m%d_%H%M%S")

        default_filename = "{}_data_sources_report_{}.txt".format(
            _safe_project_name(project_name),
            export_datetime_filename,
        )

        default_folder = project_home if project_home and os.path.isdir(project_home) else os.path.expanduser("~")
        default_path = os.path.join(default_folder, default_filename)

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Data Source Report",
            default_path,
            "Text Files (*.txt)",
        )

        if not output_path:
            return

        if not output_path.lower().endswith(".txt"):
            output_path += ".txt"

        try:
            with open(output_path, "w", encoding="utf-8") as report_file:

                def write(line=""):
                    report_file.write(line + "\n")

                write("=== PCA Data Source Explorer Report ===")
                write("Project name: {}".format(project_name))
                write("Project file: {}".format(project_file or "<not saved>"))
                write("Project home path: {}".format(project_home or "<not available>"))
                write("Export date/time: {}".format(export_datetime_display))
                write("Report file: {}".format(output_path))
                write()

                for status in (SourceStatus.PROJECT, SourceStatus.EXTERNAL, SourceStatus.MISSING):
                    write("=== {} ===".format(status))
                    folders = file_sources[status]

                    if not folders:
                        write("None")
                        write()
                        continue

                    for folder in sorted(folders.keys(), key=str.casefold):
                        write("[FOLDER] {}".format(_display_path(folder, project_home)))

                        for file_path in sorted(folders[folder].keys(), key=str.casefold):
                            file_data = folders[folder][file_path]
                            exists_text = "exists" if _path_exists(file_path) else "missing"
                            write(
                                "  - [{} | {} | {}] {}".format(
                                    file_data["status"],
                                    file_data["kind"],
                                    exists_text,
                                    _display_path(file_path, project_home),
                                )
                            )

                            for layer_name in file_data["layers"]:
                                write("      • {}".format(layer_name))

                        write()

                write("=== Database connections ===")
                if not database_sources:
                    write("None")
                else:
                    for entry in database_sources:
                        write("  - {} ({})".format(entry["name"], entry["provider"]))
                write()

                write("=== Online / service sources ===")
                if not service_sources:
                    write("None")
                else:
                    for entry in service_sources:
                        write("  - {} ({})".format(entry["name"], entry["provider"]))
                write()

                write("=== Memory / other non-file sources ===")
                if not other_sources:
                    write("None")
                else:
                    for entry in other_sources:
                        write(
                            "  - {} ({}): {}".format(
                                entry["name"],
                                entry["provider"],
                                entry.get("reason", entry["status"]),
                            )
                        )

                write()
                write("=== End ===")

        except Exception as error:
            QMessageBox.critical(
                self,
                "Report export failed",
                "The report could not be saved:\n\n{}".format(error),
            )
            return

        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))
        except Exception:
            pass

        QMessageBox.information(
            self,
            "Report created",
            "Report saved successfully:\n\n{}".format(output_path),
        )
