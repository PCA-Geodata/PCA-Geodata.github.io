# -*- coding: utf-8 -*-
"""Report generation for PCA Data Source Explorer."""

import csv
import html
import os
from datetime import datetime


def _rows(model):
    for r in model["records"]:
        yield [r["layer_name"], r["status"], r["provider"], r["path"] or r["uri"], r["crs"], "Yes" if r["read_only"] else "No", r.get("size_text", ""), r.get("modified_text", "")]


def write_report(filename, model, issues):
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".csv":
        return _write_csv(filename, model)
    if ext in (".html", ".htm"):
        return _write_html(filename, model, issues)
    if ext in (".md", ".markdown"):
        return _write_markdown(filename, model, issues)
    return _write_text(filename, model, issues)


def _header(model):
    return [
        "PCA Data Source Explorer report",
        "Generated: {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        "Project: {}".format(model["project_name"]),
        "Project file: {}".format(model["project_file"] or "Unsaved"),
        "Project home: {}".format(model["home"] or "Not set"),
    ]


def _write_text(filename, model, issues):
    with open(filename, "w", encoding="utf-8") as f:
        f.write("\n".join(_header(model)) + "\n\n")
        for key, value in model["summary"].items():
            f.write("{}: {}\n".format(key.replace("_", " ").title(), value))
        f.write("\nHEALTH\n------\n")
        for issue in issues:
            f.write("[{}] {} - {}: {}\n".format(issue["severity"], issue["category"], issue["title"], issue["detail"]))
        f.write("\nSOURCES\n-------\n")
        for row in _rows(model):
            f.write(" | ".join(row) + "\n")
    return filename


def _write_csv(filename, model):
    with open(filename, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Layer", "Status", "Provider", "Source", "CRS", "Read only", "Size", "Modified"])
        writer.writerows(_rows(model))
    return filename


def _write_markdown(filename, model, issues):
    with open(filename, "w", encoding="utf-8") as f:
        f.write("# PCA Data Source Explorer report\n\n")
        f.write("- Project: **{}**\n- Generated: {}\n- Project file: `{}`\n\n".format(model["project_name"], datetime.now().strftime("%Y-%m-%d %H:%M:%S"), model["project_file"] or "Unsaved"))
        f.write("## Health\n\n")
        for issue in issues:
            f.write("- **{} · {} · {}** — {}\n".format(issue["severity"], issue["category"], issue["title"], issue["detail"]))
        f.write("\n## Sources\n\n| Layer | Status | Provider | Source | CRS | Read only | Size | Modified |\n|---|---|---|---|---|---|---|---|\n")
        for row in _rows(model):
            f.write("| {} |\n".format(" | ".join(str(v).replace("|", "\\|") for v in row)))
    return filename


def _write_html(filename, model, issues):
    esc = html.escape
    rows = "".join("<tr>{}</tr>".format("".join("<td>{}</td>".format(esc(str(v))) for v in row)) for row in _rows(model))
    issue_rows = "".join("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(esc(i["severity"]), esc(i["category"]), esc(i["title"]), esc(i["detail"])) for i in issues)
    cards = "".join("<div class='card'><b>{}</b><span>{}</span></div>".format(esc(k.replace("_", " ").title()), v) for k, v in model["summary"].items())
    content = """<!doctype html><html><head><meta charset='utf-8'><title>PCA Data Source Explorer</title><style>
body{font-family:Arial,sans-serif;margin:28px;color:#263238}h1,h2{color:#0d4754}.cards{display:flex;flex-wrap:wrap;gap:10px}.card{border:1px solid #ccd9dc;border-radius:8px;padding:10px 14px;min-width:130px}.card span{display:block;font-size:24px;margin-top:5px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #d9e2e4;padding:7px;text-align:left}th{background:#eef5f6}tr:nth-child(even){background:#f8fafb}code{word-break:break-all}</style></head><body>
<h1>PCA Data Source Explorer report</h1><p><b>Project:</b> {project}<br><b>Generated:</b> {generated}<br><b>Project file:</b> <code>{project_file}</code></p><div class='cards'>{cards}</div><h2>Health</h2><table><tr><th>Severity</th><th>Category</th><th>Item</th><th>Detail</th></tr>{issues}</table><h2>Sources</h2><table><tr><th>Layer</th><th>Status</th><th>Provider</th><th>Source</th><th>CRS</th><th>Read only</th><th>Size</th><th>Modified</th></tr>{rows}</table></body></html>""".format(project=esc(model["project_name"]), generated=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), project_file=esc(model["project_file"] or "Unsaved"), cards=cards, issues=issue_rows, rows=rows)
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    return filename
