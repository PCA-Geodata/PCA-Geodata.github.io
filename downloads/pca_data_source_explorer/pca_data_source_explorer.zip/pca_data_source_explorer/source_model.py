# -*- coding: utf-8 -*-
"""Project source discovery and audit model for PCA Data Source Explorer."""

import ctypes
import os
import re
from collections import Counter, defaultdict
from datetime import datetime

from qgis.core import QgsMapLayer, QgsProject, QgsProviderRegistry

DATABASE_PROVIDERS = {"postgres", "postgresraster", "mssql", "oracle", "hana"}
SERVICE_PROVIDERS = {
    "wms", "wmts", "xyz", "arcgismapserver", "arcgisfeatureserver",
    "vectortile", "mesh"
}
RISKY_FOLDER_NAMES = {
    "desktop", "downloads", "documents", "onedrive", "temp", "tmp", "appdata"
}


class SourceStatus:
    PROJECT = "Project folder"
    NETWORK = "Network outside project"
    LOCAL = "Local outside project"
    MISSING = "Missing"
    DATABASE = "Database"
    SERVICE = "Online"
    MEMORY = "Memory"
    OTHER = "Other"


class IssueSeverity:
    ERROR = "Error"
    WARNING = "Warning"
    INFO = "Info"
    OK = "OK"


def normalise_path(path):
    if not isinstance(path, str) or not path.strip():
        return ""
    cleaned = path.strip().strip('"').strip("'")
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(cleaned)))
    except Exception:
        return cleaned


def project_home_path():
    project = QgsProject.instance()
    try:
        home = project.homePath()
    except Exception:
        home = ""
    if home:
        return normalise_path(home)
    try:
        filename = project.fileName()
    except Exception:
        filename = ""
    return normalise_path(os.path.dirname(filename)) if filename else ""


def is_inside(path, folder):
    if not path or not folder:
        return False
    try:
        return os.path.commonpath([normalise_path(path), normalise_path(folder)]) == normalise_path(folder)
    except (ValueError, OSError):
        return False


def display_path(path, home):
    if is_inside(path, home):
        try:
            return os.path.relpath(path, home)
        except Exception:
            pass
    return path


def clean_uri(uri):
    return str(uri or "").split("|", 1)[0]


def decode_path(provider, uri):
    try:
        values = QgsProviderRegistry.instance().decodeUri(provider, uri) or {}
    except Exception:
        values = {}
    for key in ("path", "file", "filepath"):
        value = values.get(key)
        if isinstance(value, str) and value:
            return value
    candidate = clean_uri(uri)
    if candidate.startswith("file:///"):
        candidate = candidate[8:]
    if os.path.isabs(candidate) or candidate.startswith("\\\\"):
        return candidate
    return ""


def is_network_path(path):
    """Return True for UNC paths and Windows mapped network drives."""
    if not path:
        return False
    path = normalise_path(path)
    if path.startswith("\\\\"):
        return True
    if os.name != "nt":
        return False
    drive = os.path.splitdrive(path)[0]
    if not drive:
        return False
    try:
        # DRIVE_REMOTE = 4. Adding a slash is required by GetDriveTypeW.
        return ctypes.windll.kernel32.GetDriveTypeW(drive + "\\") == 4
    except Exception:
        return False


def risky_local_path(path):
    if not path:
        return False
    parts = {part.casefold() for part in re.split(r"[\\/]", path) if part}
    return bool(parts & RISKY_FOLDER_NAMES)


def status_for_path(path, home):
    try:
        exists = os.path.exists(path)
    except OSError:
        exists = False
    if not exists:
        return SourceStatus.MISSING
    if is_inside(path, home):
        return SourceStatus.PROJECT
    if is_network_path(path):
        return SourceStatus.NETWORK
    return SourceStatus.LOCAL


def gpkg_layer_name(provider, uri, layer):
    try:
        decoded = QgsProviderRegistry.instance().decodeUri(provider, uri) or {}
    except Exception:
        decoded = {}
    for key in ("layerName", "layername", "table"):
        value = decoded.get(key)
        if value:
            return str(value).strip('"')
    match = re.search(r"(?:layername|table)=([^|]+)", str(uri or ""), re.I)
    if match:
        return match.group(1).strip('"')
    return layer.name()


def canonical_source_key(provider, uri, path, sublayer=""):
    """Key for the actual data source, not merely the containing file.

    Two different tables in the same GeoPackage are not duplicates. Two QGIS
    layers pointing to the same GeoPackage table are duplicates.
    """
    provider = (provider or "").lower()
    if path:
        key = "file:{}".format(normalise_path(path))
        if sublayer:
            key += "|layer:{}".format(str(sublayer).casefold())
        return key
    safe_uri = re.sub(r"password='[^']*'", "password='***'", str(uri or ""), flags=re.I)
    return "{}:{}".format(provider, safe_uri.casefold())


def human_size(size):
    if size is None:
        return ""
    value = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024.0 or unit == "TB":
            return "{:.1f} {}".format(value, unit)
        value /= 1024.0
    return ""


def file_metadata(path):
    result = {"size": None, "size_text": "", "modified": None, "modified_text": ""}
    try:
        stat = os.stat(path)
        result["size"] = stat.st_size
        result["size_text"] = human_size(stat.st_size)
        result["modified"] = stat.st_mtime
        result["modified_text"] = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
    except (OSError, ValueError):
        pass
    return result


def storage_label(status):
    return {
        SourceStatus.PROJECT: "Inside project folder (relative path)",
        SourceStatus.NETWORK: "Network drive (outside project folder)",
        SourceStatus.LOCAL: "Local computer (not shared)",
        SourceStatus.MISSING: "Missing source",
        SourceStatus.DATABASE: "Database connection",
        SourceStatus.SERVICE: "Online service",
        SourceStatus.MEMORY: "Temporary memory layer",
        SourceStatus.OTHER: "Other source",
    }.get(status, status)


def collect_project_model(inspect_geopackages=False):
    del inspect_geopackages  # retained for API compatibility
    project = QgsProject.instance()
    home = project_home_path()
    records = []

    for layer in list(project.mapLayers().values()):
        if not isinstance(layer, QgsMapLayer):
            continue
        provider = (layer.providerType() or "unknown").lower()
        try:
            data_provider = layer.dataProvider()
            uri = data_provider.dataSourceUri() if data_provider is not None else ""
        except Exception:
            uri = ""
        path = normalise_path(decode_path(provider, uri))
        sublayer = gpkg_layer_name(provider, uri, layer) if path.lower().endswith((".gpkg", ".sqlite", ".db")) else ""

        if provider in DATABASE_PROVIDERS:
            status = SourceStatus.DATABASE
        elif provider in SERVICE_PROVIDERS:
            status = SourceStatus.SERVICE
        elif provider == "memory":
            status = SourceStatus.MEMORY
        elif path:
            status = status_for_path(path, home)
        else:
            status = SourceStatus.OTHER

        try:
            crs = layer.crs().authid() or "Unknown"
        except Exception:
            crs = "Unknown"
        try:
            editable = bool(layer.isEditable())
        except Exception:
            editable = False
        try:
            read_only = bool(layer.readOnly())
        except Exception:
            read_only = False

        metadata = file_metadata(path) if path and status != SourceStatus.MISSING else {}
        record = {
            "layer_id": layer.id(),
            "layer_name": layer.name() or "<unnamed layer>",
            "provider": provider,
            "uri": str(uri or ""),
            "path": path,
            "display_path": display_path(path, home) if path else "",
            "folder": os.path.dirname(path) if path else "",
            "status": status,
            "storage": storage_label(status),
            "source_key": canonical_source_key(provider, uri, path, sublayer),
            "crs": crs,
            "editable": editable,
            "read_only": read_only,
            "risky_path": risky_local_path(path),
            "gpkg_layer": sublayer,
        }
        record.update(metadata)
        records.append(record)

    order = {
        SourceStatus.MISSING: 0, SourceStatus.LOCAL: 1, SourceStatus.NETWORK: 2,
        SourceStatus.PROJECT: 3, SourceStatus.DATABASE: 4, SourceStatus.SERVICE: 5,
        SourceStatus.MEMORY: 6, SourceStatus.OTHER: 7,
    }
    records.sort(key=lambda r: (order.get(r["status"], 99), r["display_path"].casefold(), r["layer_name"].casefold()))
    by_source = defaultdict(list)
    for record in records:
        by_source[record["source_key"]].append(record)

    duplicates = {key: values for key, values in by_source.items() if len(values) > 1}
    counts = Counter(record["status"] for record in records)
    summary = {
        "layers": len(records),
        "sources": len(by_source),
        "project": counts[SourceStatus.PROJECT],
        "network": counts[SourceStatus.NETWORK],
        "local": counts[SourceStatus.LOCAL],
        "missing": counts[SourceStatus.MISSING],
        "database": counts[SourceStatus.DATABASE],
        "service": counts[SourceStatus.SERVICE],
        "duplicate_sources": len(duplicates),
    }
    return {
        "home": home,
        "project_name": project.baseName() or "Unsaved project",
        "project_file": project.fileName() or "",
        "records": records,
        "by_source": dict(by_source),
        "duplicates": duplicates,
        "unused_gpkg": {},
        "summary": summary,
    }


def build_health_issues(model):
    records = model["records"]
    issues = []

    def add(severity, category, title, detail, layer_ids=None, path=""):
        issues.append({
            "severity": severity,
            "category": category,
            "title": title,
            "detail": detail,
            "layer_ids": list(layer_ids or []),
            "path": path,
        })

    for record in records:
        if record["status"] == SourceStatus.MISSING:
            add(IssueSeverity.ERROR, "Missing", record["layer_name"], record["path"] or record["uri"], [record["layer_id"]], record["path"])
        elif record["status"] == SourceStatus.LOCAL:
            detail = "Local source outside the project folder and normally unavailable to other users: {}".format(record["path"])
            add(IssueSeverity.ERROR, "Local source", record["layer_name"], detail, [record["layer_id"]], record["path"])
        elif record["status"] == SourceStatus.NETWORK:
            add(IssueSeverity.WARNING, "Network outside project", record["layer_name"], record["path"], [record["layer_id"]], record["path"])
        if record["editable"]:
            add(IssueSeverity.WARNING, "Editing", record["layer_name"], "Layer currently has an active edit session.", [record["layer_id"]], record["path"])

    project_crs = ""
    try:
        project_crs = QgsProject.instance().crs().authid()
    except Exception:
        pass
    for record in records:
        if project_crs and record["crs"] not in ("", "Unknown", project_crs):
            add(IssueSeverity.INFO, "CRS", record["layer_name"], "Layer CRS {} differs from project CRS {}.".format(record["crs"], project_crs), [record["layer_id"]], record["path"])

    if not issues:
        add(IssueSeverity.OK, "Health", "No issues found", "The project passed the enabled source checks.")

    rank = {IssueSeverity.ERROR: 0, IssueSeverity.WARNING: 1, IssueSeverity.INFO: 2, IssueSeverity.OK: 3}
    issues.sort(key=lambda i: (rank.get(i["severity"], 9), i["category"], i["title"].casefold()))
    return issues
