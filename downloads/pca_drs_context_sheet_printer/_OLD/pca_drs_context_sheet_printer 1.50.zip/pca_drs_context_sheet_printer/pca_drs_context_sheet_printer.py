# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PCADRSContextSheetPrinter
                                 A QGIS plugin
                              -------------------
        begin                : 2023-02-05
        copyright            : (C) 2023 by Valerio Pinna (Pre-Construct Archaeology)
        email                : vpinna@pre-construct.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os
import sys
import base64
import os.path
from io import BytesIO
import webbrowser
import subprocess
from qgis.core import *
from qgis.utils import iface
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction,QMessageBox, QToolBar, QLabel, QDockWidget

try:
    import xhtml2pdf 
except:
    # Define the command to install python-docx
    command = ['pip', 'install', 'xhtml2pdf']
    # Execute the command
    subprocess.call(command)



#adding missing python PATHS
username = os.getlogin( )
sys.path.append(r'C:\Users\{}\AppData\Roaming\Python\Python39'.format(username))
sys.path.append(r'C:\Users\{}\AppData\Roaming\Python\Python39\site-packages'.format(username))
sys.path.append(r'C:\Users\{}\AppData\Roaming\Python\Python39\Scripts'.format(username))


    
from xhtml2pdf import pisa    



# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .pca_drs_context_sheet_printer_dialog import PCADRSContextSheetPrinterDialog
import os.path


class PCADRSContextSheetPrinter:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'PCADRSContextSheetPrinter_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)
            
            
        self.toolbar = iface.mainWindow().findChild( QToolBar, u'PCA DRS Context Sheet Printer')
        if not self.toolbar:
            self.toolbar = iface.addToolBar( u'PCA DRS Context Sheet Printer' )
            self.toolbar.setObjectName( u'PCA DRS Context Sheet Printer')
            self.toolbar.setToolTip("") 

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&PCA DRS Context Sheet Printer')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('PCADRSContextSheetPrinter', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        

        icon_path = ':/plugins/pca_drs_context_sheet_printer/icons/PCA_logo_icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u''),
            callback=self.dontdonothing,
            parent=self.iface.mainWindow())

        icon_path = ':/plugins/pca_drs_context_sheet_printer/icons/PCA_DRS_context_printer_icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'PCA DRS Context Sheet Printer'),
            callback=self.generate_html,
            parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&PCA DRS Context Sheet Printer'),
                action)
            self.iface.removeToolBarIcon(action)



    def check_nulls(self, string):
        if string != NULL:
            return string
        if string == NULL:
            return '-'


    def generate_html(self):
        """Run method that performs all the real work"""

        # Create the dialog with elements (after translation) and keep reference
        # Only create GUI ONCE in callback, so that it will only load when the plugin is started
        if self.first_start == True:
            self.first_start = False
            self.dlg = PCADRSContextSheetPrinterDialog()
        
        
        self.dlg.DRS_Context_Sheets_MapLayerComboBox.setFilters(QgsMapLayerProxyModel.NoGeometry)
        # Attempt to get the layer from the project
        layers = QgsProject.instance().mapLayersByName('DRS_Context_Database')

        if layers:
            # Layer found, assign the first layer
            layer = layers[0]
        else:
            # Layer doesn't exist, assign another layer or handle the error
            layers = QgsProject.instance().mapLayersByName('DRS_Table')
            
            if layers:
                layer = layers[0]
            else:
                # Neither layer exists, handle the error
                layer = None

        if not layer:
            return self.dontdonothing
        
        
                   
        if layer: 
            DRS_context = layer
            print ('layer = ',layer)
    
    
            self.dlg.DRS_Context_Sheets_MapLayerComboBox.setLayer(DRS_context)  
        
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            # Do something useful here - delete the line containing pass and
            # substitute with your code.
            
            pcaLogo_base64 = b'iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAzZXpUWHRSYXcgcHJvZmlsZSB0eXBlIGV4aWYAAHjazZxbkh43kqXfsYpaAu5wLAdXs97BLH++g0iySip1W6nnZUQTmUz+GYEA3M/F4Qh3/s9/XfePf/wjhJ6ry6VZ7bV6/ss99zj4wvz333i/B5/f7++/FH/+Lfzx++73P0S+lfTJ769Wfz7/6/vh9wW+PwZflX+5kK2ff5h//Ieef65vf7rQz42SRqRB7J8L9fV7yO8fws8FxvdYvnZr//oI83x//vz8Nw387/TbXbHre2V+//bnv+fG7O3CfVKMJ4Xk+T19k5Ji0v/JpfG+0O+FD/Kh93Xg95jqz0iYkL+ap9//cVt3NdT8lx/6w6r8/ir89ffdn1crx5+PpD9Ncv39519+34Xy16vypv5f7pzt56v4x++XGfc3oj/N/pv8u+2+Z+YpRq5Mdf15qF+P8r7icyxH1q3NMbTqG/8XLtHer84vI6oXobD98pNfK/QQWYkbcthhhBvO+3OFxRBzPC42vohxxfS+aanFHtdbt6xf4caWetrJWMX1lj2n+Hss4d22++Xe3Yw778BHY+BigR/527/c3/2Be5UKIXj7PVeMK0ZNNsPQyul3PsaKhPszqeVN8K9ff/5P65pYwaJZVop0JnZ+l5gl/BMJ0lvoxAcLf345GNr+uQBTxK0LgwmJFWDVQiqhBt9ibCEwkcYCDYYeU46TFQilxM0gY06psjYWdWt+pIX30Vgi33Z8HzBjJUqqqbE2PQ0WK+dC/LRsxNAoqeRSSi2tWOll1FRzLbXWVgWKo6WWXSutttas9TYsWbZi1ZqZdRs99gRoll5769Z7H4N7Dq48+OnBB8aYcaaZZ3GzzjZt9jkW4bPyKquutmz1NXbcaYMfu+62bfc9TjiE0smnnHrasdPPuITaTe7mW2697drtd/xetZ9l/bdff2PVws+qxbdS+mD7vWp8t7VflwiCk6I1Y8Giy4EVb1oCAjpqzbyFnKNWTmvmO/AH5jHIojXbQSvGCuYTYrnh19q5+K2oVu7/ad1cy39Yt/i/XTmnpfubK/fv6/ZXq7ZFQ+ut2JeFmlSfyL4TuH+0cZtdAY6+Fu99f7o/f+N/++ffuVBedkvIlagcIuDKt/aaZ6SbhvBoZ6iadc1FNFv+hz9jqCXsbHed70L1MDWHKTmsWmWSzoVeD4t0rPETvXtmn4UBTMcbk//Dnz9jI4C5ODHCkrgtutfd/vlnHLZXC2XH2hNhd8/OM1tsd9bby2kBgD+lHlZ2cRW7eTAisc7sy84u5xRGNtbZNV/fGeG5dfuZem1rwvVca9dZWjqRYDKmy/YxojU1Nzpx064fd+2lhOOGkNpo5WrJ19FXlu7cObVbDzRybz5d/0pUtZnSIuK9Iys0EYdZMy5oxP3eRPVc6daU5gppETbCz82AY7CTbN1abhsnFRtjXDIlu7vL6K3k1uuVnGFUPHS7J3NT7lpbYVa4AddlYfiHPfYmE9ruLfSz72bRSnD6sOU1V9RXN13jAubP+9siNwbr2LePt/eamBKk0zLJMguzn7t37UxcdWiAeyNTPHc8ZtevuS/j2HZqCBDqbac00prEYzhrsyhrhkCqML2V3MsFpYDQOivUHrnZmhl8IzpbmCdySZAjnQ7W8BtcAZOviEZgKsMCHYjwOW/YNxRgxq1yZu2g2oJFZ2yWNxEUmO670mx31DokC+LuwgZwre0xGB7YwBT5q2iYZbsZQJw4R+qxgHat1heXrOE+eTFcngjEGMaPFYAxtD7nPHXVtMec/nrWOMIiwNDOdQ1gLS/0+o7g7L1J9wNOBjr7eACmEMHH0vEb+ql35rbnzGmG2ycxvkmRVfeZXag0ThugoK2UiQmy+JiQcHLVmVmCfC84uTXrVYB6kEQETUl8x4VOxpI3Gexq7exohPRkmY5HCN+a1xfhl7k84GfuM3InP8MsZlJyazDw5Cphj1oYvs/CVEamMbeYB08WU6uIU0IOLCgNnQX+k019vii+iuLurwXo4roLBSmO7YvjNepEAZ0Lnl8WNognlIM8CQ+2BuCTLxl0QjLiK53BY/O1W3f38yVorCNbWjxgaKyH1bhzTtZB65YqUbtusnMmUDaDdQI5v7xg7jbc7y/zf4mjeWCFkLgwP8UHAILZznlztCYZKlSwsFsipl/yzVRQA0ws4eAaYTT10KT6IjPqBEUN6kazXkLNLzBwsayWLwtDQrO46RLHPCMrmEr1HbB00C6QwmpFqdrb24JsR2M8hNdZa/QaTicImOsE0pSo1YZGF8Q8N7Pz+KG77ONqcmVkR9xtXZZp3rf4ZMecSGo/2luPxFSSBD+QxgPI+ZCXjL1yIeKLa8cTOmtgJTItSJ4lTBXXrFnBmG7xwQxurTSSYuWMewL6+0YZEE7FBT6Fiof8QRCgAI5PW6G7mHGAuWopKn9rPiW78xZlAqAGdizm9lSQjaB2IMJbDpkykJophO9P3QkmCHUP1AoTAWlXf5qlcmJCy6Q8kS4s8Jx1A0GtOXLuao7W4eaDVbMRkCGIBIaGoB1gGIMLGZcCV5ET3fMZSKD/ZuFeN5G9a1BuzyX80chYTG6or9rjipvFQAzmfW9ACpnAIJKYjRsj+oiVuI5EgJwUG0zDiq0g3hj+YMRCn9tZ39Q3zCLKAqhYImGZbwznApzZbCAf3YKd0z0D9XPmhsS+UTFMJPo9ECtMmdA7PTDRXlEIz0TW1K84mAFyrcYwHSFMAkAye453idM8MdPuqjMPVr4FoEm4SvJ7poylWX4vALSbEKhJFbbh/OkrHJRXBLRi2RlaJBAQU7eUuTdisccMjyVGUAlHQqINzCNhxiOgNzKZjjw+cxVRjZ1AqLWkZOtGsB5yjPGUAuAaIyKjR9SS5B0LGJgbsgD4Zdiwy3VBMjQCgBGwip1g14QXZZBXuWPVUxWhE4wPhEIoPA1TDpvjbpCQjOuUOZ2ixhAsXIb8gvc3JAPNIT6GByVJicqEQ3Mb4ALb0VYzLyR0Q/MUKDt28wtZA4kSW23HScRJwiBaAV08FvgIRr1KRZOHjSBMvf6cTlh3EcEFkBLROFsA2OR8wREWYFSmpUV0c8RPZ9ieUVTAA5DZB3pkOnJmCMx4YK224F11Ep7BkRWIv4okQy2vWaAqRrWXJ22ZaEKwoltEuKbMTgliIBZCUc0CkI3HC7mvIwuLxFPwm5Al6yHulNs3BZUJwWcyBdATARQ1A4h9wKaEvrGWJBtpAP4i/WI9k1CDAch1xI+hpSIqAyeDCltHiV8hQ2FsGXAwd2Gt1ohEGHKUoTHlrjOjjwuGJBjaMUpFHDLecowTiKhAABB0iiGHiE3LrLokbUswYxd3IoHRR/LwzCZrOaVULIBdd+yCEJ6Ms1TU0FoHJhh7itPamIVrMj2MC71KtrdI9leRDAFXgPvGN4lWlq+ppFHHhN+Z723AB8Mm87okAohkJUPPXIorzHTc+dQ1D+J5BGix1AYQ8xwIbjARAsJHSZSttGd8UXYRGGiVEOqAgaW/Vyf7IRi0HBA/mgAcS+GR6Qp+5AzxLFn+AC5c098ug5U0qghzxQ0cwKw7QEATyF2YHCQJuYsuaPrUJqeIGKgtVrFLuQMdDUjFUkFgdCvOdJFDuo2DGIqecz5wQXfeQNgenoSPwlmJCZlkDGpNlcCiihBMjgRtuPEgzy9zcRycsTb6gInZ/rHJ03RlLh+4aHhWAsKCyzASoCCQB4oPxA6gcTJ0DwdPUiRhCxakcAhZRPpMwxKstHgspEf3WeIF/O/kmq1BWq6Krd1VyTBBMzzWsOAIeHR8kym+ty3sDP4CE45l5kYw9I/R6nAUeS66/iPt/JCOE7Hon/+Fc/7EOITBL85JT0f9Felkt58WIv55dvQ6t2Lu7EAHgAKO6PQgwpo8AUHLh/+bj7pfn9Wd+DTKpDPFrLJEV39UWkjHLlzbManACLVnzNNCc19BHuryLpQ/Ih/zRgjCGVwJL2SxTAxTUb0Jt8iCdwz8VhZykSgRsVEvwCnRnAQWczlSLu80YwZzw/DYz9WxsmDqAlqLzYcN4B3Cg6skGHTnEVDtmOSjmyER+LTr2aO4DwxZblKtBZwcrDXBiZwNeDObfA8HXO/xYxNRBxeRkaskJckBdOMckH44Fv4GLzKbFXsYwpGhk5pcUqfiGllCaDEzRJRLrukTGyQ5BMi3MAuOy7PcTAX8tTZphQwLB6eIDRJgwYKsMfTeyeuALwAymcVeGrE9JsGZO7Z+uZpRiyAxijcYDp0ID5BFBWDRvT0aGHtQkuOglpEJLFavnlxp6Iv8g0Gnevdn0//7z4KmRwTcvC0zApVokF6Xu+L3lOFDvqJjNypqMDuI5eaOgRpYe2iEtAM/M5LDbmfyeE68Z5cbe2mpWGbtyD8wBECBROLg8ZzPmiWwAyXLGKD5AziONHg6P3sB4JMcMNRwJUYmZlcySvUrKI7lKF4FJgf8JdZc00bQtsclTfUoRHoj0TfJqrHwYRIDIlpAaSEZIAq+abVugiUQkAkG5ud5XOQtMwGQrsZFFhgJJ/RM5lwWoeHxOtZGlVhmSC471RUBIBRawq/5GtAAkDTrVfBCEjkkNx6UiOwgLzy8USZEbyPQWfcuM87QEIWkB1TItPNoAe18FDZSDSw1GgiHg0AgfKesvSZRYcPTZxRAHyAI2SH2nrgAFtPqaA73EBEp0FF5C99yEIB+4IIH4+NbAQ6mLST4kFFdD8HgdK5NEl1JbPefaOzA0wEqsB7GLuzM6sL5G02vOiDuC2fmMMigIdpP9AI5giXYGsIFFofvPSLqNOU5tj0wyC3wrEg53BCZyeIabEdkyzkwy3gxtJmxAkCKSFMKkOFhpdqDvSzBdmVqYDVp/EOYQbwXahNQOBSaYrPJ/EKWeGGiAQ1GQGAJ8ZWqQpUxiASMMdHo+/OK4LA11uWanO7NDoQh/0jHJwrITv8Ka4WMygg4VgSdMNfgFvGUTGQ04JLhZm6DXSutqMSKhuRvBaE1CwnW/Jx4bnL24jVYrF4WRBtkjjQKHCvBCP2n1DKshBAB5YXZ03UV6ViXiEjoKqIp2fH+1cOgNSPLwGeEH+H3DBcQOTOzF8nahq9ANHmLMG2CW3D6cQnDqhYZYscb94CFBiTwfSwOV0JOGsKGSG84hH3FfchxyI6gxRyjXUjQV42BU6UyJqQzSkJ9FyQ6YoY1Dy/kw4btJXn/GZAzQHbkQUeNtCdVAk74GVLAqWchlxTAW/itHyDL+KiQnwcUPIIN8pwIcivMlqtN2iGdGEQj+sGEJ/8Ic6UCiW8+ShbvyTxuOVtQ5LspV9nYoKJsd7oecSyR+VnUmf66PssyTQx8FMcM3SZlHhUFhdVE6zs8Qu4gGxOytF0AaYT1VTZuNtVRZbcnD4zm55GANwaZktTgISGaxExo1UFFEy+60FOqNbGc52QsPu4J65HX7aNVARKrkPPxMPPGQ3DHWoM9pDPjEq7o+0XClMV4csaD6h2FDHzgPsmp+hU97RLngKHqa6j0GSVrF9FGVntERNN6yjj2p4WMhX9sH1gzbNlP6Rd6AbUJMEQ4rDdljLcKoAQk05a8Qw0iWb2SIzKfKmRjRqBAgJNn9chbFv1pS8gEL7NwTyzalDxaqhUrBkN1k0dJlbBGRuCRmwpip/0qMss87uslrZA3V9ovy0FeEQvfnMzCJOyxWbcqOa/yMxmCMh9s+qs5kk7QE/GL4Jyq9UP5VZObJPvRpEmFBMD1iHMd/9hsNowfKonEPmUzdFk1PkGQqGZyx33x0OewxjSHyk8wCwa8s76sFcr/4hM3tgyRuzpiiok7KgG9apFCAqAU2kHxqIbETavyI2Sh8dQ2KcQV+8RBDgkilbH+hxLKrwrK9XKZFz2qYgffVuEb3ea30ybwz+TCLOAY0Ek0j4Vyyy0TZEv7Q4gyZn5J238yaKFHq/QAD0oWDsejw0xFUzAicDCRl9MaygABNxqJhoAn5DU+hnu8+PvtBHzbC4rHgR1yX0U0F8IpGJIQnIbS5flgbdIDK/GKL6qzar9OEpswRakl0XNVoaGXnhz0eLXMptBOKt/LjYyr3YQk0kAGQt9kDHDOUD1cw2PF5IN5ETsUwlWDE0LIOMYOVwuPu/Ram56cQPlHeeWZtdy9W+J/2xAzKLCxtuDRJloAskMcEVcyRZt1UZWCAfAlagagBs6LChVB2fKlCbCHJwJAEEFCiL5y5i/VNSEWaYPGKFeWnkSCfOQAwtTGI8JobdQmekoShngElcazX9sTWRBjAtQxx33nrvImZotHZ0II18uVn9JmuIIxRjwVrzwTlyPLxLIq+xM76CxY0YWEoGCtzHhGXeTB6xyLQfwb4iL/8An4SxIS9wbo4O/i1aO6inY8og6SgaAn8Qhv0uziw7g+t0/qklDpeqAX0RdhY1k6sVpUTodvkeR9k/0Ij1hRF1u7S6xwxVkQjnPMg7WQ5S0Jkid3GiAwjaXEXmGSQLkwK+y9tkWkn/o7UJLcY2ifIqLxokAMmm1cGtNUlraR5tbGGsCGRVPxfm4iFeZE1kH77mRQgOiBFrn0VGWZiL3asSl8hNhELaKsebQTa3+p7adPAB0gJ7lPrCNgvt0s1JBHJZPEB57oBbZnlaUNh4m5+JGPpsMZsKFqv7WxjrJVQeiJzboy+1tR8e4VRv7ZSOgqYUAuUdvFXVlDkjOyp9/mq6EXVe4EPsQDTHuhWUDQzuLWWne03iqfMQeryP5uUTcvvihA4ETETdZiweUFd6VWJ1dLNpXwk7zLQ6OsgisilGHtmroQETVomBWSA0/NmjxJh8C8Lw/J2rEdKU00qLz3FXtfQQM2H4hbxHhRTkATrPyrr00yIWxpVmUNHJNAEqQUKbKIhnhiLjDMozRYAjmpXYOABL5dJD6IMm3u7yNgBN+6rCD5j0Zm0mFTV4i33h9k/ycViB/Qhon/ANsenS3kfnroQfcH3PMDbvsB7i6bsOZjFmO5JRDyRQ3jKjbLxEN/cbTBby7exv62d/yruv3l53UrPmyIzROFlQRRS3gYeVp8ePu33XQ+jhvusPl4LrqWmotMFS7MM3OglNz2UCiRmSZ5HFU+uEwmVJexTuhz1XZl4varYYPAteVXPUWBqLZJhCYj3A5oiSAqsbmgjYyAxVUVX5iv8iiSFpaAibkEcp2VUucHSCdmSsyZGuYQVgwZA08sexk/mSgkyeskIIAU4LFCcGgXFN4irMIQPdvRGmSuj+dVxY6hZMIu4ZVGdBZUTwfZ1A8Q7gQGgL/pUbxNldmA3E7E4EVFZZAnjcGCwhcTd4Ou6+jDLMXWYvDZevEqEDB/pO0SgsFqyWrW/GgzeZOv8G6p2gVQ/WmQcSRKBTUXfqA7IIU0VboRmgtRJWToQT6tDe3dIjDiC0GwZzMlQDaWs2E0kWCLi+cSrUSn1hwopYnc8BonPNzpl+cHyp4VetuIhcnAQjYEUgV2q/7dPoG/Vb1xwp6Isx8b1kl34NJuMDClMp3rLNMGJtPuBzgrMWgsM0EZ1HkjGYsJavh0B+9rrxsmgXxVIg/aBy4YqJcQQlrhNcAp+IefN8HQ+zgsGvKxsZ6HBwT8Seq+ItJXu5aMYGjr/xmjTHwDqshBhh8AK9xolvIBggQfZGySqgMv1nUqhqhurhXB43UW5PluRXSEQUgYmIcHjMAZgjawpl7tE0TxKD9FHKLS5Vb4S8B/MhfisQscImNh1YLW6S/10KQ98rR4w0FSCJDlRt42ZSuRJ4gO3oA8Q0HYmNwnIdB4CoV01H6FJw2O+tnUYqhYNYIOnlGFC7jQbVS7WU5tq4RsTl/OE37Hg9UnQuDYKCzqUcUSDd5UrWk4HGQCop5ngjJ3FsCtE9GQfMAHaS8MnuoIGKHMAuNZvoppVrohOoDfSVZMVv9oG4DsY36ONhhqrA4KfmWdlF6VB88gtSNCTqr6oVll5lLSGqkuzqyrUqPdrZ5mlF+I2lRy4mcsf8bVeoSSsTZMAPMKGjIJUbth2oiKwIgfZrmrJ1GbbUCeNp6m2rCQfrGSIEuyy3KNmkB1P5DgjbjBvdodAD1kuyBn20w5ax6MWUZRNgXLlGS6ThXIAh2h8vwYm0jDlMVJwubO98jun/JLgpqKGl1w1jxhV/vqkJ8k51MYrsEuyLuD54hN5VzUkG6uClhc3JxEQAojmchzn5ArsFC3yqPx/2N+nrjj+zWfMHOs4CfsnrXnVwiy1DUFvyqf8b8rfKr4Fb2N18ZIyIf+wvrIYhUVOOCoqYpyVd4KVeXwsAWskjyIVF9RTc8Yzk74fmZBMvkwaHy5ir3lZlAT962mBqynnkhtGSQeAMW1ASL8BdqfJ5eW0HcZkeQbYiD3tFhcwBNuHy0Ae4jFox5fFd1wlE8/gSpNhjsTZcw76NYmPJWa41G1wSVCV4kOBfJwaA5t0qkzIuBQ3o3t6VpECx4erGBVovzh+iqE2PX8+p1Y48CXuI02Pk2GBYqqAVWssYwEvvqyiiwSvAB7dEEmTPXwvKFGujqyTkRRltH58MBjAVLoOYOp5yT2KsunpovKQrR4G+CEK00qYHGzBJwFtzppp8Y3HBJJGRB5qHc4G5hnjSw9TYlB79oxQzaTqkaOSMW9Gm8isq2DkEgjIEHtalAw6UAU9+B7CDyBmuNfMxdZ0CA5ZtCgDwOZmhoUES0a0hhF7flEIFlaOnbbJCADCXShrQ14qqhr1aPJ1Exa4IxIiuH2iCqZLPILVICmebSZME+ZdV7IPTmMBHhnxB/XuOUzNDP/s6jEaJD2LeAuyUpU7gC8wSN4g6DDW7B4JLHE1VBDK8oThpvab9TUS0IuAOMRJbAwHyCBrINpbcyegwPr8908HMPggauKGmdM0+7c0FWXtv8htV69Ha4L8pP0ASekNjDfVHh1L+3xfhBkaUVtNRaqOlZNiXK8OisgA2U9rB61fUByEFHakDTmF8BGyWW3s8rno8+p0ZBsTBEqHNTE9ydiA3OMySb/JF8JCaQKj78ATDVgLRKuiE1dJriiYXCqutJIZz8EdSFLe8ACQdUHoA5S10YrsVB4MEQfqaOmCHJ4Syc60w4cgmYVknOS8sh83B+wB45AHwyjaUtCVYlZAMUw0+tLTFmbbISwRa6pvSNcHKZ61xgjEbVV98MhwF3q0pJOKTxNEsMnVRzVDSXXHKp46MAhyHtGBJaAYhKkZ6gLQa3Q2gHYuLgOwOkIQLDkMdAW/X3dExAvQ09BI8Ld7xr2cilNGZ6swpCqbv1tL+zUtdvEUhp83wd2OswBpz95LSgbg3jFfBE5hMAAj9AFSDlfC8znSaiDvCJIDvCoxsJCCI181MmCIYaGtfwoAox1hOH2jVdmFuUv6+WZQslu1pxs1miUt7VgBDs6iIff4CYPVCBubfeqeSt5aA0nIDWJYlNTCjKAsEWJdNPDafMvS08hCqD3ib6IgCTymWQaiRj0mZ9hvRHzRdtkyALXr7aoYgySSbOjro+qnbISQkKUsGop4RXiWHisBNodjJuK2KBaLF4Bv+UCSHXhwJ9xlK9Mh3yDj8gdfhAVQLQoNfsk8zu3x6awhsyklDVwjKZ0wBsZr0oty9ZRlElFw/dRbaYSg1/XFqZ4I58HbBKnV2VkauMM36mPqt2jDMwyGIF9DfLTeJvu1XsDRPiARI5Y5QBVLMh/KD4Ah/RcuEcaEsAw7Vaj91bf+4042wo5BAQ2OH772yjA9yFHgVP1KfCs1VS1l5yrzzWnAmYYa1ndTOpchYEJl22InQj+s+RV2UpGJulGoZ7iHfpjMnE8IehEhBqhl2dIPJsLEUyDP3wmL9ANGrk6q16SMcGJ7GnPB7NKeLmr7sapwIr7KBRU4YrIY5ATXh9dXkBFXUDftLUAsKp7BgDhCmrBPNp+IgjU5MK3yL14VSxAJG20oXithZdu0Gl93Vna0b7z9Tfp3l+rh3aGamEy1ZkrpTWj4B5DIaKLxNF8G6jn2UxypGeugWwF9JpKgK/Wp/vYrXqKoeMB8lB+c+k1UDKRp11uyJteWWeinZjeh6lXb0x8h4FQZeguUzeAevsqc0iO8TwSxunZrrYR+tPBs9q2eIs6Nz7fKrd/CsVUhDifOlFHBTpSBRaRhIEsc5mKYpD0mlac2qNIgYxkiO+IgRqLidEZ1NsAM6jCnZERBI8aHq/25YQbqiig+rW9wpCnY9gLtsaiToR56FV7pDJP7YsgYg8cBGum9l3IYwJo34vTRucANPuZ79nc3BHBFrE7JQdtjYSkU1YfthhIg3rSXIOJ0Elake+x0ojWarhzIBpMuqpoPQsM3HHj9sr0XYulFuXGDPdXt851qGMtq8qjfcg5XyFivvn7+MGJfPzbJoUTmXjGrdjlh3BUN9aQlwc1QYcpEc3KabNw3HQuPl+b+wWMm9VJBmeIBa81cp+/UxZpXPLBtbCUnQHzMIhU6QwQzQ/QA6xRk9qtaiptDhxYUsYIiUBOgy1o/qRqB47msMxMKj9tQb1fBxk2cX3amwdLfAwThYe0CNdlnRhAgcShbifiHw8C5ocpAtQONvYmqSVK8JdV7fpqce1tkpIp6gwZazmkMgOKQs60+Cy/kz7oA5XV9rexOFSeF8koSdXBup8SWtrK0Ekc7Sk6AcYABeOpSjCZ0KTFJ+1U0nv1M6w8a8XVuQZCGnRHNQ1Rlzqd7KGlYy3OUm1ee8FdzSYoJm3LIn21ATKYi6ZTB9aT7PycC60CKIMjPNtI6pZHLDvVn6Tlj9ouVQmByMkXMIBfS5UsRsPsDW28o9GG+kpKV4lpHzV6Yoat+OlmN3XPSDF1OOzJbnUzsDjMy1S/AeqwVJJQ2w/I/9f/qJOF3ALQXlyc0HPqX41BNWL1lyadVVCHwTt8gTnyROXEP0U1JSNsMqjHF17nTzCKr4/UhIJuYqWDKQIkJpf2KnpF4H/V26kyA3CwbaEL5wDTd9zKY+3hL9BfkEjiVCeinekHCeuQcJI5JY762xgxPqCi6lIgoYp0yqNWFb3JcmjCvxIN4O/vUSefyAkrWwV+auvWJkBSTYGJ84B+FbDjZ+oTPEONMehAbRpGRKXB/Uv1dCYGXDhaY5ZUj6oe+K2qJjbKtPWlWmVS508TORKBKtpZ+8rou2yHTAOy1UCvgxAje3XJYn/UPf76B7waTAFxEHxBCtrMVQ9sKqrrTMTCjhm54JQrxIkq7JOHRAlp9+uUMpkuW+2dKUM/mFJHpSgYqGrHVMUlZDAUpy7D7IBn7WwjkwDX+XWPqAqDfZfJwbiMlLXxqJON3HHJaohpSVSG2hNLjzTCZRccJ6jimd5bVaXHV2nPTI29OmzBfAukUIrPnL86zIK7iVjggO+CJB2obQh18gzFCvFgJQYxnF7NL90IcKvZX9r/tYOpd6VpOxBd8/w82o+lPcdHp/NtwzO1LBVGDaRXyY8HmyG8LaycuZrXMcCqXlpGqtZqnCAGR6UTbFt8R6rQv7GaqgVFUKw4Wq+VOcOdRfvSajpQmQJ8HbKvejIU9sg6CEwoRR1jcRMcAsi9NoE1aTIJMt0Fj5a1KX2wXZjOnI9mDhunqmZStwPPKMDrCBZGBOGTyyQi0sLDhF59d7AgihyYQYIytxANP6jzGHxDJ7lY6q2RfTuqS4c43IZ+CJe91SJ+dJpNXj2ggkkw1R9VBz2R4KuvVFSJ3NVVYIFESMuHtELIt+LWVX35teLY9JdaarfWVE6vJ8iRGLxBVaiRxZAJAsH6IdTUL+XkyWD+KJcJsgLq0gioPkIxvwYEhIheAdB0MDGqEKxL7K8EpS6erCuYUz9L05mZMNW4yDPJCTQyopItXg3GpvNIfUtmg1Da3q3+GYasfgZWhYAwZ3pS1nw3ne1Qj0GcuPKQ6qMCyJ9oTbsSOWpu7joBIQWAWXgnLFuEzLBRLmTTWSvtnpeAYEIhW+is3UFXzS4pIaRUyzUAXv2MmXg8qudpJ7nY62dKrFrBwWb03QRA1Q84dSK883Pab3zVdVs/7VXlfHs5ah5rmXmvymtcLGnkrmxXzJEJNNJJt+9qqcM5mhryOh4DbaUy9dHxhSqCQPoRa1d1yMGS4inMrUHy9jj157Fxn2DFzy45LRYZwVfTVk0MnI84cTVdQsXaqIIlv5Zd1s2lBjd6mbwA8mCDEo7vpiFA91t7dDLjVanTBMhX4kbHhK56xjAUUIy2i9zzjXKxXFA2Dr3kdXhXXrnLQ+FzSBcW8E1Z/xrl7Lk6PTQwXeZGaBn824mVmN85W1WPZRpta4coK0b4UcBThxumzuTBiuoMJYZLNHzuwtjzmKwaGEdyF/Vk1M8w8K1v6w4dhOjj3/du7dlmnXCM2pRB0+pgsnkUl+FPnMqf4PCr1uB9NrCDBooeTg0HyiJ5la+qdsGL9g68rCvk4WcGPhXKMlH20FEE4P0EH8hSqIXIfmeP3pmpCnC+rYSEYO+vwghL9RK9OrWyuvXwIPm80xkokM3f1K6vc4ZoMsAW0EFtjEZiEV06AKZmJgB+YE9b9+ofSpsxa2V2SI44iVlJTFLAUDgthEC3YakKS3J4mk2d7sAQylS7EVCxGArCIM4kbFedTidlr4I/oe8ICa4ysC1rvE3B9XQumI3eRpYXsPIEiJQQwaYIpgy/sVvQyYNXIkUJAY/Y1t21aYjaC/ihEFBl3tAQybxFpnlIjmqHPBX1kWyDZMiwHFzW/kL/9swD6gqDhkpjwlA1YGM+7/iMWqYAzmyvXfT4hnA7wiZBFLo3R2ed4OWuAZTd92f3P+gUwia25pJ40IaI3vFgiiId4mZekHkte8yCap5z6EiVR3ETHfftHaYfr/ft8HUEEzmv/t7+zpqCeUEFVgCuv/GcLnldd3U6uNSknYMaGfO+OiowuZXGXgBwVBYuSO3Eb0F46KHTDHKBUam30LEEl1tiUYJl6/Rm4gbjTeG4KuYQJaRvVgO1j0nV0KJeCj90HpQHwLXEPXU98OgQ+jqTeFRCsaeptRN5bsScC0jEtkenEn0Py2sDAZkO7aBPGhGvVuW8cZCIp7aWjf32SkDP/oUg3iOMSiQRCxPsgt/V7mD54MLVOpq2qAxWwO/f4fTkb4xJ9YquJjeEwTdEEjrLNRKhAA+MyqhKvFERYHuhyBAmWSyf+tumvwg0ghQz0CTCIstKPKjRu2RhtlrAUQLcCiIwIqlmIhfRxVKoa4n1FItANSqVq1rWZB+hCnxH1vmnnPSakQlnd/WMLJ12KiV1uOLcFDGV9WLldfwWpt2qT4E3qumHZWpTL3ovBr5DyqSBYunDjdG/04lbTexWL6QJ2JNGBKDT4fbw08IsALEu2QVZonl0CK3HcKE5BggZVEIgbvXb4GdULynI9SgrV1xmOnWo3UDwqWOoikTyDwgpz72l13uBsdxNO0nVq/zlSTdB4Fg/pb3uvi8XmkZVnqutax2sJduugSjEf0GJNx0FImOYZ5XPjHlDCOk8mt5/gfVRQHI/WBysaBLvsn3yMASc9jLfCxS0iQmlh6RnWV6LhXCq4/lONSkAYA6lA54wK+qEaDoF80LIq7qA4RTeQlFIE9Nx2tjnO2V+x+vTyzryXqOOTDuo+G3vRXWxRlCBn1f7DX8ZKpaWiG2wpdMuVRsAv7Fr4AyCDtQHUmhi1xfcJ+H0kLmrZ2R+3v6dL+za49w4T/SEahraXkd8xKUDkUtn1Vk1nRx3Okf0TqPr9QBdh+feO2cYmTwSmYh1fB85syLKyKSavzaVPyxPdJJkcRfV39AkwPgqpE+XZve44Ew2Z+19qzetoVmjjkrgE/CqElVfMwlA/3ItosX9zzk0vUPAVI/HM18oWMW5XdXUt3S2Ky7p1kB8qk1oBfSIFjgP9zXomM5cfJ01V68QeLt/9+uPAI9wcfLEkx+N0ANBjhOHKGUxBmHMTLgMNrOwkZlIOgY91AFfUUcTyJEXRRyvqN7aoRo207hVjG8145208/ODTI5FPGqVUlixUPaOXfqvx5DoySurY2bp4Dx4qMOPCCrfh/Z2UMeERp6sW3d6oYl/rTKZKIFACBBklfbsi44/qkXo4LAwLD2K3rzMvc+v0yrNosMQXBwWgVHhFv3fmgnpgw7P6pip9nZVG2duh2woWDJzY5515qJqfwmtr1Zv5LG9VVNjhXaQSZymkwvajchauaYT/JG7mvbdYeKuohLssqbqjLDokTJUbd7hOEiIqd0guYT1Duh7uF0HjPcLxsh846srllQHsyEkiGRJZenY5NS7LNJ2OpM8dBp1a/MV97ZCxzmhjyUmVRB+BwG2NvdBAYDptX4gThYIMpk7SV9sloTWUoXBlxJwczYUAMy5jL+2RLCPdVXdA9mhntToeSoYwtSxL3eqWIsugkdLtZ9ThaRXaLLD0VF9yPmqgKcPoES7Gh1NiVtbbci3vjO6Ve4ABHHADZGPIsD8AQqgOVlhOJ6iZvfXpUWaMwDBWQRhsIbgeXvTF/x5bx/BwjjY7UY1m6ghqwT+SzrGJVmlM6LCpVm6XgngdeypYY6EhSBLw16943z560AY3eukvI4KFsBKmwH4+KIdp6QzZ+D91BlEtQCrm3x+2+Cqj30Nj8xhWnprFWtJguvVKO+9XupRu/udnH2bQHAAy7QCX5+1dAQeAn9Hj+Ku9zskj7d24kmmDmFdtHNDpnuc+Yn4sS77o+MUpsDRZjtLS8zVmnEV/utzH3qnD7MlFukyPIvf1WQikU/aEb06LitZdKG8M171WYcCpnp0M08/mXadGTGdK+ru9O8ksScCuWNnfLgU7a3Up5RlVMtCAukERONWeeuUFldd6m3PavPHR0+nfrU11EqqDkycPGx85XknCKZIb8BnAzKAua5rA2+6qY5YvU3uuwUvr1arlzvo9QpT/hG1gQTEPi6DlCWs+wLeMP8q4WDEytKLVlTZVRIRY3jmsxowwlrsgHBIY0gUkR86McADwINBb06ZqJ4cwYzFfHRVBnR0ggnTSasCfBLNXOhItuisoLj0HkIak606m9dRnJSsTzKwBzTMWozrqObzjkDHHxkt2TucXooTsN21eB3RJIvQx9jlVsmHmN4eP9rDnlzQYaX8NfIHVDAuV6+rwGXu41RuT0ScGv9fdZT1hX9Up41X1kWn4bX/pIJBtPbFT1C7pJrAa4HKV85qhh8QQWU+J8vDyqrvAOxParPQGukwJ1MnLZxec/bUXiPy/8JFUoZqKireIZr1EqPW9ZY77Tmia7U7F+fSmZupMqdM18HhHclnHS0i+7RtyU/oOHI8OUVX1TKFROXp1zd53BStH3kORGCX3UYXYbfXU0NX+0nzE0OMd60nhnxyOttvoqz2juqa9nSuDhbkL8tzGh+qqfEOXaGm4tdwiZnrqkb3r43ZrV8fX1X94uodRjboTX4o6quasl6jpO7xLvW3ND6k4yoyB+gVpVCblpyK0IpcodTVadqiF48EUhyc1ou0AGohRVC9ltR6XhQK4Q8NUKpLNXi9S4MZ5jtbjUcFVih6txAWXsfqQZcDrrH0oEwdRe+mOEG7nnrDFxYjaROyQL7NodUtancQAm16IQQU4F+sNKFH6XfpXQRqs8EPqK0aS/eUr+7OjJw8dcDBkTmDH4Jg0lkorWVT2zMMnnRBtkC++JrXO86HDlZKe4td7xoQuEMWepuQLVSttjG6FLqdV/6C0xjuCp8EexD9ATTwPKQPj87/rBIaAKS2xxIIEqdXBhhqZenFKdt0VF0nAZtepgIqk8KqopNUYfNNdVbozID6i7WjrSZ/vbPjNKnapo0seVZNOmEnrwpEpSm3iuAFUXHp/VN0OpDQ/dYBxEswwgUEJzHgsnYJpTGK3uGkt1sxJShU2x2loZbduX5au8/U23pm+WmVD4mU/F7mAxY6NadtcVn/8SQEC8q2bUOFYiDgOp0TIl3xVkxw1ilQvRVR3Rp6Qd2rwdXptKFX1PTJIhEKvZT35jw8pt6W82lqU4FH+8H5hK7jn1kdy1lv/ggqTfAYwWl/RQff1E5XwcCrVsKbdIrPw0ZQ7hF4Dr00Sm/rE2mQi+rhR01MliA3FN1yZnLc19+pTy+Vzd/OMHObtKGk5kGYWC8mK2qKGqyZ9nR1GEkvPZkAFKhf3HutVgNZut6jgC5D9gg0VU2LQ++/GmVgpx8Hq7NixNTUFK3XtVTdMRfd0b1bqq2a3C8qGcopNeUWIkuA2bnYO8z0ColHr/oaeiXHmer29GAXaeizw+nB2VWlXjhjyZepLvneBgPo7c0SN1ZJp/5A0VN06FBNMKw8SlLbAUjyvJ3OFupMKXOleWChujqiJjikFCL492vcUAw1Rjzb161tPFGRtytv9zS7qdfSvPcz4SL7Q1NrQ0e+R3mnGt6xKpUQolrLjNXwB75A6am3PB3tjra68WvkgZdDeS87VQVV2impxwx9l3UAsUh5MpypN2vqwOTVe3qGKhmf5oUJ3EKizTukK/W2WXToIgu0f2yATUfEstBT9Rhw9B1j7sok9axVnVMXhKIuh2uqgR6CCloaOooEio6Kdlav6317D1HnrwKBWcAItV/pJIxeC6tD/xiP1lCM7+0epvfvMa0VJkGCajt/oAYHsPVknMxcJzFZHWUZeinO19UoVMBl63w++kht91NQfVUe31ldCwggvYzr6PzvQsPr0GpSJZKoVnEbta1Q7Dr9KZ7SWVFATK/whSeLjk8k0t+TojVDI9lvHfyFV3QEGRegbnwS7jWNEElRXceIJq7AhaTnataY0Ndag17V1ITG09sUUtbmvU7CqDNb/WXMI/KFydc777js67Cdruu1BzzfUiN6Cyqpa3XFka/NjOkKQduiCA/Eq3qddMZ5qQOovzezPNeFhkRYvLb/TuCqK0jyYe1XBdRRUFSh9qHVxNsv3lsn4yo/ey65E5Paal63nyswDiY/6aVL6uJr8PR7qViSCIRvsGEE0lDxnQSZsmdC5K2j/3qBnVmTa3emCVuaFNQD39dJWRQ0oTPfm/bU379UF+1vb+t12p5b1cIWr/pWm5oJXmuV8mM15k5QhL3PpJ061FX+tGN66dHSlrwKCdpp80lCXi9YksRRwRCo11mIix9SYKm1TdZlAW8vXHXA8KA+5tfO0HTCd4Ps8EJTR+ErIHOfFvc9zrp24iZmT5v7DJ7HYDl4bBxCRnhcEhlvVTFQY269d+lISpj63hXz0fRqFu9IKpJeGYT81vsyivbqlupQqjU3nYmIevONbHx7YbR30bmMFkCR3XFg6rXTq+Zws+B2TWW+6kdI3GDr+vFCK6C13sT13qel3ROdSxC8L2ge6EAd4ipVQPA6GVnVJVH5U7vF/h3d6GpFfBSDuNyiyR7e0QG1Rhdtar/2xKaNsFyzs4AiknXXOxWJlsQMqOCzdViTmYWouvBWgaGjSMy4epcRcBOlg2HTOWUbzS0ybj1iITWhQvVkpEKUoQAQoUXYyRiWmEkSfy+9V7jjJj0aqeqw1VLbrIOvMC1INPRLmHoVKAqYR9MWlV6WhJfq8/X/igJUVOivM0NvGYccFOpL5XLHrElukDXqVEVpAbTYJtSi5mWofK8j0bf5s4T5eh06QCmJeuy9/lg23IbTixAYOCtwft6pJK3xH7xO9U9/ur/7A/9/XkhFvK03nf9fxsDmSILtPP8AAAGFaUNDUElDQyBwcm9maWxlAAB4nH2RPUjDQBzFX1NLVSoOdhBxyFAdxIKoiKNUsQgWSluhVQeTS7+gSUOS4uIouBYc/FisOrg46+rgKgiCHyCuLk6KLlLi/5JCixgPjvvx7t7j7h0gNCpMNbsmAFWzjFQ8JmZzq2LwFQIC6MEsxiRm6on0Ygae4+sePr7eRXmW97k/R5+SNxngE4nnmG5YxBvEM5uWznmfOMxKkkJ8Tjxu0AWJH7kuu/zGueiwwDPDRiY1TxwmFosdLHcwKxkq8TRxRFE1yheyLiuctzirlRpr3ZO/MJTXVtJcpzmMOJaQQBIiZNRQRgUWorRqpJhI0X7Mwz/k+JPkkslVBiPHAqpQITl+8D/43a1ZmJp0k0IxIPBi2x8jQHAXaNZt+/vYtpsngP8ZuNLa/moDmP0kvd7WIkdA/zZwcd3W5D3gcgcYfNIlQ3IkP02hUADez+ibcsDALdC75vbW2sfpA5ChrpZvgINDYLRI2ese7+7u7O3fM63+fgCuMXK/e2Uy9AAADXZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDQuNC4wLUV4aXYyIj4KIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgIHhtbG5zOkdJTVA9Imh0dHA6Ly93d3cuZ2ltcC5vcmcveG1wLyIKICAgIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIgogICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIgogICB4bXBNTTpEb2N1bWVudElEPSJnaW1wOmRvY2lkOmdpbXA6MTBlYjAyNmQtMjViZS00NTA4LWJhYzgtNmQ5YTgxMTkxNjA2IgogICB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjA0ZjU2MDRhLTI5MTItNDM4Ni04MWM2LTZjYTNmYmM3MjNmMCIKICAgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmI5OWYyZmFhLTUwOGQtNGRlYi05MjZkLWVmMTEwNTQ3OTU5MiIKICAgZGM6Rm9ybWF0PSJpbWFnZS9wbmciCiAgIEdJTVA6QVBJPSIyLjAiCiAgIEdJTVA6UGxhdGZvcm09IldpbmRvd3MiCiAgIEdJTVA6VGltZVN0YW1wPSIxNjc1NTkxMjkwMDcyMjM5IgogICBHSU1QOlZlcnNpb249IjIuMTAuMzIiCiAgIHRpZmY6T3JpZW50YXRpb249IjEiCiAgIHhtcDpDcmVhdG9yVG9vbD0iR0lNUCAyLjEwIgogICB4bXA6TWV0YWRhdGFEYXRlPSIyMDIzOjAyOjA1VDEwOjAxOjI2KzAwOjAwIgogICB4bXA6TW9kaWZ5RGF0ZT0iMjAyMzowMjowNVQxMDowMToyNiswMDowMCI+CiAgIDx4bXBNTTpIaXN0b3J5PgogICAgPHJkZjpTZXE+CiAgICAgPHJkZjpsaQogICAgICBzdEV2dDphY3Rpb249InNhdmVkIgogICAgICBzdEV2dDpjaGFuZ2VkPSIvIgogICAgICBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjI0MTIxZDYwLWE0YTktNDY2Mi1iMzY1LTU2MDMzZmVjZjM5MyIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iR2ltcCAyLjEwIChXaW5kb3dzKSIKICAgICAgc3RFdnQ6d2hlbj0iMjAyMy0wMi0wNVQxMDowMTozMCIvPgogICAgPC9yZGY6U2VxPgogICA8L3htcE1NOkhpc3Rvcnk+CiAgPC9yZGY6RGVzY3JpcHRpb24+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9InciPz7DZmxpAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAC4jAAAuIwF4pT92AAAAB3RJTUUH5wIFCgEbFGJfswAADfBJREFUaN7tmWl0VeW5gJ9v733GnJORDJgEMhAyABHCGMook1eCTL1VsXq16vVWlrVKoYi21jrB8qq31jrite1dioJCEUFRGQQZDKOJhEwkJCEkhpDpnJxxD/fHCYEIARH/tIt3rbPWWWd/+/32s793PiJ19hMbgAL+yUXiX0SuglwFuQpycVHOfDGAgG6g6gYB4+wCkwCbLCGLy1fu1Qw6NB2PHtpBFgKHJHDKApN0aYUe7eyD2GSBuBSIXZG4/8ah5GQkERnhINxpR4jQbS63h6qaRvYVVbNqdxXn6L6gaAakRFiYPyGT/OEDSUlOIDLCgcmk4PH4ON3aQfmxE2zdU8L7X9UQ1C+sMCvWzh8XzkRRZDRN5+W3t7KtvPniIE6LTMG0kST2jb3gokFZqcyakc9/1jfx1Mvr2Xzk2wuusykSS28axfyCcdht1vOu2+1W7HYryYlxREc6+XBfba8gP5s6mLzcgUiSwDAM5jSe5ouKLfSy/KxpnZHq2gbeem8bp9s9CCHIzejLxLGDyUhLIikxjuW/XYD7sb+xq7qlx31pUVZeWDyPITlpIbPw+DhaUcPOwlK+PFzDofoOpmTFMXZoCqOGDWTvwTI6Vf2CDxVhlhk1NATh9wewWMzk5Q6gj20HTZ7g9wNpb+9kXeFxOoOhTTYVN7B87UGWzh/OXQtmEBEexi9vmcD+Fevxd9lZpEXm+d/MZUhOGoZhcPibSn61Yh317kAP3Z+XNvF5aRPGu4UAvdp8dl8n6amJaJrO9t1FTJuYR0JcNBMH92VNYe2VRa3XPjpMZfWJkP1m9KOP3RRSIGDxzfkhCGD3viPc9via8yDOFXERCAHMnZKL2aTQ6fHy5to9eH0BZFlm2rjByEJcGUirX6O+IeRsTqcdixK6NTXKxoxJeQghONXcytI/b8LTi8l8H4myKgwbko4Qgsrqeo43d1JRFXqBuTmpxIeZrgxEFgJFCVmiqmrdTjd/UjaREQ4Mw+CL3UXUuwJXlA+GpUSTkpyArusUHq6k2auy71AFum4QExXBDaNSrgykr8NMRuo1ADSdaqXTr2KSBEOy+iFJEpqms3lX6RVBCAGzJg9BliU6PT5WbykBYM22EjxeH7IsMWF0NuYL5KBLghhG6Lgfu2cKCfExGIbBngOlnPKqOM0ycTGRALg9XioaOq4IJNZmYtjgkFmVlNXQ2OVnJzv8lJaHnHxQZgqJ4ZZLR60wu5WZw5IJqBqSJMhOjefGGaOJ7RMFwNHyGp5/b28o68sCu93aHW6Dmn5FIOOyE+ibEIOm6+wsPIqvS59H1dlReJS8azOICA9jzviBvLCh6OIgGelJLF92G4YROuoz4g8E2bu/hEUvfkyLTz1b1xghZ1Fkubsa+EFFn4AZ4wehyDItbR2s31XZI1mu+7KcO2/qJCrSSf7wTF79+Bu85wSV80Bcbg/+QBBZktB1nVOn29izv4w3Nx6msTPQI7P6NR1XpycUyRx2wszyDwZJCDN3J1O71coHL9xzfuVgDZlU9sB+9I+0Utrs6R3kWPVJbv/janyqgWYYXKy0cgV0Gptaycroj9lsYuK1yVRuK/9BINOH9yO2y9+sVjNWq7nXtTarlXmTc3h6zf7eQc5YjGoYl9xcMwwOFFczIT8XWZaYOm4wb++owKcZlwVhkgSTx+QgyxJen597l71JY5v3/MgZZeO1p+7GajUzJi+T8PWH6AhoP04/su7LChqbQnXX8Gsz+emYVC7XU/o6zeRk9Qeg4tgJvq5ro7LFe97nUG0bZZWh6JWRlsiA2LAfr7FqcAd4f+NuVE1DUWSW3DeHgqHXcDl+f2P+AKIinOi6QeHhClzBC0c/d1Bnz4FydF3HbDYxf8qQHw/EAF7dVMzWnYfQdQNHmJ3nHv0P3nhoJsOTIuhjO2u9FlnQP8LCdZmxTM2KC/mDLPjJyCwkScLn97Nm65GL7vfB9qN4vH6EEIwYmkG0VendRy5XfJrBgy99yqMtLubPGo/ZpHDd+GFMHHstqqqhaRqarmNSFCRZQlFkvtxbxPayj0iMsDIoM1R2lFXW0dDhv+heJzv8lJQdZ1ReNinJCeQmR7K9ornrRAzQNB1V09A0HYzLh/GqOo/+fRf/fv9L7NxbjM8fAAEWiwm73YrTYcdiMSFLgkAgiMcTwCwLZo8biNliIhhU2XOgDHdQv0T7rLNrXymBYBAhBDMnDgqVN6mzn9ggCQrSo2xYTDIuX5Dadv8PYelZbthNJEZacdhM2C0mgqqGL6Dh9gVpaPfR7FW78oeJGIcFDIPjLd5em61zxSoL0mNC7Xi7N0hdhz9kWroBFS3eH3WqccoT5FQv3dy50tgZpLEzeNmmfKSp8198HOQ0SYSZZVwBDU9QJ7arAzztVbHIIlR+GAbNXrXb7GRBKGoIQbM3iE2WcFpkOnwaPk0n3Cx3J6wwk4RH1YmxKmgG6IaBWQ69R7+qo8gCRQja/Gp3HvJpBk6TjDuoIbr2koTAp+pYuxo7VTdo9akhEEUSPLtwOi63l4FpiTy78hMW3309VbWNKLKEy+0lMiKMDpeXFe/sptWv4TBJPLdwOgbQ2elj3ZYiHrpzOuVV9WQNSOL3L33EikVzeWv1dgrLm1j88wk0nmojqW8MDU2tuD0+hg1KRVV1Dn5TxYTROZRXneSahCiKS+vQdZ1XNhbzpwf+jeVvbeXXt47DrCi0uzxUHP+WvMEpREc5OVBUxYv/OBgCEV3V6+trC7l3/mhy0uLocHlYue4rFt8xBa8vwCc7jrCr9Fva/KE3fMuEDNpdHpa8uQMBvPzADN5ev4v399fx0KxcFlw/lJONLfz0htFUnPgEs1khMSGKQyXH+euWUryawRLA7Qnw4Z5Khg9J5W8bD7DsrmlYLQrBoAYCzGaF8blJqJrOwj9vQtNDVfm8FhejhqTw9Pv7Eef6iKLIPLd4Ll5fgJ1f1xEfF8nj983kQFEVum6QnBDJiLQYHvnZSNY+cTPp/eI43eYORRFFwhlmo/xEKwJoOu0mzG4lqKrsPVjOnXNGA/CHlVuxmBTeefwmEuym7gmEAKIjw1l21zQamloJBLUe9h8X46SlzY1hhMp98Z1hRQ9nV1WN+5d/wCN/341f1WhsauWxlzcxIjcNIQQ1J1vYW9nMk6v3UfDIKtZtLSY/L5PMPnbMsqDoaA13zRlFQpiJKT/JYc+hSgBWbT1KZHgYhmFgVWRWby/F5wtg/07Jf7q1g8de3UxCXBSNp9rpnxhLYrgFSZLYtu8YeYPTyO3rJMIsc6FpqxyVdd0Cw2Cgv6OD0kZXaPar6XS2tnOwtg1Pezul1U0kJUSQmRhFY7MLr6pzst3H8ap6po1MZ3D/GFZ+cgQLKpPyUvhsdymfFjfgaeugpMHFkaO1NDa1Ehth4/r8AWz+soRDdW14XR6qG9qo7/DT2dZGcX073vZ2Pvu6HqtQGZmdyOpPD1FY00Z5WS1TRqaSm9qH8toW2lw+Gk+1UdvqPZsQv89fb8Z3jrK33/Wu4+9NLnX9Ymt7e4YL5hHRyyDtzHchzioX3/mcaVkvpOPc65cCOaPj3HVnHFpcKo8APDgrl+wBSTz40ieMTInmoV9MJxBUKa2s55lVe3j01rFkZyTjDwR5d8NXTB6TyZLXtjAmLYYbJw/htyu3c9PYVGZNyeO+Ff/AbpZ58w+34PMHOVJey+vr9vHMr2aGbFqSWPT8h9w7ZwSf7Slje0UzMVaF/3moAJMiY1IUHv7TBho6fDy7cDoJcVEIBCtXb2f6uEEseXUL9984FHenj5c3l5wFCTfLDBucitViJj3Gjt2qcOJkM8te38Iby+bxy5m5OMJsFCx7B59mMLF/FNFRzq7WUyE6yoFZEowfORBdN8jPjKOktoXmlnZueXIdumHw+q+v57Odxfzl8zJ+UzCEpXdMQgB2q4Ik4Hd3TuBAURXL13/NvZMzWHrndaExU3UDdzz3MQHDINYiM3vKMOaN6s/QnBQefGFDT9PKiAsjGNTYX3SM2RNzukaUabz39G0UH60lvV88B785jiIEDkVCCEhNjud/H57LPTdNQpZl+oSZsFstfLqjiKn52QgEyYlx/N/Ds1kyZyjREQ4+PVCDVRZs2lvJNfExSF32E26WSUmKZ+PuCqyyYOvhOhwOGwmx0azeVsrCqZms/908JmfFs/L9XfzXz6fz0dZDfNtVp3WDzJ44CMPQiXDayM1JwaTIfF1SxVOvbGBAagItbW5Skvr0qIqraxtZ8ORaXlu1DU3TKMgfgKzIpPWLJaVfPA6rQl19E3c8s54XNxShajp56X0AGJERx+nWdvSu2YAnqNPS7mJEZkLoJaZEEwgE8QeCjBoYx7s7K6lvbCExPpyyRhc19U3sKK7v6SNRFpmMtGv4/V82Ud/hZ+XS2STEOJEkQUl9OzaLmfc+K2LR7ZPZ8Myt+AMB1mwsRJIk7IqELElIksSYYRm8tuoLdh47zSsPRDBmUCIZ6Uls/O/bqalr4q9rd/HAHdO5ucCL1WJmxRsfc9f8sSy6+wbu8wX4eOtBFswey+ypedhsFp5/azOBoM6iX0zntrkSToedorI6EAJJiB5ztO7w267qhCsSAuhQdaySIKAbOBSJtqBOhEnCpxn0d5oJaDqnvCpe3SBckdAM6NR0DOjW4dEMFAH1gVB/4ZQFMV06ro0L4+C3bhyKhEvVaVZDp5JolgjqMLxvGPsb3Ti6isoOVae/w0ytO4Ctq7g893kvK49c/Xv6KshVkKsgV0F+TPl/IJTN3Sdk+IkAAAAASUVORK5CYII='

            
            DRS_context_table =  self.dlg.DRS_Context_Sheets_MapLayerComboBox.currentLayer()   
            output_folder = self.dlg.output_folder_QgsFileWidget.filePath()
            print ('output_folder',output_folder)
            
            sitecode = QgsExpressionContextUtils.projectScope(QgsProject.instance()).variable('sitecode')

            if sitecode == None:
                sitecode = ''
            if sitecode != None:
                if len(sitecode)== 0:
                    sitecode = ''
                    
            



            for f in DRS_context_table.selectedFeatures():
                context_no = f['Context']
                if f['Category'] == 'Cremation':
                    extra_definition = ' and Cremation'
                    
                if f['Type'] == 'Timber':
                    extra_definition = ' and Timber'
                
                if f['Type'] == 'Masonry':
                    extra_definition = ' and Masonry'
                
                if f['Type'] == 'Skeleton':
                    extra_definition = ' and Skeleton'

                if f['Type'] == 'Coffin':
                    extra_definition = ' and Coffin'
                    
                else:
                    extra_definition = ''
                
                    
                if f['Type'] == 'Cut':       #cut only
                    cut_description_section = """
                        <pround3><strong>Cut description</strong></pround3>
                        <p>
                        <strong>Shape:   </strong>"""+str(self.check_nulls(f['Shape']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Sides:   </strong>"""+str(self.check_nulls(f['Sides']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Base:   </strong>"""+str(self.check_nulls(f['Base']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Orientation:   </strong>"""+str(self.check_nulls(f['Orientation']))+"""
                        </p>
                        <p>
                        <strong>Cuts:   </strong>"""+str(self.check_nulls(f['Cuts']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Cut by:   </strong>"""+str(self.check_nulls(f['Cut_by']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Number of fills:   </strong>"""+str(self.check_nulls(f['Number_of_fills']))+"""
                        </p>
                        
                        
                        <p>
                        <strong>Interpretation:   </strong>"""+str(self.check_nulls(f['Interpretation']))+"""
                        </p><p> 
                        <strong>Additional comments:   </strong>"""+str(self.check_nulls(f['Additional_comments']))+"""
                        </p><p>
                        <strong>Provisional dating:   </strong>"""+str(self.check_nulls(f['Provisional_dating']))+"""
                        </p>
                        """
                else:
                    cut_description_section = ''


                if f['Type'] == 'Fill' or f['Type'] == 'Layer':
                    fill_description_section = """
                        <pround3><strong>Fill/Layer description</strong></pround3>
                        <p>
                        <strong>Compaction:   </strong>"""+str(self.check_nulls(f['Compaction']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Colour:   </strong>"""+str(self.check_nulls(f['Tone']))+""" """+ str(self.check_nulls(f['Hue']))+""" """+str(self.check_nulls(f['Colour']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Composition:   </strong>"""+str(self.check_nulls(f['Composition']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Significant Inclusions:   </strong>"""+str(self.check_nulls(f['Significant_ Inclusions']))+"""
                        </p>
                                  
                        <p>
                        <strong>Fill sequence:   </strong>"""+str(self.check_nulls(f['Fill_Sequence']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Same as:   </strong>"""+str(self.check_nulls(f['Same_as']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Equivalent to:   </strong>"""+str(self.check_nulls(f['Equivalent_to']))+"""
                        </p>
                        <p>
                        <strong>Formation:   </strong>"""+str(self.check_nulls(f['Formation']))+"""
                        </p>
                        <p>
                        <strong>Additional comments:   </strong>"""+str(self.check_nulls(f['Additional_comments']))+"""
                        </p>
                        <p> 
                        <strong>Provisional dating:   </strong>"""+str(self.check_nulls(f['Provisional_dating']))+"""
                        </p>
                        """
                else:
                    fill_description_section = ''
                
                if f['Category'] == 'Cremation':
                    cremation_description_section = """
                        <hr>
                        <pround3><strong>Cremation description</strong></pround3>
                        <p>
                        <strong>Cremation type:   </strong>"""+str(self.check_nulls(f['Cremation_type']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Cremation truncation:   </strong>"""+str(self.check_nulls(f['Cremation_truncation']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Urn Number:   </strong>"""+str(self.check_nulls(f['Urn_Number']))+"""
                        </p><p>
                        <strong>Cremation grave goods:   </strong>"""+str(self.check_nulls(f['Crem_grave_goods']))+"""
                        </p>
                        
                        """
                else:
                    cremation_description_section = ''
                
                if f['Type'] == 'Skeleton':       #skeleton only
                    skeleton_description_section = """
                        <pround3><strong>Skeleton description</strong></pround3>
                        <p>
                        <strong>Head at:   </strong>"""+str(self.check_nulls(f['Head_at']))+"""
                        </p><p>
                        <strong>Skeleton attitude:   </strong>"""+str(self.check_nulls(f['Skeleton_attitude']))+"""
                        </p><p>
                        <strong>Head:   </strong>"""+str(self.check_nulls(f['Head']))+"""
                        </p><p> 
                        <strong>Right arm:   </strong>"""+str(self.check_nulls(f['Right_arm']))+"""
                        </p><p> 
                        <strong>Left arm:   </strong>"""+str(self.check_nulls(f['Left_arm']))+"""
                        </p><p> 
                        <strong>Right leg:   </strong>"""+str(self.check_nulls(f['Right_leg']))+"""
                        </p><p> 
                        <strong>Left leg:   </strong>"""+str(self.check_nulls(f['Left_leg']))+"""
                        </p><p> 
                        <strong>Feet:   </strong>"""+str(self.check_nulls(f['Feet']))+"""
                        </p><p>
                        <strong>Skeleton preservation:   </strong>"""+str(self.check_nulls(f['Skeleton_preservation']))+"""
                        </p>
                                 
                        
                        <p>
                        <strong>Additional comments:   </strong>"""+str(self.check_nulls(f['Additional_comments']))+"""
                        </p><p>
                        <strong>Provisional dating:   </strong>"""+str(self.check_nulls(f['Provisional_dating']))+"""
                        </p>
                        """
                else:
                    skeleton_description_section = ''

                html_content = """
                <html>
                    <style>
                    p {
                    font-family: Arial;
                    font-size: 12px;
                    }
                    
                    mytitle {
                    font-family: Arial;
                    font-size: 20px;
                    
                    }
                    
                    pround3 {
                    font-family: Arial;
                    font-size: 13px;
                    border: 1px solid black;
                    border-radius: 5px;
                    padding: 5px
                    }
                    
                    pcontext {
                    font-family: Arial;
                    font-size: 15px;
                    border: 1px solid black;
                    border-radius: 5px;
                    padding: 5px
                    }
                   
                    </style>
                    <head>
                        <title>"""+sitecode+""" - PCA DRS Context Sheet No """+str(context_no)+ """"</title>
                    </head>
                    <body>
                        <mytitle><img src=data:image/svg;base64,"""+ str(pcaLogo_base64,'utf-8') +""">&nbsp;&nbsp;&nbsp; <strong>DRS PCA Context"""+extra_definition+""" Sheet</strong> </mytitle>
                        <br>
                        <hr width= "50%" color="white" size="2">
                        <pcontext>Context No: <strong>"""+str(context_no)+"""</strong></pcontext>
                        <br><br>
                        <p>
                        
                        <strong>Sitecode:   </strong>"""+str(sitecode)+"""  
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <strong>Area/Trench:   </strong>"""+str(self.check_nulls(f['Trench']))+""" 
                        </p>
                        <hr>
                        <p>
                        <strong>Cut No:   </strong>"""+str(self.check_nulls(f['Cut']))+"""  
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Type:   </strong>"""+str(self.check_nulls(f['Type']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Category:   </strong>"""+str(self.check_nulls(f['Category']))+"""
                        </p>
                        
                        <p>
                        <strong>Plan No:   </strong>"""+str(self.check_nulls(f['Plan']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Section No:   </strong>"""+str(self.check_nulls(f['Section']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Additional Section No:   </strong>"""+str(self.check_nulls(f['Additional_Sections']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Section Sheet:   </strong>"""+str(self.check_nulls(f['Section_Sheet']))+"""
                        </p>
                    
                        <p>
                        <strong>Camera Set No:   </strong>"""+str(self.check_nulls(f['Camera_set_number']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Photos No:   </strong>"""+str(self.check_nulls(f['Photo_numbers']))+"""
                        </p>
                        <hr>
                
                        
                        <pround3><strong>Measures</strong></pround3>
                        <p>
                        <strong>Length:   </strong>"""+str(self.check_nulls(f['Length']))+""" m"""+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Width:   </strong>"""+str(self.check_nulls(f['Width']))+""" m"""+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Depth:   </strong>"""+str(self.check_nulls(f['Depth']))+""" m"""+"""
                        </p>
                        <hr>
                        
                        <p>
                        <strong>Stratigraphically above:   </strong>"""+str(self.check_nulls(f['Stratigraphically_above']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Stratigraphically below:   </strong>"""+str(self.check_nulls(f['Stratigraphically_below']))+"""
                        </p>
                        <hr>
                        
                        """ +cut_description_section + cremation_description_section+fill_description_section +skeleton_description_section+"""

                        <hr>
                        <pround3><strong>Find and samples</strong></pround3>
                        <p>
                        <strong>Enviromental samples:   </strong>"""+str(self.check_nulls(f['Enviro_samples']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Other samples:   </strong>"""+str(self.check_nulls(f['Other_samples']))+"""
                        </p>
                        <p>
                        <strong>Finds:   </strong>"""+str(self.check_nulls(f['Finds']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Small Finds:   </strong>"""+str(self.check_nulls(f['Small_Finds']))+"""
                        </p>
                        <hr>
                        <pround3><strong>Attachments</strong></pround3>
                        <p>
                        <strong>Feature photo:   </strong> <a href="""+str(self.check_nulls(f['Feature_photo']))+""">"""+str(self.check_nulls(f['Feature_photo']))+"""</a>
                        </p><p> 
                        <strong>Sketch plan:   </strong> <a href="""+str(self.check_nulls(f['Sketch_plan']))+""">"""+str(self.check_nulls(f['Sketch_plan']))+"""</a>     
                        </p>
                        
                        <hr color="black" size="2">
                        <pround3><strong>Recording</strong></pround3>
                        <p>
                        <strong>Excavated by:   </strong>"""+str(self.check_nulls(f['Excavated_by']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Recorded by:   </strong>"""+str(self.check_nulls(f['Recorded_by']))+"""
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <strong>Recorded at:   </strong>"""+str(self.check_nulls(f['Timestamp']))+"""
                        </p>
                        
                    </body>
                </html>
                """

                pdf_filename = '{}_PCA_DRS_Context_Sheet_{}.pdf'.format(sitecode, str(context_no))
                # Save the HTML report to a file
                output_pdf_name = os.path.join(output_folder,pdf_filename)

   
                # Create BytesIO object
                output_pdf = BytesIO()

                # Convert HTML to PDF
                pisa.CreatePDF(html_content, dest=output_pdf)

                # Get the PDF content from BytesIO
                pdf_data = output_pdf.getvalue()

                # Save the PDF to a file
                with open(output_pdf_name, "wb") as f:
                    f.write(pdf_data)

                webbrowser.open_new(output_pdf_name)


    def dontdonothing(self):
                pass
                
                
  


