# -*- coding: utf-8 -*-
"""Small compatibility helpers for QGIS 3 / Qt5 and QGIS 4 / Qt6."""


def exec_dialog(dialog):
    """Execute a Qt dialog using the Qt6 name when available."""
    if hasattr(dialog, "exec"):
        return dialog.exec()
    return dialog.exec_()
