# -*- coding: utf-8 -*-
"""Native QGIS print-layout exporter for PCA DRS context sheets.

This module intentionally avoids external PDF/HTML libraries. It creates a real
QGIS print layout and exports it through QgsLayoutExporter.
"""

import os
import re
from pathlib import Path

from datetime import datetime
from qgis.core import QgsApplication

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    NULL,
    QgsExpressionContextUtils,
    QgsLayoutExporter,
    QgsLayoutItemLabel,
    QgsLayoutItemPage,
    QgsLayoutItemPicture,
    QgsLayoutItemShape,
    QgsLayoutMeasurement,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsPrintLayout,
    QgsProject,
    QgsTextFormat,
    QgsUnitTypes,
)

MM = QgsUnitTypes.LayoutMillimeters

# Qt5 / Qt6 alignment compatibility.
try:
    ALIGN_LEFT = Qt.AlignmentFlag.AlignLeft
    ALIGN_RIGHT = Qt.AlignmentFlag.AlignRight
    ALIGN_HCENTER = Qt.AlignmentFlag.AlignHCenter
    ALIGN_TOP = Qt.AlignmentFlag.AlignTop
    ALIGN_BOTTOM = Qt.AlignmentFlag.AlignBottom
    ALIGN_VCENTER = Qt.AlignmentFlag.AlignVCenter
except AttributeError:
    ALIGN_LEFT = Qt.AlignLeft
    ALIGN_RIGHT = Qt.AlignRight
    ALIGN_HCENTER = Qt.AlignHCenter
    ALIGN_TOP = Qt.AlignTop
    ALIGN_BOTTOM = Qt.AlignBottom
    ALIGN_VCENTER = Qt.AlignVCenter
    
PAGE_WIDTH = 210.0
PAGE_HEIGHT = 297.0
MARGIN = 10.0
CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2)

SECTION_FILL = QColor(236, 241, 245)
SECTION_STROKE = QColor(150, 165, 175)
BOX_STROKE = QColor(75, 75, 75)
TEXT_COLOR = QColor(25, 25, 25)
VALUE_COLOR = QColor(35, 35, 35)
MUTED_COLOR = QColor(95, 95, 95)


_FIELD_NAME_ALIASES = {
    "Small_finds": ["Small_Finds"],
    "Inclusions": ["Significant_ Inclusions"],
    "Significant_inclusions": ["Significant_ Inclusions"],
    "Colour_combined": ["Tone", "Hue", "Colour"],
    "Description": [
        "Shape",
        "Sides",
        "Base",
        "Composition",
        "Compaction",
        "Significant_ Inclusions",
        "Formation",
        "Fill_Sequence",
        "Coffin_Description",
        "Timber_structure",
        "Masonry_structure",
    ],
    "Completeness": ["Skeleton_preservation"],
    "Filled_by": ["Fill_Sequence"],
}


def _normalise_field_name(name):
    """Return a simplified field name for tolerant field-name matching."""
    return str(name).replace(" ", "").replace("_", "").lower()


def _resolve_field_name(feature, field_name):
    """Resolve a requested field name against the actual feature fields."""
    field_names = feature.fields().names()

    if field_name in field_names:
        return field_name

    requested = _normalise_field_name(field_name)
    for existing_name in field_names:
        if _normalise_field_name(existing_name) == requested:
            return existing_name

    return None


def safe_value(feature, field_name, fallback="-"):
    """Safely return a printable value from a feature field or field alias list."""
    candidate_names = _FIELD_NAME_ALIASES.get(field_name, [field_name])

    values = []
    for candidate_name in candidate_names:
        resolved_name = _resolve_field_name(feature, candidate_name)
        if not resolved_name:
            continue

        value = feature[resolved_name]
        if value is None or value == NULL:
            continue

        text = str(value).strip()
        if text:
            values.append(text)

    return " ".join(values) if values else fallback


def project_sitecode():
    """Return the project-level sitecode variable, if available."""
    value = QgsExpressionContextUtils.projectScope(QgsProject.instance()).variable("sitecode")
    return str(value).strip() if value else ""


def filename_safe(value):
    """Return a Windows-safe file-name component."""
    text = str(value).strip() if value is not None else "context"
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_") or "context"


def _font(size, bold=False, italic=False):
    font = QFont("Arial", size)
    font.setBold(bool(bold))
    font.setItalic(bool(italic))
    return font


def _add_label(
    layout,
    text,
    x,
    y,
    width,
    height,
    font=None,
    color=None,
    align=None,
    page_offset=0.0,
):
    label = QgsLayoutItemLabel(layout)
    label.setText(str(text))
    
    if align is None:
        align = ALIGN_LEFT | ALIGN_TOP

    text_font = font or _font(8)
    text_color = color or TEXT_COLOR

    text_format = QgsTextFormat()
    text_format.setFont(text_font)
    text_format.setSize(text_font.pointSizeF() if text_font.pointSizeF() > 0 else text_font.pointSize())
    text_format.setColor(text_color)
    label.setTextFormat(text_format)

    label.setHAlign(
        ALIGN_LEFT
        if align & ALIGN_LEFT
        else ALIGN_HCENTER
        if align & ALIGN_HCENTER
        else ALIGN_RIGHT
    )

    label.setVAlign(
        ALIGN_TOP
        if align & ALIGN_TOP
        else ALIGN_VCENTER
        if align & ALIGN_VCENTER
        else ALIGN_BOTTOM
    )

    layout.addLayoutItem(label)
    label.attemptMove(QgsLayoutPoint(x, y + page_offset, MM))
    label.attemptResize(QgsLayoutSize(width, height, MM))

    return label


def _add_box(layout, x, y, width, height, page_offset=0.0, fill=None, stroke=None, stroke_width=0.25):
    shape = QgsLayoutItemShape(layout)
    shape.setShapeType(QgsLayoutItemShape.Rectangle)
    shape.attemptMove(QgsLayoutPoint(x, y + page_offset, MM))
    shape.attemptResize(QgsLayoutSize(width, height, MM))
    shape.setBackgroundEnabled(True)
    shape.setBackgroundColor(fill or QColor(255, 255, 255))
    shape.setFrameEnabled(True)
    shape.setFrameStrokeColor(stroke or BOX_STROKE)
    shape.setFrameStrokeWidth(QgsLayoutMeasurement(stroke_width, MM))
    layout.addLayoutItem(shape)
    return shape


def _add_section_header(layout, title, x, y, width, page_offset=0.0):
    _add_box(layout, x, y, width, 6.5, page_offset, fill=SECTION_FILL, stroke=SECTION_STROKE, stroke_width=0.2)
    _add_label(layout, title, x + 2.2, y + 1.3, width - 4.4, 4.2, _font(8, bold=True), TEXT_COLOR, page_offset=page_offset)


def _add_field(layout, feature, field_name, label, x, y, label_width, value_width, page_offset=0.0, suffix=""):
    value = safe_value(feature, field_name)

    if value != "-" and suffix:
        value = "{} {}".format(value, suffix)

    _add_label(layout, label + ":", x, y, label_width, 4.8, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_label(layout, value, x + label_width + 1.2, y, value_width, 4.8, _font(7), VALUE_COLOR, page_offset=page_offset)


def _add_text_block(layout, feature, field_name, title, x, y, width, height, page_offset=0.0):
    _add_label(layout, title + ":", x, y, width, 4.6, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)

    value = safe_value(feature, field_name)

    _add_box(
        layout,
        x,
        y + 4.8,
        width,
        height - 4.8,
        page_offset,
        fill=QColor(255, 255, 255),
        stroke=QColor(210, 210, 210),
        stroke_width=0.15,
    )
    _add_label(layout, value, x + 1.8, y + 6.2, width - 3.6, height - 7.2, _font(6), VALUE_COLOR, page_offset=page_offset)


def _add_row_fields(layout, feature, fields, x, y, page_offset=0.0):
    """Add a row of labelled fields with even column widths."""
    if not fields:
        return

    col_width = CONTENT_WIDTH / len(fields)

    for index, item in enumerate(fields):
        field_name, label = item[0], item[1]
        suffix = item[2] if len(item) > 2 else ""

        _add_field(
            layout,
            feature,
            field_name,
            label,
            x + (index * col_width),
            y,
            col_width * 0.42,
            col_width * 0.52,
            page_offset,
            suffix,
        )


def _context_subtitle(feature):
    category = safe_value(feature, "Category", "").lower()
    context_type = safe_value(feature, "Type", "").lower()

    if "cremation" in category:
        return " and Cremation"

    lookup = {
        "timber": " and Timber",
        "masonry": " and Masonry",
        "skeleton": " and Skeleton",
        "coffin": " and Coffin",
    }

    return lookup.get(context_type, "")

def _page_y_offset(layout, page_index):
    """
    Return the real Y offset of a layout page.

    Do not calculate this as PAGE_HEIGHT * page_index because QGIS layouts
    include internal page spacing between pages.
    """
    page = layout.pageCollection().page(page_index)
    if page is None:
        return PAGE_HEIGHT * page_index

    return page.pos().y()

def current_username():
    """
    Return the current QGIS / OS username.
    """
    user = QgsApplication.userFullName()

    if user and str(user).strip():
        return str(user).strip()

    return os.getenv("USERNAME") or os.getenv("USER") or "Unknown User"


def export_timestamp():
    """
    Return a formatted export timestamp.
    """
    return datetime.now().strftime("%d/%m/%Y %H:%M")
    
def add_context_sheet_page(layout, feature, page_index, sitecode, logo_path=None):
    """Add one context sheet page to an existing QgsPrintLayout."""
    if page_index > 0:
        page = QgsLayoutItemPage(layout)
        page.setPageSize("A4", QgsLayoutItemPage.Portrait)
        layout.pageCollection().addPage(page)

    page_offset = _page_y_offset(layout, page_index)

    if logo_path and os.path.exists(logo_path):
        picture = QgsLayoutItemPicture(layout)
        picture.setPicturePath(logo_path)
        layout.addLayoutItem(picture)
        picture.attemptMove(QgsLayoutPoint(MARGIN, 9 + page_offset, MM))
        picture.attemptResize(QgsLayoutSize(16, 16, MM))

    context_no = safe_value(feature, "Context")
    title = "DRS PCA Context{} Sheet".format(_context_subtitle(feature))

    _add_label(layout, title, 30, 10, 118, 9, _font(15, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_label(layout, "Sitecode: {}".format(sitecode or "-"), 30, 20, 70, 5, _font(7), MUTED_COLOR, page_offset=page_offset)

    _add_box(layout, 152, 10, 48, 16, page_offset, fill=QColor(255, 255, 255), stroke=BOX_STROKE, stroke_width=0.35)
    _add_label(layout, "Context No", 155, 12, 18, 4, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_label(
        layout,
        context_no,
        174,
        11.6,
        23,
        8,
        _font(13, bold=True),
        TEXT_COLOR,
        align=ALIGN_HCENTER | ALIGN_VCENTER,
        page_offset=page_offset,
    )

    y = 31

    _add_section_header(layout, "Identification", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(layout, feature, [("Trench", "Area/Trench"), ("Cut", "Cut No"), ("Type", "Type"), ("Category", "Category")], MARGIN, y, page_offset)
    y += 7
    _add_row_fields(layout, feature, [("Plan", "Plan No"), ("Section", "Section No"), ("Additional_Sections", "Additional Section No"), ("Section_Sheet", "Section Sheet")], MARGIN, y, page_offset)
    y += 7
    _add_row_fields(layout, feature, [("Camera_set_number", "Camera Set No"), ("Photo_numbers", "Photos No")], MARGIN, y, page_offset)
    y += 9

    _add_section_header(layout, "Measures and stratigraphy", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(layout, feature, [("Length", "Length", "m"), ("Width", "Width", "m"), ("Depth", "Depth", "m")], MARGIN, y, page_offset)
    y += 7
    _add_row_fields(layout, feature, [("Stratigraphically_above", "Stratigraphically above"), ("Stratigraphically_below", "Stratigraphically below")], MARGIN, y, page_offset)
    y += 9

    context_type = safe_value(feature, "Type", "").lower()
    category = safe_value(feature, "Category", "").lower()

    if context_type == "cut":
        _add_section_header(layout, "Cut description", MARGIN, y, CONTENT_WIDTH, page_offset)
        y += 8
        _add_row_fields(layout, feature, [("Shape", "Shape"), ("Sides", "Sides"), ("Base", "Base"), ("Orientation", "Orientation")], MARGIN, y, page_offset)
        y += 7
        _add_row_fields(layout, feature, [("Cuts", "Cuts"), ("Cut_by", "Cut by"), ("Number_of_fills", "Number of fills")], MARGIN, y, page_offset)
        y += 8

    elif context_type in ("fill", "layer", "deposit"):
        _add_section_header(layout, "Deposit description", MARGIN, y, CONTENT_WIDTH, page_offset)
        y += 8
        _add_row_fields(layout, feature, [("Colour_combined", "Colour"), ("Composition", "Composition"), ("Compaction", "Compaction")], MARGIN, y, page_offset)
        y += 7
        _add_row_fields(layout, feature, [("Significant_ Inclusions", "Significant inclusions"), ("Formation", "Formation"), ("Fill_Sequence", "Fill sequence")], MARGIN, y, page_offset)
        y += 7
        _add_row_fields(layout, feature, [("Same_as", "Same as"), ("Equivalent_to", "Equivalent to")], MARGIN, y, page_offset)
        y += 8

    elif context_type == "skeleton":
        _add_section_header(layout, "Skeleton description", MARGIN, y, CONTENT_WIDTH, page_offset)
        y += 8
        _add_row_fields(layout, feature, [("Skeleton_preservation", "Preservation"), ("Condition", "Condition")], MARGIN, y, page_offset)
        y += 8

    elif "cremation" in category:
        _add_section_header(layout, "Cremation description", MARGIN, y, CONTENT_WIDTH, page_offset)
        y += 8
        _add_row_fields(layout, feature, [("Colour_combined", "Colour"), ("Compaction", "Compaction"), ("Significant_ Inclusions", "Significant inclusions")], MARGIN, y, page_offset)
        y += 8

    block_height = 21
    _add_text_block(layout, feature, "Interpretation", "Interpretation", MARGIN, y, CONTENT_WIDTH, block_height, page_offset)
    y += block_height + 2

    _add_text_block(layout, feature, "Description", "Description", MARGIN, y, CONTENT_WIDTH, block_height, page_offset)
    y += block_height + 2

    _add_text_block(layout, feature, "Additional_comments", "Additional comments", MARGIN, y, CONTENT_WIDTH, 18, page_offset)
    y += 20

    _add_section_header(layout, "Finds, samples and records", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(layout, feature, [("Enviro_samples", "Environmental samples"), ("Other_samples", "Other samples"), ("Finds", "Finds"), ("Small_Finds", "Small Finds")], MARGIN, y, page_offset)
    y += 7
    _add_row_fields(layout, feature, [("Feature_photo", "Feature photo"), ("Sketch_plan", "Sketch plan")], MARGIN, y, page_offset)
    y += 9

    _add_section_header(layout, "Recording", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(layout, feature, [("Excavated_by", "Excavated by"), ("Recorded_by", "Recorded by"), ("Timestamp", "Recorded at")], MARGIN, y, page_offset)
    y += 7
    _add_row_fields(layout, feature, [("Provisional_dating", "Provisional dating")], MARGIN, y, page_offset)

    footer_text = (
        "PCA DRS Context Sheet Printer • "
        "{} • {}"
    ).format(
        current_username(),
        export_timestamp(),
    )

    _add_label(
        layout,
        footer_text,
        MARGIN,
        288,
        CONTENT_WIDTH,
        4,
        _font(6, italic=True),
        MUTED_COLOR,
        align=ALIGN_HCENTER | ALIGN_VCENTER,
        page_offset=page_offset,
    )

def _ensure_output_file_is_writable(output_pdf):
    """
    Raise a clear error if the target PDF cannot be written.

    On Windows, an open PDF is often locked by the PDF viewer, which causes
    QgsLayoutExporter to fail with exporter code 3.
    """
    output_pdf = Path(output_pdf)

    if not output_pdf.exists():
        return

    try:
        with output_pdf.open("ab"):
            pass
    except PermissionError:
        raise PermissionError(
            "The PDF file is already open or locked:\n\n"
            "{}\n\n"
            "Please close the PDF and try again.".format(output_pdf)
        )

def export_context_sheets(
    features,
    output_folder,
    sitecode=None,
    combined=True,
    logo_path=None,
    print_mode="selected",
    progress_callback=None,
):
    """Export context sheets to PDF using a native QGIS print layout."""
    if not features:
        raise ValueError("No context records were found for printing.")

    output_dir = Path(output_folder)
    output_dir.mkdir(parents=True, exist_ok=True)

    sitecode = sitecode if sitecode is not None else project_sitecode()
    sitecode_part = filename_safe(sitecode or "Site")

    if combined:
        layout = QgsPrintLayout(QgsProject.instance())
        layout.initializeDefaults()
        layout.setName("PCA DRS Context Sheets Export")
        layout.pageCollection().page(0).setPageSize("A4", QgsLayoutItemPage.Portrait)

        total = len(features)

        for index, feature in enumerate(features):
            add_context_sheet_page(layout, feature, index, sitecode, logo_path)

            if progress_callback:
                if progress_callback(index + 1, total, "Preparing context sheet {} of {}".format(index + 1, total)):
                    raise RuntimeError("Export cancelled by user.")
        
        context_values = []

        for feature in features:
            context_value = safe_value(feature, "Context", "")
            if context_value and context_value != "-":
                context_values.append(str(context_value))

        record_count = len(context_values)

        if print_mode == "all":
            context_part = "All_{}records".format(record_count)

        elif record_count == 1:
            context_part = context_values[0]

        elif record_count <= 5:
            context_part = "_".join(context_values)

        elif context_values:
            context_part = "{}_to_{}_{}records".format(
                context_values[0],
                context_values[-1],
                record_count,
            )

        else:
            context_part = "contexts"

        output_pdf = output_dir / "{}_DRS_Context_Sheets_{}.pdf".format(
            sitecode_part,
            filename_safe(context_part),
        )
        
        _ensure_output_file_is_writable(output_pdf)

        exporter = QgsLayoutExporter(layout)
        result = exporter.exportToPdf(str(output_pdf), QgsLayoutExporter.PdfExportSettings())

        if result != QgsLayoutExporter.Success:
            raise RuntimeError("PDF export failed with QGIS exporter code: {}".format(result))

        return [str(output_pdf)]

    exported = []

    for feature in features:
        layout = QgsPrintLayout(QgsProject.instance())
        layout.initializeDefaults()
        layout.setName("PCA DRS Context Sheet Export")
        layout.pageCollection().page(0).setPageSize("A4", QgsLayoutItemPage.Portrait)

        add_context_sheet_page(layout, feature, 0, sitecode, logo_path)

        context_no = filename_safe(safe_value(feature, "Context"))
        output_pdf = output_dir / "{}_DRS_Context_Sheet_{}.pdf".format(
            sitecode_part,
            context_no,
        )

        _ensure_output_file_is_writable(output_pdf)

        exporter = QgsLayoutExporter(layout)
        result = exporter.exportToPdf(str(output_pdf), QgsLayoutExporter.PdfExportSettings())

        if result != QgsLayoutExporter.Success:
            raise RuntimeError("PDF export failed for context {} with QGIS exporter code: {}".format(context_no, result))

        exported.append(str(output_pdf))
        
        if progress_callback:
            if progress_callback(len(exported), len(features), "Exported context sheet {} of {}".format(len(exported), len(features))):
                raise RuntimeError("Export cancelled by user.")

    return exported