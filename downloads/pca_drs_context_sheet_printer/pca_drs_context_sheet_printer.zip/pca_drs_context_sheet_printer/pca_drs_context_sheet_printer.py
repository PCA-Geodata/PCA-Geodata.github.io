# -*- coding: utf-8 -*-
"""PCA DRS Context Sheet Printer plugin.

Refactored to use native QGIS print layouts instead of external HTML/PDF
libraries. This keeps the plugin autonomous across supported QGIS versions.
"""

import os
import webbrowser

from qgis.PyQt.QtCore import Qt, QCoreApplication, QSettings, QTranslator
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QToolBar, QProgressDialog
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject, QgsExpressionContextUtils

from .compat import exec_dialog
from .context_sheet_layout import export_context_sheets, project_sitecode, safe_value
from .pca_drs_context_sheet_printer_dialog import PCADRSContextSheetPrinterDialog
from .range_parser import parse_context_range
from .pca_drs_trench_sheet_printer_dialog import PCADRSTrenchSheetPrinterDialog
from .trench_sheet_layout import export_trench_sheets
from .resources import *  # noqa: F401,F403 - required for Qt resource icons

try:
    WINDOW_MODAL = Qt.WindowModality.WindowModal
except AttributeError:
    WINDOW_MODAL = Qt.WindowModal
    
class PCADRSContextSheetPrinter:
    """QGIS plugin implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr("&PCA DRS Context Sheet Printer")
        self.dlg = None
        self.trench_dlg = None

        locale = QSettings().value("locale/userLocale", "")[:2]
        locale_path = os.path.join(self.plugin_dir, "i18n", "PCADRSContextSheetPrinter_{}.qm".format(locale))
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)
            
        # Read plugin version from metadata
        self.plugin_version = self._read_plugin_version()

        self.toolbar = iface.mainWindow().findChild(QToolBar, "PCA DRS Context Sheet Printer")
        if self.toolbar is None:
            self.toolbar = iface.addToolBar("PCA DRS Context Sheet Printer")
            self.toolbar.setObjectName("PCA DRS Context Sheet Printer")

    def tr(self, message):
        return QCoreApplication.translate("PCADRSContextSheetPrinter", message)

    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        self.add_action(
            ":/plugins/pca_drs_context_sheet_printer/icons/PCA_logo_icon.png",
            self.tr(f"PCA DRS Context Sheet Printer – version {self.plugin_version}"),
            self.noop,
            parent=self.iface.mainWindow(),
        ) 
        
        self.add_action(
            ":/plugins/pca_drs_context_sheet_printer/icons/PCA_DRS_context_printer_icon.png",
            self.tr("PCA DRS Context Sheet Printer"),
            self.open_print_dialog,
            parent=self.iface.mainWindow(),
        )
        
        self.add_action(
            ":/plugins/pca_drs_context_sheet_printer/icons/PCA_DRS_trench_printer_icon.png",
            self.tr("PCA DRS Trench Sheet Printer"),
            self.open_trench_print_dialog,
            parent=self.iface.mainWindow(),
        )

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)

    def _read_plugin_version(self):
        """
        Read plugin version directly from metadata.txt.
        Safe and works in QGIS 3 and QGIS 4.
        """
        metadata_path = os.path.join(self.plugin_dir, 'metadata.txt')

        if not os.path.exists(metadata_path):
            print("metadata.txt not found!")
            return "unknown"

        version = "unknown"

        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                        break
        except Exception as e:
            print(f"Could not read metadata.txt: {e}")

        return version
        
    def _default_layer(self):
        """Return the preferred DRS context table if present in the project."""
        for name in ("DRS_Context_Database", "DRS_Table"):
            layers = QgsProject.instance().mapLayersByName(name)
            if layers:
                return layers[0]
        return None

    def _default_trench_layer(self):
        """Return the DRS trench table if present in the project."""
        layers = QgsProject.instance().mapLayersByName("DRS_Trench_Database")
        if layers:
            return layers[0]
        return None
    
    def _features_for_dialog_options(self, layer, mode, range_text):
        """Return the features requested by the print dialog."""
        if mode == PCADRSContextSheetPrinterDialog.MODE_SELECTED:
            features = list(layer.selectedFeatures())
            if not features:
                raise ValueError("No records are selected in the chosen context table.")
            return features

        if mode == PCADRSContextSheetPrinterDialog.MODE_ALL:
            return list(layer.getFeatures())

        if mode == PCADRSContextSheetPrinterDialog.MODE_RANGE:
            wanted_contexts = set(parse_context_range(range_text))
            if "Context" not in layer.fields().names():
                raise ValueError("The selected table does not contain a 'Context' field.")

            features = []
            for feature in layer.getFeatures():
                try:
                    context_value = int(feature["Context"])
                except (TypeError, ValueError):
                    continue

                if context_value in wanted_contexts:
                    features.append(feature)

            found = {int(feature["Context"]) for feature in features if str(feature["Context"]).isdigit()}
            missing = sorted(wanted_contexts.difference(found))
            if missing:
                raise ValueError("The following context numbers were not found: {}".format(", ".join(map(str, missing))))

            return features

        raise ValueError("Unknown print mode.")

    def _trench_features_for_dialog_options(self, layer, mode, range_text):
        """Return the trench features requested by the print dialog."""
        if layer.name() != "DRS_Trench_Database":
            raise ValueError("The selected table is not DRS_Trench_Database.")

        if "Trench_Number" not in layer.fields().names():
            raise ValueError("The selected table does not contain a 'Trench_Number' field.")

        if mode == PCADRSTrenchSheetPrinterDialog.MODE_SELECTED:
            features = list(layer.selectedFeatures())
            if not features:
                raise ValueError("No records are selected in the chosen trench table.")
            return features

        if mode == PCADRSTrenchSheetPrinterDialog.MODE_ALL:
            return list(layer.getFeatures())

        if mode == PCADRSTrenchSheetPrinterDialog.MODE_RANGE:
            wanted_trenches = set(parse_context_range(range_text))

            features = []
            for feature in layer.getFeatures():
                try:
                    trench_value = int(feature["Trench_Number"])
                except (TypeError, ValueError):
                    continue

                if trench_value in wanted_trenches:
                    features.append(feature)

            found = {
                int(feature["Trench_Number"])
                for feature in features
                if str(feature["Trench_Number"]).isdigit()
            }

            missing = sorted(wanted_trenches.difference(found))
            if missing:
                raise ValueError(
                    "The following trench numbers were not found: {}".format(
                        ", ".join(map(str, missing))
                    )
                )

            return features

        raise ValueError("Unknown trench print mode.")

    def open_print_dialog(self):
        if self.dlg is None:
            icon_path = os.path.join(
                self.plugin_dir,
                "icons",
                "PCA_DRS_context_printer_icon.png",
            )

            self.dlg = PCADRSContextSheetPrinterDialog(
                self.iface.mainWindow(),
                icon_path=icon_path,
            )

        default_layer = self._default_layer()
        if default_layer is not None:
            self.dlg.DRS_Context_Sheets_MapLayerComboBox.setLayer(default_layer)

        if not exec_dialog(self.dlg):
            return

        layer = self.dlg.current_layer()
        if layer is None:
            QMessageBox.warning(self.iface.mainWindow(), "Missing table", "Please select a valid DRS context table.")
            return

        try:
            features = self._features_for_dialog_options(layer, self.dlg.print_mode(), self.dlg.range_text())
            sitecode = project_sitecode()
            logo_path = os.path.join(self.plugin_dir, "icons", "PCA_logo_icon_black.png")
            
            progress = self._create_progress_dialog(
                "Exporting context sheets",
                "Preparing context sheets...",
                len(features),
            )
            exported_files = export_context_sheets(
                features=features,
                output_folder=self.dlg.output_folder(),
                sitecode=sitecode,
                combined=self.dlg.combined_pdf(),
                logo_path=logo_path,
                print_mode=self.dlg.print_mode(),
                progress_callback=self._progress_callback_factory(progress),
            )

            progress.setValue(progress.maximum())

        except Exception as exc:
            QMessageBox.critical(self.iface.mainWindow(), "PDF export failed", str(exc))
            return

        QMessageBox.information(
            self.iface.mainWindow(),
            "PDF export complete",
            "Created {} PDF file(s).".format(len(exported_files)),
        )

        if self.dlg.open_output_folder():
            webbrowser.open(os.path.dirname(exported_files[0]))

    def open_trench_print_dialog(self):
        """Open the print dialog and export DRS trench sheets."""
        if self.trench_dlg is None:
            icon_path = os.path.join(
                self.plugin_dir,
                "icons",
                "PCA_DRS_trench_printer_icon.png",
            )

            self.trench_dlg = PCADRSTrenchSheetPrinterDialog(
                self.iface.mainWindow(),
                icon_path=icon_path,
            )

        default_layer = self._default_trench_layer()
        if default_layer is not None:
            self.trench_dlg.DRS_Trench_Sheets_MapLayerComboBox.setLayer(default_layer)

        if not exec_dialog(self.trench_dlg):
            return

        layer = self.trench_dlg.current_layer()

        if layer is None:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Missing trench table",
                "Please select the DRS_Trench_Database table.",
            )
            return

        try:
            features = self._trench_features_for_dialog_options(
                layer,
                self.trench_dlg.print_mode(),
                self.trench_dlg.range_text(),
            )

            sitecode = project_sitecode()

            logo_path = os.path.join(
                self.plugin_dir,
                "icons",
                "PCA_logo_icon_black.png",
            )

            progress = self._create_progress_dialog(
                "Exporting trench sheets",
                "Preparing trench sheets...",
                len(features),
            )

            exported_files = export_trench_sheets(
                features=features,
                output_folder=self.trench_dlg.output_folder(),
                sitecode=sitecode,
                combined=self.trench_dlg.combined_pdf(),
                logo_path=logo_path,
                print_mode=self.trench_dlg.print_mode(),
                progress_callback=self._progress_callback_factory(progress),
            )

            progress.setValue(progress.maximum())

        except Exception as exc:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "PDF export failed",
                str(exc),
            )
            return

        QMessageBox.information(
            self.iface.mainWindow(),
            "PDF export complete",
            "Created {} PDF file(s).".format(len(exported_files)),
        )

        if self.trench_dlg.open_output_folder():
            webbrowser.open(os.path.dirname(exported_files[0]))

    def noop(self):
        pass
        
    def _create_progress_dialog(self, title, label, total):
        """Create a compact progress dialog for long PDF exports."""
        progress = QProgressDialog(label, "Cancel", 0, max(total, 1), self.iface.mainWindow())
        progress.setWindowTitle(title)
        progress.setWindowModality(WINDOW_MODAL)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        return progress


    def _progress_callback_factory(self, progress):
        """Return a callback used by PDF exporters."""
        def update_progress(current, total, message):
            progress.setMaximum(max(total, 1))
            progress.setLabelText(message)
            progress.setValue(current)
            QCoreApplication.processEvents()
            return progress.wasCanceled()

        return update_progress