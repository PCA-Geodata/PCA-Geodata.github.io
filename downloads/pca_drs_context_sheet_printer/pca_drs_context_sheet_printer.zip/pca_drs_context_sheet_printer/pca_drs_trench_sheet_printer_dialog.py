# -*- coding: utf-8 -*-
"""Print-style dialog for the PCA DRS Trench Sheet Printer."""

import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QRadioButton,
    QVBoxLayout,
)
from qgis.gui import QgsFileWidget, QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel, QgsProject


try:
    KEEP_ASPECT_RATIO = Qt.AspectRatioMode.KeepAspectRatio
    SMOOTH_TRANSFORMATION = Qt.TransformationMode.SmoothTransformation
except AttributeError:
    KEEP_ASPECT_RATIO = Qt.KeepAspectRatio
    SMOOTH_TRANSFORMATION = Qt.SmoothTransformation


class PCADRSTrenchSheetPrinterDialog(QDialog):
    """A compact print-style dialog for exporting trench sheets."""

    MODE_SELECTED = "selected"
    MODE_ALL = "all"
    MODE_RANGE = "range"

    def __init__(self, parent=None, icon_path=None):
        super().__init__(parent)
        self.icon_path = icon_path
        self.setWindowTitle("PCA DRS Trench Sheet Printer")
        self.setMinimumWidth(540)
        self.setModal(True)

        self._build_ui()
        self._connect_signals()
        self._apply_style()
        self._update_range_state()

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 18, 18, 16)
        main_layout.setSpacing(12)

        header_layout = QHBoxLayout()
        header_layout.setSpacing(10)

        icon_label = QLabel()
        icon_label.setObjectName("pluginIconLabel")
        icon_label.setFixedSize(75, 75)

        if self.icon_path and os.path.exists(self.icon_path):
            pixmap = QPixmap(self.icon_path)
            icon_label.setPixmap(
                pixmap.scaled(
                    75,
                    75,
                    KEEP_ASPECT_RATIO,
                    SMOOTH_TRANSFORMATION,
                )
            )

        title_block = QVBoxLayout()
        title_block.setSpacing(2)

        title = QLabel("PCA DRS Trench Sheet Printer")
        title.setObjectName("titleLabel")

        subtitle = QLabel("Export clean one-page PDF trench sheets from the DRS trench table.")
        subtitle.setObjectName("subtitleLabel")
        subtitle.setWordWrap(True)

        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addWidget(icon_label)
        header_layout.addLayout(title_block, 1)
        main_layout.addLayout(header_layout)

        layer_group = QGroupBox("Source")
        layer_layout = QFormLayout(layer_group)

        self.DRS_Trench_Sheets_MapLayerComboBox = QgsMapLayerComboBox()
        self.DRS_Trench_Sheets_MapLayerComboBox.setFilters(QgsMapLayerProxyModel.NoGeometry)
        self._populate_trench_table_combo()

        layer_layout.addRow("Trench table:", self.DRS_Trench_Sheets_MapLayerComboBox)
        main_layout.addWidget(layer_group)

        print_group = QGroupBox("Print")
        print_layout = QVBoxLayout(print_group)
        self.mode_group = QButtonGroup(self)

        self.selected_radio = QRadioButton("Selected records only")
        self.all_radio = QRadioButton("All records")
        self.range_radio = QRadioButton("Defined trench range")
        self.selected_radio.setChecked(True)

        self.mode_group.addButton(self.selected_radio)
        self.mode_group.addButton(self.all_radio)
        self.mode_group.addButton(self.range_radio)

        print_layout.addWidget(self.selected_radio)
        print_layout.addWidget(self.all_radio)

        range_row = QHBoxLayout()
        range_row.addWidget(self.range_radio)

        self.range_edit = QLineEdit()
        self.range_edit.setPlaceholderText("Example: 1-3, 6, 10-12")
        range_row.addWidget(self.range_edit, 1)

        print_layout.addLayout(range_row)
        main_layout.addWidget(print_group)

        output_group = QGroupBox("Output")
        output_layout = QFormLayout(output_group)

        self.output_folder_QgsFileWidget = QgsFileWidget()
        self.output_folder_QgsFileWidget.setStorageMode(QgsFileWidget.GetDirectory)
        output_layout.addRow("Output folder:", self.output_folder_QgsFileWidget)

        self.combined_pdf_check = QCheckBox("Create one combined PDF")
        self.combined_pdf_check.setChecked(True)

        self.open_folder_check = QCheckBox("Open output folder when complete")
        self.open_folder_check.setChecked(True)

        output_layout.addRow("", self.combined_pdf_check)
        output_layout.addRow("", self.open_folder_check)

        main_layout.addWidget(output_group)

        try:
            cancel_button = QDialogButtonBox.StandardButton.Cancel
            ok_button = QDialogButtonBox.StandardButton.Ok
        except AttributeError:
            cancel_button = QDialogButtonBox.Cancel
            ok_button = QDialogButtonBox.Ok

        self.button_box = QDialogButtonBox(cancel_button | ok_button)
        self.button_box.button(ok_button).setText("Print PDF")
        main_layout.addWidget(self.button_box)

    def _populate_trench_table_combo(self):
        """Restrict the layer selector to the valid DRS trench table only."""
        valid_names = {"DRS_Trench_Database"}
        project = QgsProject.instance()

        valid_layers = [
            layer
            for layer in project.mapLayers().values()
            if layer.name() in valid_names
        ]

        self.DRS_Trench_Sheets_MapLayerComboBox.setExceptedLayerList(
            [
                layer
                for layer in project.mapLayers().values()
                if layer not in valid_layers
            ]
        )

        if valid_layers:
            self.DRS_Trench_Sheets_MapLayerComboBox.setLayer(valid_layers[0])

    def _connect_signals(self):
        self.button_box.accepted.connect(self._validate_and_accept)
        self.button_box.rejected.connect(self.reject)
        self.selected_radio.toggled.connect(self._update_range_state)
        self.all_radio.toggled.connect(self._update_range_state)
        self.range_radio.toggled.connect(self._update_range_state)

    def _apply_style(self):
        """Apply compact light/dark compatible styling."""
        self.setStyleSheet("""
            QDialog {
                background-color: palette(window);
                color: palette(text);
            }

            QLabel {
                background: transparent;
                color: palette(text);
            }

            QLabel#pluginIconLabel {
                background: transparent;
            }

            QLabel#titleLabel {
                font-size: 16pt;
                font-weight: 700;
                letter-spacing: 0.3px;
                color: palette(text);
            }

            QLabel#subtitleLabel {
                color: palette(mid);
                font-size: 9pt;
                padding-top: 2px;
            }

            QGroupBox {
                font-weight: 600;
                font-size: 9pt;
                color: palette(text);
                border: 1px solid palette(mid);
                border-radius: 10px;
                margin-top: 12px;
                padding: 12px 10px 10px 10px;
                background-color: palette(alternate-base);
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 5px;
                color: palette(text);
                background-color: palette(window);
            }

            QgsMapLayerComboBox,
            QgsFileWidget,
            QComboBox,
            QLineEdit {
                min-height: 28px;
                border-radius: 7px;
                padding: 3px 8px;
                border: 1px solid palette(mid);
                background-color: palette(base);
                color: palette(text);
                selection-background-color: palette(highlight);
                selection-color: palette(highlighted-text);
            }

            QgsMapLayerComboBox:hover,
            QgsFileWidget:hover,
            QComboBox:hover,
            QLineEdit:hover {
                border: 1px solid palette(highlight);
            }

            QRadioButton,
            QCheckBox {
                spacing: 8px;
                padding: 2px;
                color: palette(text);
                background: transparent;
            }

            QRadioButton::indicator,
            QCheckBox::indicator {
                width: 15px;
                height: 15px;
            }

            QPushButton {
                min-width: 90px;
                min-height: 28px;
                border-radius: 8px;
                padding: 4px 14px;
                font-weight: 600;
                border: 1px solid palette(mid);
                background-color: palette(button);
                color: palette(button-text);
            }

            QPushButton:hover {
                border: 1px solid palette(highlight);
                background-color: palette(alternate-base);
            }

            QPushButton:pressed {
                background-color: palette(midlight);
            }
        """)

    def _update_range_state(self):
        self.range_edit.setEnabled(self.range_radio.isChecked())

    def _validate_and_accept(self):
        layer = self.current_layer()

        if layer is None:
            QMessageBox.warning(
                self,
                "Missing DRS trench table",
                "No valid DRS trench table was found in the project.\n\n"
                "The plugin requires:\n"
                "- DRS_Trench_Database",
            )
            return

        if layer.name() != "DRS_Trench_Database":
            QMessageBox.warning(
                self,
                "Invalid DRS trench table",
                "Please select the DRS_Trench_Database table.",
            )
            return

        if "Trench_Number" not in layer.fields().names():
            QMessageBox.warning(
                self,
                "Invalid trench table",
                "The selected table does not contain the required 'Trench_Number' field.",
            )
            return

        if not self.output_folder():
            QMessageBox.warning(
                self,
                "Missing output folder",
                "Please select an output folder for the PDF file.",
            )
            return

        if self.print_mode() == self.MODE_RANGE and not self.range_text().strip():
            QMessageBox.warning(
                self,
                "Missing range",
                "Please enter a trench range, for example: 1-3, 6.",
            )
            return

        self.accept()

    def current_layer(self):
        return self.DRS_Trench_Sheets_MapLayerComboBox.currentLayer()

    def output_folder(self):
        return self.output_folder_QgsFileWidget.filePath().strip()

    def range_text(self):
        return self.range_edit.text().strip()

    def print_mode(self):
        if self.all_radio.isChecked():
            return self.MODE_ALL
        if self.range_radio.isChecked():
            return self.MODE_RANGE
        return self.MODE_SELECTED

    def combined_pdf(self):
        return self.combined_pdf_check.isChecked()

    def open_output_folder(self):
        return self.open_folder_check.isChecked()