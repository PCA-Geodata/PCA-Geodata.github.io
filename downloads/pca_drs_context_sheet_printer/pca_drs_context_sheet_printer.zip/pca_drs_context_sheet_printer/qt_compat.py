# -*- coding: utf-8 -*-
"""Small Qt compatibility helpers for QGIS 3 / Qt5 and QGIS 4 / Qt6."""

from __future__ import annotations

from qgis.PyQt.QtWidgets import QDialog


def exec_dialog(dialog: QDialog) -> int:
    """Execute a dialog using the Qt6 method when available, with Qt5 fallback."""
    if hasattr(dialog, "exec"):
        return dialog.exec()
    return dialog.exec_()
