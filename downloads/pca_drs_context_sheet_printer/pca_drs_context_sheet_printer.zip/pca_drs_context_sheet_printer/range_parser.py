# -*- coding: utf-8 -*-
"""Parser for user-defined context ranges such as '1-3, 6, 10-12'."""


def parse_context_range(range_text):
    """
    Convert a range string into an ordered list of integer context numbers.

    Examples:
        '1-3, 6' -> [1, 2, 3, 6]
    """
    if not range_text or not range_text.strip():
        return []

    values = set()
    parts = [part.strip() for part in range_text.split(",") if part.strip()]

    for part in parts:
        if "-" in part:
            start_text, end_text = [p.strip() for p in part.split("-", 1)]
            if not start_text.isdigit() or not end_text.isdigit():
                raise ValueError("Invalid range value: {}".format(part))

            start = int(start_text)
            end = int(end_text)
            if end < start:
                raise ValueError("Invalid reversed range: {}".format(part))

            values.update(range(start, end + 1))
        else:
            if not part.isdigit():
                raise ValueError("Invalid context number: {}".format(part))
            values.add(int(part))

    return sorted(values)
