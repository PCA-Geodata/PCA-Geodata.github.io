# -*- coding: utf-8 -*-
"""Native QGIS print-layout exporter for PCA DRS trench sheets."""

import os
import re
from datetime import datetime
from pathlib import Path

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    NULL,
    QgsApplication,
    QgsExpressionContextUtils,
    QgsLayoutExporter,
    QgsLayoutItemLabel,
    QgsLayoutItemPage,
    QgsLayoutItemPicture,
    QgsLayoutItemShape,
    QgsLayoutMeasurement,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsPrintLayout,
    QgsProject,
    QgsTextFormat,
    QgsUnitTypes,
)

MM = QgsUnitTypes.LayoutMillimeters
PAGE_WIDTH = 210.0
PAGE_HEIGHT = 297.0
MARGIN = 10.0
CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2)

SECTION_FILL = QColor(236, 241, 245)
SECTION_STROKE = QColor(150, 165, 175)
BOX_STROKE = QColor(75, 75, 75)
TEXT_COLOR = QColor(25, 25, 25)
VALUE_COLOR = QColor(35, 35, 35)
MUTED_COLOR = QColor(95, 95, 95)

try:
    ALIGN_LEFT = Qt.AlignmentFlag.AlignLeft
    ALIGN_RIGHT = Qt.AlignmentFlag.AlignRight
    ALIGN_HCENTER = Qt.AlignmentFlag.AlignHCenter
    ALIGN_TOP = Qt.AlignmentFlag.AlignTop
    ALIGN_BOTTOM = Qt.AlignmentFlag.AlignBottom
    ALIGN_VCENTER = Qt.AlignmentFlag.AlignVCenter
except AttributeError:
    ALIGN_LEFT = Qt.AlignLeft
    ALIGN_RIGHT = Qt.AlignRight
    ALIGN_HCENTER = Qt.AlignHCenter
    ALIGN_TOP = Qt.AlignTop
    ALIGN_BOTTOM = Qt.AlignBottom
    ALIGN_VCENTER = Qt.AlignVCenter


_FIELD_NAME_ALIASES = {
    "Trench_Number": ["Trench_Number", "Trench Number", "Trench"],
    "Trench_Length": ["Trench_Length", "Trench Length"],
    "Trench_Width": ["Trench_Width", "Trench Width"],
    "Trench_Orientation": ["Trench_Orientation", "Trench Orientation"],
    "Maximum_trench_depth": ["Maximum_trench_depth", "Maximum trench depth"],
    "Topsoil_description": ["Topsoil_description", "Topsoil description"],
    "Subsoil_description": ["Subsoil_description", "Subsoil description"],
    "Natural_description": ["Natural_description", "Natural description"],
    "Layers": ["Layers"],
    "End_1_Location": ["End_1_Location", "End 1 Location"],
    "Topsoil_thickness_End_1": ["Topsoil_thickness_End_1", "Topsoil thickness at end 1"],
    "Subsoil_Thickness_End_1": ["Subsoil_Thickness_End_1", "Subsoil thickness at end 1"],
    "End_2_Location": ["End_2_Location", "End 2 Location"],
    "Topsoil_thickness_End_2": ["Topsoil_thickness_End_2", "Topsoil thickness at end 2"],
    "Subsoil_Thickness_End_2": ["Subsoil_Thickness_End_2", "Subsoil thickness at end 2"],
    "Archaeology_Presence": ["Archaeology_Presence", "Archaeology Presence"],
    "Finds": ["Finds"],
    "Trench_archaeology_notes": ["Trench_archaeology_notes", "Trench archaeology notes"],
    "Comments": ["Comments"],
    "Section_Rep": ["Section_Rep", "Section Rep"],
    "DSLR_camera_set_number": ["DSLR_camera_set_number", "DSLR Camera Set Num"],
    "DSLR_photo_numbers": ["DSLR_photo_numbers", "DSLR_photo_numbers"],
    # "Trench_photo": ["Trench_photo", "Trench photo"],
    # "Sketch_plan": ["Sketch_plan", "Sketch plan"],
    "Recorded_by": ["Recorded_by", "Recorded by"],
    "Timestamp": ["Timestamp", "Recorded at"],
}


def _normalise_field_name(name):
    """Return a simplified field name for tolerant field-name matching."""
    return str(name).replace(" ", "").replace("_", "").lower()


def _resolve_field_name(feature, field_name):
    """Resolve a requested field name against the actual feature fields."""
    field_names = feature.fields().names()

    if field_name in field_names:
        return field_name

    requested = _normalise_field_name(field_name)
    for existing_name in field_names:
        if _normalise_field_name(existing_name) == requested:
            return existing_name

    return None


def safe_value(feature, field_name, fallback="-"):
    """Safely return a printable value from a feature field or alias list."""
    candidate_names = _FIELD_NAME_ALIASES.get(field_name, [field_name])

    for candidate_name in candidate_names:
        resolved_name = _resolve_field_name(feature, candidate_name)
        if not resolved_name:
            continue

        value = feature[resolved_name]
        if value is None or value == NULL:
            continue

        text = str(value).strip()
        if text and text.upper() != "NULL":
            return text

    return fallback


def project_sitecode():
    """Return the project-level sitecode variable, if available."""
    value = QgsExpressionContextUtils.projectScope(QgsProject.instance()).variable("sitecode")
    return str(value).strip() if value else ""


def filename_safe(value):
    """Return a Windows-safe file-name component."""
    text = str(value).strip() if value is not None else "trench"
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_") or "trench"


def current_username():
    """Return the current QGIS/OS username."""
    user = QgsApplication.userFullName()

    if user and str(user).strip():
        return str(user).strip()

    return os.getenv("USERNAME") or os.getenv("USER") or "Unknown User"


def export_timestamp():
    """Return a formatted export timestamp."""
    return datetime.now().strftime("%d/%m/%Y %H:%M")


def _font(size, bold=False, italic=False):
    font = QFont("Arial", size)
    font.setBold(bool(bold))
    font.setItalic(bool(italic))
    return font


def _add_label(
    layout,
    text,
    x,
    y,
    width,
    height,
    font=None,
    color=None,
    align=None,
    page_offset=0.0,
):
    label = QgsLayoutItemLabel(layout)
    label.setText(str(text))

    if align is None:
        align = ALIGN_LEFT | ALIGN_TOP

    text_font = font or _font(8)
    text_color = color or TEXT_COLOR

    text_format = QgsTextFormat()
    text_format.setFont(text_font)
    text_format.setSize(text_font.pointSizeF() if text_font.pointSizeF() > 0 else text_font.pointSize())
    text_format.setColor(text_color)
    label.setTextFormat(text_format)

    label.setHAlign(
        ALIGN_LEFT
        if align & ALIGN_LEFT
        else ALIGN_HCENTER
        if align & ALIGN_HCENTER
        else ALIGN_RIGHT
    )

    label.setVAlign(
        ALIGN_TOP
        if align & ALIGN_TOP
        else ALIGN_VCENTER
        if align & ALIGN_VCENTER
        else ALIGN_BOTTOM
    )

    layout.addLayoutItem(label)
    label.attemptMove(QgsLayoutPoint(x, y + page_offset, MM))
    label.attemptResize(QgsLayoutSize(width, height, MM))
    return label


def _add_box(layout, x, y, width, height, page_offset=0.0, fill=None, stroke=None, stroke_width=0.25):
    shape = QgsLayoutItemShape(layout)
    shape.setShapeType(QgsLayoutItemShape.Rectangle)
    shape.attemptMove(QgsLayoutPoint(x, y + page_offset, MM))
    shape.attemptResize(QgsLayoutSize(width, height, MM))
    shape.setBackgroundEnabled(True)
    shape.setBackgroundColor(fill or QColor(255, 255, 255))
    shape.setFrameEnabled(True)
    shape.setFrameStrokeColor(stroke or BOX_STROKE)
    shape.setFrameStrokeWidth(QgsLayoutMeasurement(stroke_width, MM))
    layout.addLayoutItem(shape)
    return shape


def _add_section_header(layout, title, x, y, width, page_offset=0.0):
    _add_box(
        layout,
        x,
        y,
        width,
        6.5,
        page_offset,
        fill=SECTION_FILL,
        stroke=SECTION_STROKE,
        stroke_width=0.2,
    )
    _add_label(
        layout,
        title,
        x + 2.2,
        y + 1.3,
        width - 4.4,
        4.2,
        _font(8, bold=True),
        TEXT_COLOR,
        page_offset=page_offset,
    )


def _add_field(layout, feature, field_name, label, x, y, label_width, value_width, page_offset=0.0, suffix=""):
    value = safe_value(feature, field_name)

    if value != "-" and suffix:
        value = "{} {}".format(value, suffix)

    _add_label(layout, label + ":", x, y, label_width, 4.8, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_label(layout, value, x + label_width + 1.2, y, value_width, 4.8, _font(7), VALUE_COLOR, page_offset=page_offset)


def _add_row_fields(layout, feature, fields, x, y, page_offset=0.0):
    """Add a row of labelled fields with even column widths."""
    if not fields:
        return

    col_width = CONTENT_WIDTH / len(fields)

    for index, item in enumerate(fields):
        field_name, label = item[0], item[1]
        suffix = item[2] if len(item) > 2 else ""

        _add_field(
            layout,
            feature,
            field_name,
            label,
            x + (index * col_width),
            y,
            col_width * 0.45,
            col_width * 0.49,
            page_offset,
            suffix,
        )


def _add_text_block(layout, feature, field_name, title, x, y, width, height, page_offset=0.0):
    _add_label(layout, title + ":", x, y, width, 4.6, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)

    value = safe_value(feature, field_name)

    _add_box(
        layout,
        x,
        y + 4.8,
        width,
        height - 4.8,
        page_offset,
        fill=QColor(255, 255, 255),
        stroke=QColor(210, 210, 210),
        stroke_width=0.15,
    )

    _add_label(
        layout,
        value,
        x + 1.8,
        y + 6.2,
        width - 3.6,
        height - 7.2,
        _font(6),
        VALUE_COLOR,
        page_offset=page_offset,
    )


def _page_y_offset(layout, page_index):
    """
    Return the real Y offset of a layout page.

    QGIS layouts include internal page spacing between pages, so this must not
    be calculated manually as PAGE_HEIGHT * page_index.
    """
    page = layout.pageCollection().page(page_index)

    if page is None:
        return PAGE_HEIGHT * page_index

    return page.pos().y()


def _ensure_output_file_is_writable(output_pdf):
    """
    Raise a clear error if the target PDF cannot be written.

    On Windows, an open PDF is often locked by the PDF viewer.
    """
    output_pdf = Path(output_pdf)

    if not output_pdf.exists():
        return

    try:
        with output_pdf.open("ab"):
            pass
    except PermissionError:
        raise PermissionError(
            "The PDF file is already open or locked:\n\n"
            "{}\n\n"
            "Please close the PDF and try again.".format(output_pdf)
        )


def add_trench_sheet_page(layout, feature, page_index, sitecode, logo_path=None):
    """Add one trench sheet page to an existing QgsPrintLayout."""
    if page_index > 0:
        page = QgsLayoutItemPage(layout)
        page.setPageSize("A4", QgsLayoutItemPage.Portrait)
        layout.pageCollection().addPage(page)

    page_offset = _page_y_offset(layout, page_index)

    if logo_path and os.path.exists(logo_path):
        picture = QgsLayoutItemPicture(layout)
        picture.setPicturePath(logo_path)
        layout.addLayoutItem(picture)
        picture.attemptMove(QgsLayoutPoint(MARGIN, 9 + page_offset, MM))
        picture.attemptResize(QgsLayoutSize(16, 16, MM))

    trench_no = safe_value(feature, "Trench_Number")

    _add_label(layout, "DRS PCA Trench Sheet", 30, 10, 118, 9, _font(15, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_label(layout, "Sitecode: {}".format(sitecode or "-"), 30, 20, 70, 5, _font(7), MUTED_COLOR, page_offset=page_offset)

    _add_box(layout, 152, 10, 48, 16, page_offset, fill=QColor(255, 255, 255), stroke=BOX_STROKE, stroke_width=0.35)
    _add_label(layout, "Trench No", 155, 12, 18, 4, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_label(
        layout,
        trench_no,
        174,
        11.6,
        23,
        8,
        _font(13, bold=True),
        TEXT_COLOR,
        align=ALIGN_HCENTER | ALIGN_VCENTER,
        page_offset=page_offset,
    )

    y = 31

    _add_section_header(layout, "Trench information", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(
        layout,
        feature,
        [
            ("Trench_Length", "Length", "m"),
            ("Trench_Width", "Width", "m"),
            ("Maximum_trench_depth", "Max depth", "m"),
            ("Trench_Orientation", "Orientation"),
        ],
        MARGIN,
        y,
        page_offset,
    )
    y += 9

    _add_section_header(layout, "Descriptions", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8

    half_width = (CONTENT_WIDTH - 4) / 2
    _add_text_block(layout, feature, "Topsoil_description", "Topsoil description", MARGIN, y, half_width, 21, page_offset)
    _add_text_block(layout, feature, "Subsoil_description", "Subsoil description", MARGIN + half_width + 4, y, half_width, 21, page_offset)
    y += 23

    _add_text_block(layout, feature, "Natural_description", "Natural description", MARGIN, y, half_width, 21, page_offset)
    _add_text_block(layout, feature, "Layers", "Layers", MARGIN + half_width + 4, y, half_width, 21, page_offset)
    y += 25

    _add_section_header(layout, "Trench ends", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8

    _add_box(layout, MARGIN, y, half_width, 29, page_offset, fill=QColor(255, 255, 255), stroke=QColor(210, 210, 210), stroke_width=0.15)
    _add_label(layout, "End 1", MARGIN + 2, y + 2, half_width - 4, 4.5, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_field(layout, feature, "End_1_Location", "Location", MARGIN + 2, y + 8, 32, half_width - 36, page_offset)
    _add_field(layout, feature, "Topsoil_thickness_End_1", "Topsoil thickness", MARGIN + 2, y + 15, 32, half_width - 36, page_offset, "m")
    _add_field(layout, feature, "Subsoil_Thickness_End_1", "Subsoil thickness", MARGIN + 2, y + 22, 32, half_width - 36, page_offset, "m")

    right_x = MARGIN + half_width + 4
    _add_box(layout, right_x, y, half_width, 29, page_offset, fill=QColor(255, 255, 255), stroke=QColor(210, 210, 210), stroke_width=0.15)
    _add_label(layout, "End 2", right_x + 2, y + 2, half_width - 4, 4.5, _font(7, bold=True), TEXT_COLOR, page_offset=page_offset)
    _add_field(layout, feature, "End_2_Location", "Location", right_x + 2, y + 8, 32, half_width - 36, page_offset)
    _add_field(layout, feature, "Topsoil_thickness_End_2", "Topsoil thickness", right_x + 2, y + 15, 32, half_width - 36, page_offset, "m")
    _add_field(layout, feature, "Subsoil_Thickness_End_2", "Subsoil thickness", right_x + 2, y + 22, 32, half_width - 36, page_offset, "m")

    y += 33

    _add_section_header(layout, "Archaeology and finds", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(
        layout,
        feature,
        [
            ("Archaeology_Presence", "Archaeology presence"),
            ("Finds", "Finds"),
        ],
        MARGIN,
        y,
        page_offset,
    )
    y += 8

    _add_text_block(layout, feature, "Trench_archaeology_notes", "Trench archaeology notes", MARGIN, y, half_width, 26, page_offset)
    _add_text_block(layout, feature, "Comments", "Comments", MARGIN + half_width + 4, y, half_width, 26, page_offset)
    y += 30

    _add_section_header(layout, "Records", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(
        layout,
        feature,
        [
            ("Section_Rep", "Section rep"),
            ("DSLR_camera_set_number", "Camera set"),
            ("DSLR_photo_numbers", "Photo numbers"),
        ],
        MARGIN,
        y,
        page_offset,
    )
    y += 7
    # _add_row_fields(
        # layout,
        # feature,
        # [
            # ("Trench_photo", "Trench photo"),
            # ("Sketch_plan", "Sketch plan"),
        # ],
        # MARGIN,
        # y,
        # page_offset,
    # )
    # y += 8

    _add_section_header(layout, "Recording", MARGIN, y, CONTENT_WIDTH, page_offset)
    y += 8
    _add_row_fields(
        layout,
        feature,
        [
            ("Recorded_by", "Recorded by"),
            ("Timestamp", "Recorded at"),
        ],
        MARGIN,
        y,
        page_offset,
    )

    footer_text = "PCA DRS Trench Sheet Printer • {} • {}".format(
        current_username(),
        export_timestamp(),
    )

    _add_label(
        layout,
        footer_text,
        MARGIN,
        288,
        CONTENT_WIDTH,
        4,
        _font(6, italic=True),
        MUTED_COLOR,
        align=ALIGN_HCENTER | ALIGN_VCENTER,
        page_offset=page_offset,
    )


def _trench_filename_part(features, print_mode):
    """Return a safe, compact trench identifier for exported PDF filenames."""
    trench_values = []

    for feature in features:
        trench_value = safe_value(feature, "Trench_Number", "")
        if trench_value and trench_value != "-":
            trench_values.append(str(trench_value))

    record_count = len(trench_values)

    if print_mode == "all":
        return "All_{}records".format(record_count)

    if record_count == 1:
        return trench_values[0]

    if record_count <= 5:
        return "_".join(trench_values)

    if trench_values:
        return "{}_to_{}_{}records".format(
            trench_values[0],
            trench_values[-1],
            record_count,
        )

    return "trenches"


def export_trench_sheets(
    features,
    output_folder,
    sitecode=None,
    combined=True,
    logo_path=None,
    print_mode="selected",
    progress_callback=None,
):
    """Export trench sheets to PDF using a native QGIS print layout."""
    if not features:
        raise ValueError("No trench records were found for printing.")

    output_dir = Path(output_folder)
    output_dir.mkdir(parents=True, exist_ok=True)

    sitecode = sitecode if sitecode is not None else project_sitecode()
    sitecode_part = filename_safe(sitecode or "Site")

    if combined:
        layout = QgsPrintLayout(QgsProject.instance())
        layout.initializeDefaults()
        layout.setName("PCA DRS Trench Sheets Export")
        layout.pageCollection().page(0).setPageSize("A4", QgsLayoutItemPage.Portrait)

        total = len(features)

        for index, feature in enumerate(features):
            add_trench_sheet_page(layout, feature, index, sitecode, logo_path)

            if progress_callback:
                if progress_callback(index + 1, total, "Preparing trench sheet {} of {}".format(index + 1, total)):
                    raise RuntimeError("Export cancelled by user.")

        trench_part = filename_safe(_trench_filename_part(features, print_mode))
        output_pdf = output_dir / "{}_DRS_Trench_Sheets_{}.pdf".format(sitecode_part, trench_part)

        _ensure_output_file_is_writable(output_pdf)

        exporter = QgsLayoutExporter(layout)
        result = exporter.exportToPdf(str(output_pdf), QgsLayoutExporter.PdfExportSettings())

        if result != QgsLayoutExporter.Success:
            raise RuntimeError("PDF export failed with QGIS exporter code: {}".format(result))

        return [str(output_pdf)]

    exported = []

    for feature in features:
        layout = QgsPrintLayout(QgsProject.instance())
        layout.initializeDefaults()
        layout.setName("PCA DRS Trench Sheet Export")
        layout.pageCollection().page(0).setPageSize("A4", QgsLayoutItemPage.Portrait)

        add_trench_sheet_page(layout, feature, 0, sitecode, logo_path)

        trench_no = filename_safe(safe_value(feature, "Trench_Number"))
        output_pdf = output_dir / "{}_DRS_Trench_Sheet_{}.pdf".format(sitecode_part, trench_no)

        _ensure_output_file_is_writable(output_pdf)

        exporter = QgsLayoutExporter(layout)
        result = exporter.exportToPdf(str(output_pdf), QgsLayoutExporter.PdfExportSettings())

        if result != QgsLayoutExporter.Success:
            raise RuntimeError(
                "PDF export failed for trench {} with QGIS exporter code: {}".format(
                    trench_no,
                    result,
                )
            )

        exported.append(str(output_pdf))
        
        if progress_callback:
            if progress_callback(len(exported), len(features), "Exported trench sheet {} of {}".format(len(exported), len(features))):
                raise RuntimeError("Export cancelled by user.")

    return exported