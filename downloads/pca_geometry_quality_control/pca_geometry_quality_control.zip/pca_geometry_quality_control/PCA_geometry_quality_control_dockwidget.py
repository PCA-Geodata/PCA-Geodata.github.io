# -*- coding: utf-8 -*-
"""
PCA Geometry Quality Control DockWidget
"""

# Standard library
import os

# PyQt / Qt
from qgis.PyQt import uic
from qgis.PyQt.QtCore import pyqtSignal, QCoreApplication, Qt, QUrl
from qgis.PyQt.QtGui import QGuiApplication, QDesktopServices, QIcon, QColor
from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QTreeWidgetItem,
    QFileDialog,
    QMessageBox,
    QMenu,
)

# QGIS core
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsExpressionContextUtils,
)

# QGIS utils
from qgis.utils import iface



# Load the .ui file at runtime
FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), 'PCA_geometry_quality_control_dockwidget_base.ui')
)

# -----------------------------------------------------------------------------
# Qt5 / Qt6 compatibility helpers
# -----------------------------------------------------------------------------

# Data roles
try:
    USER_ROLE = Qt.ItemDataRole.UserRole
except AttributeError:
    # Qt5 fallback
    USER_ROLE = Qt.UserRole

# Context menu policy
try:
    CUSTOM_CONTEXT_MENU = Qt.ContextMenuPolicy.CustomContextMenu
except AttributeError:
    # Qt5 fallback
    CUSTOM_CONTEXT_MENU = Qt.CustomContextMenu

# Red colour for tree foregrounds
try:
    RED_COLOR = QColor("red")
except Exception:
    # Super defensive, but keeps things safe
    RED_COLOR = QColor(Qt.red)
    

def menu_exec(menu, pos):
    """
    Runs QMenu in a Qt5/Qt6 compatible way.
    Qt5: exec_()
    Qt6: exec()
    """
    try:
        return menu.exec(pos)   # Qt6
    except AttributeError:
        return menu.exec_(pos)  # Qt5 fallback

# QMessageBox buttons (Qt5 / Qt6 compatibility)
try:
    MB_YES = QMessageBox.StandardButton.Yes
    MB_NO = QMessageBox.StandardButton.No
except AttributeError:
    MB_YES = QMessageBox.Yes
    MB_NO = QMessageBox.No
    
# -----------------------------------------------------------------------------

DEEP_VALIDATION = False   # you can later expose this as a checkbox
MAX_ERRORS_TO_LIST = 999

# Very small polygon areas (e.g. tiny slivers) will be flagged as "suspected"
# This assumes a projected CRS in metres (e.g. EPSG:27700) so units are m².

SUSPECT_AREA_THRESHOLD = 1e-04      # 0.0001 m²     (1 cm²)

'''
# Extremely small polygons — almost always geometry errors
SUSPECT_AREA_THRESHOLD = 1e-06      # 0.000001 m²   (~1 mm²)

# Very tiny polygons — smaller than a grain of rice
SUSPECT_AREA_THRESHOLD = 1e-05      # 0.00001 m²    (~3×3 mm)

# Tiny polygons — around the size of a fingernail
SUSPECT_AREA_THRESHOLD = 1e-04      # 0.0001 m²     (1 cm²)

# Small polygons — small but still suspicious
SUSPECT_AREA_THRESHOLD = 1e-03      # 0.001 m²      (10 cm²)

# Small polygons — around 10×10 cm
SUSPECT_AREA_THRESHOLD = 1e-02      # 0.01 m²       (100 cm² = 10×10 cm)

# Medium-small polygons — smaller than a trowel footprint
SUSPECT_AREA_THRESHOLD = 5e-02      # 0.05 m²       (~22×22 cm)

# Medium polygons — still unusually small for most archaeological contexts
SUSPECT_AREA_THRESHOLD = 1e-01      # 0.1 m²        (~31×31 cm)

'''

# Thinness threshold: area / perimeter smaller than this ⇒ line-like polygon
SUSPECT_THINNESS_THRESHOLD = 0.02       # ~4 cm effective width

# Polygons with very few vertices are also suspicious (e.g. line → polygon)
SUSPECT_MIN_VERTEX_COUNT = 4            # <= 3 distinct vertices → suspicious



def layer_has_skip_variable(layer):
    """
    Returns True if the layer variable 'skip_geometry_check' is set
    to a truthy value (true/1/yes).
    """
    scope = QgsExpressionContextUtils.layerScope(layer)
    val = scope.variable('skip_geometry_check')
    if val is None:
        return False
    return str(val).strip().lower() in ("1", "true", "yes", "y")


def check_vector_layer_geometries(layer, deep_validation=False, max_errors_to_log=10):
    """
    Check a QgsVectorLayer for basic geometry issues.

    Returns a dict with counts and sample feature IDs.
    """
    results = {
        "layer_name": layer.name(),
        "layer_id": layer.id(),
        "geometry_type": QgsWkbTypes.displayString(layer.wkbType()),
        "total_features": 0,
        "null_geometries": 0,
        "empty_geometries": 0,
        "invalid_geometries": 0,
        "read_errors": 0,
        # for samples in report:
        #   list of (fid, [error_strings])
        "invalid_feature_ids": [],
        "null_feature_ids": [],
        "empty_feature_ids": [],
        "read_error_ids": [],
        # full lists for actions:
        "all_null_ids": [],
        "all_empty_ids": [],
        "all_invalid_ids": [],
        
        # suspicious small-area polygons
        "suspected_geometries": 0,
        "suspected_feature_ids": [],  # list of (fid, area)
        "all_suspected_ids": [],
    }
    
    for feat in layer.getFeatures():
        results["total_features"] += 1
        fid = feat.id()

        try:
            geom = feat.geometry()
        except Exception:
            results["read_errors"] += 1
            if len(results["read_error_ids"]) < max_errors_to_log:
                results["read_error_ids"].append(fid)
            continue

        # Null geometry
        if geom is None or geom.isNull():
            results["null_geometries"] += 1
            results["all_null_ids"].append(fid)
            if len(results["null_feature_ids"]) < max_errors_to_log:
                results["null_feature_ids"].append(fid)
            continue

        # Empty geometry
        if geom.isEmpty():
            results["empty_geometries"] += 1
            results["all_empty_ids"].append(fid)
            if len(results["empty_feature_ids"]) < max_errors_to_log:
                results["empty_feature_ids"].append(fid)
            continue


        # Geometry validity checks
        try:
            if deep_validation:
                # Full validation: list of QgsGeometry.ValidationError
                errors = geom.validateGeometry()
                if errors:
                    results["invalid_geometries"] += 1
                    results["all_invalid_ids"].append(fid)

                    # Store sample errors for the report
                    if len(results["invalid_feature_ids"]) < max_errors_to_log:
                        err_strings = [
                            f"{e.what()} @ {e.where()}" for e in errors
                        ]
                        results["invalid_feature_ids"].append((fid, err_strings))
            else:
                # Fast GEOS check – we don't get detailed errors, just “invalid”
                if not geom.isGeosValid():
                    results["invalid_geometries"] += 1
                    results["all_invalid_ids"].append(fid)

                    if len(results["invalid_feature_ids"]) < max_errors_to_log:
                        results["invalid_feature_ids"].append(
                            (fid, ["Invalid geometry (GEOS check)"])
                        )

        except Exception:
            results["read_errors"] += 1
            if len(results["read_error_ids"]) < max_errors_to_log:
                results["read_error_ids"].append(fid)
                
        # Polygon sanity checks: tiny area, very few vertices, or "line-like"
        geom_type = QgsWkbTypes.geometryType(layer.wkbType())
        if geom_type == QgsWkbTypes.PolygonGeometry:
            area = geom.area()
            perim = geom.length()

            # Count vertices in a geometry-agnostic way (handles multi-polygons)
            try:
                vertex_count = sum(1 for _ in geom.vertices())
            except Exception:
                vertex_count = 0

            is_tiny_area = (area == 0) or (0 < abs(area) <= SUSPECT_AREA_THRESHOLD)
            is_few_vertices = vertex_count > 0 and vertex_count <= SUSPECT_MIN_VERTEX_COUNT

            is_thin = False
            if perim > 0 and area > 0:
                thin_value = area / perim   # roughly half the effective width
                is_thin = thin_value <= SUSPECT_THINNESS_THRESHOLD

            if is_tiny_area or is_few_vertices or is_thin:
                results["suspected_geometries"] += 1
                results["all_suspected_ids"].append(fid)

                if len(results["suspected_feature_ids"]) < max_errors_to_log:
                    # store extra info for the report
                    results["suspected_feature_ids"].append(
                        (fid, area, perim, vertex_count)
                    )

    return results


def build_report_text(layer_results, skipped_layers_info):
    """
    Build a plain-text report string summarizing the results.
    """
    lines = []
    lines.append("=" * 60)
    lines.append("GEOMETRY CHECK REPORT FOR CURRENT PROJECT")
    lines.append("=" * 60)
    lines.append("")

    if skipped_layers_info:
        lines.append("Skipped layers (no geometry or 'skip_geometry_check' variable set):")
        for info in skipped_layers_info:
            lines.append(f"  - {info}")
        lines.append("")

    problematic_layers = [
        r for r in layer_results
        if (r["null_geometries"] > 0 or
            r["empty_geometries"] > 0 or
            r["invalid_geometries"] > 0 or            
            r["suspected_geometries"] > 0 or 
            r["read_errors"] > 0)
    ]



    if not problematic_layers:
        lines.append("No geometry issues detected in checked vector layers.")
        lines.append("")
        lines.append("Tip: layers can be excluded from this check by adding a")
        lines.append("layer variable named 'skip_geometry_check' set to 'true'.")
    else:
        for r in problematic_layers:
            lines.append("-" * 60)
            lines.append(f"Layer: {r['layer_name']}  (ID: {r['layer_id']})")
            lines.append(f"Geometry type : {r['geometry_type']}")
            lines.append(f"Total features: {r['total_features']}")
            lines.append("Issues:")
            lines.append(f"  Null geometries      : {r['null_geometries']}")
            lines.append(f"  Empty geometries     : {r['empty_geometries']}")
            lines.append(f"  Invalid geometries   : {r['invalid_geometries']}")
            lines.append(f"  Suspected geometries : {r['suspected_geometries']}")
            lines.append(f"  Read errors          : {r['read_errors']}")


            if r["null_feature_ids"]:
                lines.append(f"    Sample null FIDs   : {r['null_feature_ids']}")
            if r["empty_feature_ids"]:
                lines.append(f"    Sample empty FIDs  : {r['empty_feature_ids']}")
            #if r["invalid_feature_ids"]:
            #    lines.append(f"    Sample invalid FIDs: {r['invalid_feature_ids']}")
            if r["invalid_feature_ids"]:
                lines.append("    Invalid geometry details:")
                for fid, errors in r["invalid_feature_ids"]:
                    lines.append(f"      - Feature {fid}:")
                    for e in errors:
                        lines.append(f"          • {e}")
            if r["suspected_feature_ids"]:
                lines.append("    Suspected polygons (tiny / line-like / few vertices):")
                for entry in r["suspected_feature_ids"]:
                    # Backwards compatibility if older results have fewer fields
                    if len(entry) == 4:
                        fid, area, perim, vcount = entry
                        thin_val = area / perim if perim > 0 else 0
                        lines.append(
                            f"      - Feature {fid}: "
                            f"area = {area}, perimeter = {perim}, "
                            f"vertices = {vcount}, area/perimeter ≈ {thin_val}"
                        )
                    elif len(entry) == 3:
                        fid, area, perim = entry
                        thin_val = area / perim if perim > 0 else 0
                        lines.append(
                            f"      - Feature {fid}: "
                            f"area = {area}, perimeter = {perim}, "
                            f"area/perimeter ≈ {thin_val}"
                        )
                    else:
                        fid, area = entry
                        lines.append(f"      - Feature {fid}: area = {area}")
            if r["read_error_ids"]:
                lines.append(f"    Sample read-error FIDs: {r['read_error_ids']}")
            lines.append("")

        lines.append("=" * 60)
        lines.append("END OF REPORT")
        lines.append("=" * 60)

    return "\n".join(lines)

def build_summary_text(layer_results):
    """
    Build a compact text summary for copying to clipboard.
    """
    problematic_layers = [
        r for r in layer_results
        if (r["null_geometries"] > 0 or
            r["empty_geometries"] > 0 or
            r["invalid_geometries"] > 0 or
            r["suspected_geometries"] > 0 or 
            r["read_errors"] > 0)
            
    ]


    lines = []
    lines.append("PCA Geometry Quality Control - Summary")
    lines.append("")
    if not problematic_layers:
        lines.append("No geometry issues detected in checked vector layers.")
        return "\n".join(lines)

    header = "Layer | Null | Empty | Invalid | Suspected | Read errors"
    lines.append(header)
    lines.append("-" * len(header))

    for r in problematic_layers:
        lines.append(
            f"{r['layer_name']} | "
            f"{r['null_geometries']} | "
            f"{r['empty_geometries']} | "
            f"{r['invalid_geometries']} | "
            f"{r['suspected_geometries']} | "
            f"{r['read_errors']}"
        )

    return "\n".join(lines)

def run_geometry_check_on_project(deep_validation=False, max_errors_to_log=10, progress_callback=None):
    """
    Run geometry checks on all vector layers in the current project and
    return (layer_results, skipped_layers_info, full_report_text).

    If progress_callback is provided, it will be called as:
        progress_callback(processed_count, total_layers, layer_name)
    """
    project = QgsProject.instance()
    all_layers = list(project.mapLayers().values())

    # Consider only vector layers for progress, even if later skipped
    vector_layers = [
        lyr for lyr in all_layers if isinstance(lyr, QgsVectorLayer)
    ]
    total_layers = len(vector_layers)
    processed = 0

    layer_results = []
    skipped_layers_info = []

    for layer in vector_layers:
        # Only vector layers (already filtered, but keep for safety)
        if not isinstance(layer, QgsVectorLayer):
            continue

        # ---------------------------------------------------------------------
        # IMPORTANT: handle "kept unavailable" / broken-source layers FIRST.
        #
        # When a layer's source is moved/missing, QGIS can still return a
        # QgsVectorLayer object, but calls like wkbType() / layerScope() /
        # getFeatures() may raise or behave unpredictably.
        #
        # So we validate first (and also check provider validity) before doing
        # any other layer operations.
        # ---------------------------------------------------------------------
        try:
            is_valid = layer.isValid()
        except Exception:
            is_valid = False

        try:
            provider = layer.dataProvider()
            provider_ok = (provider is not None and provider.isValid())
        except Exception:
            provider_ok = False

        if not is_valid or not provider_ok:
            # Keep going: record the issue and continue with the next layer
            r = {
                "layer_name": layer.name() if layer else "<unknown>",
                "layer_id": layer.id() if layer else "<unknown>",
                "geometry_type": "Unknown (layer unavailable / broken source)",
                "total_features": 0,
                "null_geometries": 0,
                "empty_geometries": 0,
                "invalid_geometries": 0,
                "read_errors": 1,

                # for samples in report:
                "invalid_feature_ids": [],
                "null_feature_ids": [],
                "empty_feature_ids": [],
                "read_error_ids": ["<layer unavailable / broken source>"],

                # full lists for actions:
                "all_null_ids": [],
                "all_empty_ids": [],
                "all_invalid_ids": [],

                # suspicious small-area polygons
                "suspected_geometries": 0,
                "suspected_feature_ids": [],
                "all_suspected_ids": [],
            }
            layer_results.append(r)

            processed += 1
            if progress_callback is not None:
                progress_callback(processed, total_layers, r["layer_name"])
            continue

        # ---------------------------------------------------------------------
        # From here, we can safely call layer methods.
        # ---------------------------------------------------------------------

        # Skip geometryless tables
        try:
            if layer.wkbType() == QgsWkbTypes.NoGeometry:
                skipped_layers_info.append(f"{layer.name()} (no geometry)")
                processed += 1
                if progress_callback is not None:
                    progress_callback(processed, total_layers, layer.name())
                continue
        except Exception as ex:
            # If even wkbType() fails, treat it like an unavailable layer but don't crash
            r = {
                "layer_name": layer.name(),
                "layer_id": layer.id(),
                "geometry_type": "Unknown (wkbType failed)",
                "total_features": 0,
                "null_geometries": 0,
                "empty_geometries": 0,
                "invalid_geometries": 0,
                "read_errors": 1,
                "invalid_feature_ids": [],
                "null_feature_ids": [],
                "empty_feature_ids": [],
                "read_error_ids": [f"<wkbType error: {ex}>"],
                "all_null_ids": [],
                "all_empty_ids": [],
                "all_invalid_ids": [],
                "suspected_geometries": 0,
                "suspected_feature_ids": [],
                "all_suspected_ids": [],
            }
            layer_results.append(r)

            processed += 1
            if progress_callback is not None:
                progress_callback(processed, total_layers, layer.name())
            continue

        # Skip layers explicitly marked via layer variable
        try:
            if layer_has_skip_variable(layer):
                skipped_layers_info.append(f"{layer.name()} (skip_geometry_check = true)")
                processed += 1
                if progress_callback is not None:
                    progress_callback(processed, total_layers, layer.name())
                continue
        except Exception as ex:
            # If variable lookup fails, don't kill the run
            skipped_layers_info.append(f"{layer.name()} (skip var lookup failed: {ex})")
            processed += 1
            if progress_callback is not None:
                progress_callback(processed, total_layers, layer.name())
            continue

        # Normal check
        res = check_vector_layer_geometries(
            layer,
            deep_validation=deep_validation,
            max_errors_to_log=max_errors_to_log
        )
        layer_results.append(res)

        processed += 1
        if progress_callback is not None:
            progress_callback(processed, total_layers, layer.name())

    report_text = build_report_text(layer_results, skipped_layers_info)
    return layer_results, skipped_layers_info, report_text

# -----------------------------------------------------------------------------
# Dock widget class
# -----------------------------------------------------------------------------


class PCA_Geometry_Quality_ControlDockWidget(QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""
        super().__init__(parent)
        self.setupUi(self)
        
        # Give the dock a stable object name so QGIS remembers its position
        self.setObjectName("PCA_Geometry_Quality_ControlDockWidget")
               
        # # Context menu for the summary tree (Qt5 + Qt6 compatible)
        # if hasattr(Qt, "CustomContextMenu"):
            # # Qt5-style
            # self.treeSummary.setContextMenuPolicy(Qt.CustomContextMenu)
        # else:
            # # Qt6-style
            # self.treeSummary.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

        # Context menu for the summary tree (Qt5 + Qt6 compatible)
        self.treeSummary.setContextMenuPolicy(CUSTOM_CONTEXT_MENU)
        
        self.treeSummary.customContextMenuRequested.connect(
            self.on_summary_context_menu
        )

        # Internal state
        self._last_layer_results = []
        self._last_skipped_layers = []
        self._last_full_report_text = ""

        # Wire up UI
        self.btnRunCheck.clicked.connect(self.on_run_check)
        self.btnCopySummary.clicked.connect(self.on_copy_summary)
        self.btnExportReport.clicked.connect(self.on_export_report)
        
        self.helpButton.clicked.connect(self.open_help)


        # Optional: ensure summary tree has sensible columns (in case .ui differs)
        if self.treeSummary.columnCount() < 6:
            self.treeSummary.setColumnCount(6)
            self.treeSummary.setHeaderLabels(
                ["Layer", "Null", "Empty", "Invalid", "Suspected", "Read errors"]
            )

        self.lblStatus.setText("Status: idle")
        
        # 🔗 Reset results when project changes
        proj = QgsProject.instance()
        proj.cleared.connect(self._on_project_changed)
        proj.readProject.connect(self._on_project_changed)

    # ------------------------------------------------------------------ UI hooks

    def closeEvent(self, event):
        """Emit signal when dock widget is closed."""
        self.closingPlugin.emit()
        event.accept()

    def on_run_check(self):
        """Run geometry check and update UI."""
        self.lblStatus.setText("Status: running geometry checks...")
        self.btnRunCheck.setEnabled(False)
        self.btnCopySummary.setEnabled(False)
        self.btnExportReport.setEnabled(False)

        try:
            layer_results, skipped, report_text = run_geometry_check_on_project(
                deep_validation=DEEP_VALIDATION,
                max_errors_to_log=MAX_ERRORS_TO_LIST,
                progress_callback=self._progress_callback
            )

            self._last_layer_results = layer_results
            self._last_skipped_layers = skipped
            self._last_full_report_text = report_text

            self.populate_summary_tree(layer_results)
            self.textFullReport.setPlainText(report_text)

            if not any(
                r["null_geometries"] > 0 or
                r["empty_geometries"] > 0 or
                r["invalid_geometries"] > 0 or
                r["read_errors"] > 0
                for r in layer_results
            ):
                self.lblStatus.setText("Status: completed - no geometry issues found.")
            else:
                self.lblStatus.setText("Status: completed - issues detected.")

        except Exception as ex:
            self.lblStatus.setText("Status: error during geometry check.")
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                f"An error occurred while running the geometry check:\n{ex}"
            )

        finally:
            self.btnRunCheck.setEnabled(True)
            self.btnCopySummary.setEnabled(True)
            self.btnExportReport.setEnabled(True)
            
            # Finalize progress bar
            self.progressBar.setValue(self.progressBar.maximum())
            self.progressBar.setVisible(False)

    def on_copy_summary(self):
        """Copy a compact summary to the clipboard."""
        if not self._last_layer_results:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No results available yet. Please run the geometry check first."
            )
            return

        text = build_summary_text(self._last_layer_results)
        QGuiApplication.clipboard().setText(text)
        self.lblStatus.setText("Status: summary copied to clipboard.")

    def on_export_report(self):
        """Export the full report to a text file."""
        if not self._last_full_report_text:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No report available yet. Please run the geometry check first."
            )
            return

        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export Geometry Check Report",
            "",
            "Text files (*.txt);;All files (*)"
        )
        if not filename:
            return

        try:
            with open(filename, "w", encoding="utf-8") as f:
                f.write(self._last_full_report_text)
            self.lblStatus.setText(f"Status: report exported to {filename}")
        except Exception as ex:
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                f"Could not export report:\n{ex}"
            )

    # ------------------------------------------------------------------ helpers
       
    def populate_summary_tree(self, layer_results):
        """Populate the Simple Summary tree with layers that have issues."""
        self.treeSummary.clear()

        problematic_layers = [
            r for r in layer_results
            if (r["null_geometries"] > 0 or
                r["empty_geometries"] > 0 or
                r["invalid_geometries"] > 0 or
                r["suspected_geometries"] > 0 or
                r["read_errors"] > 0)
        ]

        if not problematic_layers:
            return

        for r in problematic_layers:
            item = QTreeWidgetItem(self.treeSummary)

            # Text values
            item.setText(0, r["layer_name"])
            item.setText(1, str(r["null_geometries"]))
            item.setText(2, str(r["empty_geometries"]))
            item.setText(3, str(r["invalid_geometries"]))
            item.setText(4, str(r["suspected_geometries"]))
            item.setText(5, str(r["read_errors"]))

            # Store layer ID for context menu (Qt5/Qt6 compatible)
            item.setData(0, USER_ROLE, r["layer_id"])

            # Colour code non-zero counts in red
            columns = {
                1: r["null_geometries"],
                2: r["empty_geometries"],
                3: r["invalid_geometries"],
                4: r["suspected_geometries"],
                5: r["read_errors"],
            }
            for col, val in columns.items():
                if val > 0:
                    item.setForeground(col, RED_COLOR)

        self.treeSummary.resizeColumnToContents(0)

           
    def _progress_callback(self, processed, total, layer_name):
        """
        Update progress bar and status label during checks.
        """
        if total <= 0:
            return

        # Ensure progress bar is configured
        self.progressBar.setVisible(True)
        self.progressBar.setMaximum(total)
        self.progressBar.setValue(processed)

        self.lblStatus.setText(
            f"Status: checking layer {processed}/{total} - {layer_name}"
        )

        # Keep UI responsive
        QCoreApplication.processEvents()

    def _get_layer_and_result(self, layer_id):
        """
        Given a layer ID, return (layer, result_dict) or (None, None) on error.
        """
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            QMessageBox.warning(
                self,
                "Geometry Quality Control",
                "Layer not found. It may have been removed from the project."
            )
            return None, None

        result = next(
            (r for r in self._last_layer_results if r["layer_id"] == layer_id),
            None
        )
        if result is None:
            QMessageBox.warning(
                self,
                "Geometry Quality Control",
                "No stored results for this layer. Please run the check again."
            )
            return None, None

        return layer, result

    def on_summary_context_menu(self, pos):
        """
        Show a context menu when right-clicking on a layer row in the summary.
        """
        item = self.treeSummary.itemAt(pos)
        if item is None:
            return

        layer_id = item.data(0, USER_ROLE)
        if layer_id is None:
            return

        menu = QMenu(self)

        ##action_select = menu.addAction("Select all Empty/Invalid geometries")
        ##action_delete_null = menu.addAction("Delete NULL or empty geometries")
        
        
        action_select = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/select.png"),
            "Select all Empty/Invalid geometries"
        )
        
        action_suspect_select = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/select.png"),
            "Select all Suspected geometries"
        )
                
        action_delete_null = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/bin_red.png"),
            "Delete NULL or empty geometries"
        )
        
        chosen = menu_exec(menu, self.treeSummary.viewport().mapToGlobal(pos))
        
        if chosen is None:
            return

        if chosen == action_select:
            self.select_problem_geometries(layer_id)
        elif chosen == action_suspect_select:
            self.select_suspect_geometries(layer_id)
        elif chosen == action_delete_null:
            self.delete_null_geometries(layer_id)

    def select_problem_geometries(self, layer_id):
        """
        Select all null, empty and invalid geometries in the given layer.
        """
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = (
            set(result.get("all_invalid_ids", []))
        )


        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No problematic geometries to select for this layer."
            )
            return

        layer.removeSelection()
        layer.selectByIds(list(ids))
        
        # Make it the active layer
        iface.setActiveLayer(layer)

        # Zoom to selection
        canvas = iface.mapCanvas()
        canvas.zoomToSelected(layer)

        # Flash the selected feature IDs
        canvas.flashFeatureIds(layer, list(ids))

        self.lblStatus.setText(
            f"Status: selected {len(ids)} problematic features in '{layer.name()}'."
        )

    def select_suspect_geometries(self, layer_id):
        """
        Select all null, empty and invalid geometries in the given layer.
        """
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = (
            set(result.get("all_suspected_ids", []))
        )

        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No suspect geometries to select for this layer."
            )
            return

        layer.removeSelection()
        layer.selectByIds(list(ids))
        
        # Make it the active layer
        iface.setActiveLayer(layer)

        # Zoom to selection
        canvas = iface.mapCanvas()
        canvas.zoomToSelected(layer)

        # Flash the selected feature IDs
        canvas.flashFeatureIds(layer, list(ids))

        self.lblStatus.setText(
            f"Status: selected {len(ids)} suspect features in '{layer.name()}'."
        )

    def delete_null_geometries(self, layer_id):
        """
        Delete all features with null geometry in the given layer.
        Never commit edits automatically: leave commit/rollback to the user.
        """
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = result.get("all_null_ids", [])
        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "This layer has no null geometries to delete."
            )
            return

        reply = QMessageBox.question(
            self,
            "Delete Null geometries",
            (
                f"Layer '{layer.name()}' has {len(ids)} features with null geometry.\n\n"
                "Do you want to delete these features?\n\n"
                "The layer will remain in edit mode so you may commit or "
                "roll back the changes manually."
            ),
            MB_YES | MB_NO,
            MB_NO
        )
        if reply != MB_YES:
            return

        # Ensure layer is editable but DO NOT commit later
        if not layer.isEditable():
            if not layer.startEditing():
                QMessageBox.critical(
                    self,
                    "Geometry Quality Control",
                    "Could not start editing on this layer."
                )
                return

        # Delete using grouped undo command
        layer.beginEditCommand("Delete null geometries")

        try:
            for fid in ids:
                layer.deleteFeature(fid)
            layer.endEditCommand()
        except Exception:
            layer.destroyEditCommand()
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                "Error deleting null geometries. No changes were applied."
            )
            return

        layer.triggerRepaint()

        self.lblStatus.setText(
            f"Status: deleted {len(ids)} null-geometry features in '{layer.name()}'. "
            "Layer is in EDIT MODE — commit or rollback manually."
        )

        # 🔄 Refresh QC results after deletion
        self.on_run_check()

    def _on_project_changed(self):
        """
        Called when the QGIS project is cleared or a new project is loaded.
        Clears cached results and UI to avoid confusion between projects.
        """
        # Clear internal caches
        self._last_layer_results = []
        self._last_skipped_layers = []
        self._last_full_report_text = ""

        # Clear UI
        self.treeSummary.clear()
        self.textFullReport.clear()

        # Disable actions that depend on previous results
        self.btnCopySummary.setEnabled(False)
        self.btnExportReport.setEnabled(False)

        self.lblStatus.setText(
            "Status: project changed – please run a new geometry check."
        )

    def open_help(self):
        """
        Opens the plugin's help/index.html file in the user's default web browser.
        """
        # Path to the plugin folder (one level up from this file)
        plugin_dir = os.path.dirname(__file__)

        # Path to help file (adjust name if different)
        help_path = os.path.join(plugin_dir, "help", "index.html")

        if not os.path.exists(help_path):
            QMessageBox.warning(
                self,
                "Help file not found",
                f"Could not find the help documentation at:\n{help_path}"
            )
            return

        url = QUrl.fromLocalFile(help_path)
        QDesktopServices.openUrl(url)
