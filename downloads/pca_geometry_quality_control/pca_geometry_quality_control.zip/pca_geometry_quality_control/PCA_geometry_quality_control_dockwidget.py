# -*- coding: utf-8 -*-
"""
PCA Geometry Quality Control DockWidget
"""

# Standard library
import os

# PyQt / Qt
from qgis.PyQt import uic
from qgis.PyQt.QtCore import pyqtSignal, QCoreApplication, Qt, QUrl
from qgis.PyQt.QtGui import QGuiApplication, QDesktopServices, QIcon, QColor
from qgis.PyQt.QtWidgets import (
    QApplication,
    QDockWidget,
    QTreeWidgetItem,
    QFileDialog,
    QMessageBox,
    QMenu,
    QHeaderView,
)

# QGIS core
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsExpressionContextUtils,
    QgsFeatureRequest,
    QgsVectorDataProvider,
)

# Load the .ui file at runtime
FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "PCA_geometry_quality_control_dockwidget_base.ui")
)

# -----------------------------------------------------------------------------
# Qt5 / Qt6 compatibility helpers
# -----------------------------------------------------------------------------

try:
    USER_ROLE = Qt.ItemDataRole.UserRole
except AttributeError:
    USER_ROLE = Qt.UserRole

try:
    CUSTOM_CONTEXT_MENU = Qt.ContextMenuPolicy.CustomContextMenu
except AttributeError:
    CUSTOM_CONTEXT_MENU = Qt.CustomContextMenu

try:
    UNIQUE_CONNECTION = Qt.ConnectionType.UniqueConnection
except AttributeError:
    UNIQUE_CONNECTION = Qt.UniqueConnection

try:
    SECTION_RESIZE_STRETCH = QHeaderView.ResizeMode.Stretch
    SECTION_RESIZE_RESIZE_TO_CONTENTS = QHeaderView.ResizeMode.ResizeToContents
except AttributeError:
    SECTION_RESIZE_STRETCH = QHeaderView.Stretch
    SECTION_RESIZE_RESIZE_TO_CONTENTS = QHeaderView.ResizeToContents

try:
    MB_YES = QMessageBox.StandardButton.Yes
    MB_NO = QMessageBox.StandardButton.No
except AttributeError:
    MB_YES = QMessageBox.Yes
    MB_NO = QMessageBox.No

# Softer than pure red, easier to read in light and dark themes.
RED_COLOR = QColor("#c85c5c")


def menu_exec(menu, pos):
    """Run QMenu in a Qt5/Qt6 compatible way."""
    try:
        return menu.exec(pos)   # Qt6
    except AttributeError:
        return menu.exec_(pos)  # Qt5 fallback


def connect_unique(signal, slot):
    """
    Connect a Qt signal using UniqueConnection where available.

    Some PyQt/PySide builds are strict about overloads, so this helper falls
    back to a normal connection if the compatibility enum is rejected.
    """
    try:
        signal.connect(slot, UNIQUE_CONNECTION)
    except TypeError:
        try:
            signal.disconnect(slot)
        except (TypeError, RuntimeError):
            pass
        signal.connect(slot)


# -----------------------------------------------------------------------------
# Geometry check settings
# -----------------------------------------------------------------------------

DEEP_VALIDATION = False   # You can later expose this as a checkbox.
MAX_ERRORS_TO_LIST = 999

# Very small polygon areas will be flagged as suspected. This assumes a projected
# CRS in metres, such as EPSG:27700, so units are m².
SUSPECT_AREA_THRESHOLD = 1e-04      # 0.0001 m², approximately 1 cm².

'''
# Extremely small polygons — almost always geometry errors
SUSPECT_AREA_THRESHOLD = 1e-06      # 0.000001 m²   (~1 mm²)

# Very tiny polygons — smaller than a grain of rice
SUSPECT_AREA_THRESHOLD = 1e-05      # 0.00001 m²    (~3×3 mm)

# Tiny polygons — around the size of a fingernail
SUSPECT_AREA_THRESHOLD = 1e-04      # 0.0001 m²     (1 cm²)

# Small polygons — small but still suspicious
SUSPECT_AREA_THRESHOLD = 1e-03      # 0.001 m²      (10 cm²)

# Small polygons — around 10×10 cm
SUSPECT_AREA_THRESHOLD = 1e-02      # 0.01 m²       (100 cm² = 10×10 cm)

# Medium-small polygons — smaller than a trowel footprint
SUSPECT_AREA_THRESHOLD = 5e-02      # 0.05 m²       (~22×22 cm)

# Medium polygons — still unusually small for most archaeological contexts
SUSPECT_AREA_THRESHOLD = 1e-01      # 0.1 m²        (~31×31 cm)

'''


# Thinness threshold: area / perimeter smaller than this means line-like polygon.
SUSPECT_THINNESS_THRESHOLD = 0.02   # approximately 4 cm effective width.

# Polygons with very few vertices are also suspicious, e.g. line converted to polygon.
SUSPECT_MIN_VERTEX_COUNT = 4        # <= 4 vertices can indicate a suspicious polygon.


def tr(message):
    """Translate helper for module-level functions."""
    return QCoreApplication.translate("PCA_Geometry_Quality_ControlDockWidget", message)


def layer_has_skip_variable(layer):
    """
    Return True if the layer variable 'skip_geometry_check' is truthy.
    """
    scope = QgsExpressionContextUtils.layerScope(layer)
    val = scope.variable("skip_geometry_check")
    if val is None:
        return False
    return str(val).strip().lower() in ("1", "true", "yes", "y")


def _new_empty_result(layer_name, layer_id, geometry_type):
    """Create a consistent result dictionary for one layer."""
    return {
        "layer_name": layer_name,
        "layer_id": layer_id,
        "geometry_type": geometry_type,
        "total_features": 0,
        "null_geometries": 0,
        "empty_geometries": 0,
        "invalid_geometries": 0,
        "read_errors": 0,
        "invalid_feature_ids": [],
        "null_feature_ids": [],
        "empty_feature_ids": [],
        "read_error_ids": [],
        "all_null_ids": [],
        "all_empty_ids": [],
        "all_invalid_ids": [],
        "suspected_geometries": 0,
        "suspected_feature_ids": [],
        "all_suspected_ids": [],
    }


def _is_problematic_result(result):
    """Return True if a layer result contains any issue type."""
    return (
        result["null_geometries"] > 0 or
        result["empty_geometries"] > 0 or
        result["invalid_geometries"] > 0 or
        result["suspected_geometries"] > 0 or
        result["read_errors"] > 0
    )


def _format_float(value):
    """Format geometry metrics compactly for the text report."""
    try:
        return f"{float(value):.8g}"
    except (TypeError, ValueError):
        return str(value)


def check_vector_layer_geometries(layer, deep_validation=False, max_errors_to_log=10):
    """
    Check a QgsVectorLayer for basic geometry issues.

    Returns a dict with counts, sample feature IDs and full ID lists for actions.
    Attribute values are not requested, which improves performance on large
    layers and remote providers.
    """
    layer_wkb_type = layer.wkbType()
    layer_geom_type = QgsWkbTypes.geometryType(layer_wkb_type)

    results = _new_empty_result(
        layer.name(),
        layer.id(),
        QgsWkbTypes.displayString(layer_wkb_type),
    )

    request = QgsFeatureRequest()
    request.setNoAttributes()

    for feat in layer.getFeatures(request):
        results["total_features"] += 1
        fid = feat.id()

        try:
            geom = feat.geometry()
        except Exception:
            results["read_errors"] += 1
            if len(results["read_error_ids"]) < max_errors_to_log:
                results["read_error_ids"].append(fid)
            continue

        if geom is None or geom.isNull():
            results["null_geometries"] += 1
            results["all_null_ids"].append(fid)
            if len(results["null_feature_ids"]) < max_errors_to_log:
                results["null_feature_ids"].append(fid)
            continue

        if geom.isEmpty():
            results["empty_geometries"] += 1
            results["all_empty_ids"].append(fid)
            if len(results["empty_feature_ids"]) < max_errors_to_log:
                results["empty_feature_ids"].append(fid)
            continue

        try:
            if deep_validation:
                errors = geom.validateGeometry()
                if errors:
                    results["invalid_geometries"] += 1
                    results["all_invalid_ids"].append(fid)

                    if len(results["invalid_feature_ids"]) < max_errors_to_log:
                        err_strings = [f"{e.what()} @ {e.where()}" for e in errors]
                        results["invalid_feature_ids"].append((fid, err_strings))
            else:
                if not geom.isGeosValid():
                    results["invalid_geometries"] += 1
                    results["all_invalid_ids"].append(fid)

                    if len(results["invalid_feature_ids"]) < max_errors_to_log:
                        results["invalid_feature_ids"].append(
                            (fid, ["Invalid geometry (GEOS check)"])
                        )
        except Exception as ex:
            results["read_errors"] += 1
            if len(results["read_error_ids"]) < max_errors_to_log:
                results["read_error_ids"].append(f"{fid}: {ex}")
            continue

        # Polygon sanity checks: tiny area, very few vertices, or line-like shape.
        if layer_geom_type == QgsWkbTypes.PolygonGeometry:
            try:
                area = geom.area()
                perim = geom.length()
            except Exception as ex:
                results["read_errors"] += 1
                if len(results["read_error_ids"]) < max_errors_to_log:
                    results["read_error_ids"].append(f"{fid}: polygon metric error: {ex}")
                continue

            try:
                vertex_count = sum(1 for _ in geom.vertices())
            except Exception:
                vertex_count = 0

            is_tiny_area = (area == 0) or (0 < abs(area) <= SUSPECT_AREA_THRESHOLD)
            is_few_vertices = vertex_count > 0 and vertex_count <= SUSPECT_MIN_VERTEX_COUNT

            is_thin = False
            if perim > 0 and area > 0:
                thin_value = area / perim
                is_thin = thin_value <= SUSPECT_THINNESS_THRESHOLD

            if is_tiny_area or is_few_vertices or is_thin:
                results["suspected_geometries"] += 1
                results["all_suspected_ids"].append(fid)

                if len(results["suspected_feature_ids"]) < max_errors_to_log:
                    results["suspected_feature_ids"].append(
                        (fid, area, perim, vertex_count)
                    )

    return results


def build_report_text(layer_results, skipped_layers_info):
    """Build a plain-text report string summarising the results."""
    lines = []
    lines.append("=" * 60)
    lines.append("GEOMETRY CHECK REPORT FOR CURRENT PROJECT")
    lines.append("=" * 60)
    lines.append("")

    if skipped_layers_info:
        lines.append("Skipped layers (no geometry or 'skip_geometry_check' variable set):")
        for info in skipped_layers_info:
            lines.append(f"  - {info}")
        lines.append("")

    problematic_layers = [r for r in layer_results if _is_problematic_result(r)]

    if not problematic_layers:
        lines.append("No geometry issues detected in checked vector layers.")
        lines.append("")
        lines.append("Tip: layers can be excluded from this check by adding a")
        lines.append("layer variable named 'skip_geometry_check' set to 'true'.")
        return "\n".join(lines)

    for r in problematic_layers:
        lines.append("-" * 60)
        lines.append(f"Layer: {r['layer_name']}  (ID: {r['layer_id']})")
        lines.append(f"Geometry type : {r['geometry_type']}")
        lines.append(f"Total features: {r['total_features']}")
        lines.append("Issues:")
        lines.append(f"  Null geometries      : {r['null_geometries']}")
        lines.append(f"  Empty geometries     : {r['empty_geometries']}")
        lines.append(f"  Invalid geometries   : {r['invalid_geometries']}")
        lines.append(f"  Suspected geometries : {r['suspected_geometries']}")
        lines.append(f"  Read errors          : {r['read_errors']}")

        if r["null_feature_ids"]:
            lines.append(f"    Sample null FIDs   : {r['null_feature_ids']}")
        if r["empty_feature_ids"]:
            lines.append(f"    Sample empty FIDs  : {r['empty_feature_ids']}")
        if r["invalid_feature_ids"]:
            lines.append("    Invalid geometry details:")
            for fid, errors in r["invalid_feature_ids"]:
                lines.append(f"      - Feature {fid}:")
                for error_text in errors:
                    lines.append(f"          • {error_text}")
        if r["suspected_feature_ids"]:
            lines.append("    Suspected polygons (tiny / line-like / few vertices):")
            for entry in r["suspected_feature_ids"]:
                if len(entry) == 4:
                    fid, area, perim, vertex_count = entry
                    thin_val = area / perim if perim > 0 else 0
                    lines.append(
                        f"      - Feature {fid}: "
                        f"area = {_format_float(area)}, "
                        f"perimeter = {_format_float(perim)}, "
                        f"vertices = {vertex_count}, "
                        f"area/perimeter ≈ {_format_float(thin_val)}"
                    )
                elif len(entry) == 3:
                    fid, area, perim = entry
                    thin_val = area / perim if perim > 0 else 0
                    lines.append(
                        f"      - Feature {fid}: "
                        f"area = {_format_float(area)}, "
                        f"perimeter = {_format_float(perim)}, "
                        f"area/perimeter ≈ {_format_float(thin_val)}"
                    )
                else:
                    fid, area = entry
                    lines.append(f"      - Feature {fid}: area = {_format_float(area)}")
        if r["read_error_ids"]:
            lines.append(f"    Sample read-error FIDs: {r['read_error_ids']}")
        lines.append("")

    lines.append("=" * 60)
    lines.append("END OF REPORT")
    lines.append("=" * 60)
    return "\n".join(lines)


def build_summary_text(layer_results):
    """Build a compact text summary for copying to clipboard."""
    problematic_layers = [r for r in layer_results if _is_problematic_result(r)]

    lines = []
    lines.append("PCA Geometry Quality Control - Summary")
    lines.append("")
    if not problematic_layers:
        lines.append("No geometry issues detected in checked vector layers.")
        return "\n".join(lines)

    header = "Layer | Null | Empty | Invalid | Suspected | Read errors"
    lines.append(header)
    lines.append("-" * len(header))

    for r in problematic_layers:
        lines.append(
            f"{r['layer_name']} | "
            f"{r['null_geometries']} | "
            f"{r['empty_geometries']} | "
            f"{r['invalid_geometries']} | "
            f"{r['suspected_geometries']} | "
            f"{r['read_errors']}"
        )

    return "\n".join(lines)


def run_geometry_check_on_project(deep_validation=False, max_errors_to_log=10, progress_callback=None):
    """
    Run geometry checks on all vector layers in the current project.

    Returns (layer_results, skipped_layers_info, full_report_text).
    If progress_callback is provided, it is called as:
        progress_callback(processed_count, total_layers, layer_name)
    """
    project = QgsProject.instance()
    vector_layers = [
        layer for layer in project.mapLayers().values()
        if isinstance(layer, QgsVectorLayer)
    ]

    total_layers = len(vector_layers)
    processed = 0
    layer_results = []
    skipped_layers_info = []

    for layer in vector_layers:
        try:
            layer_name = layer.name()
            layer_id = layer.id()
        except Exception:
            layer_name = "<unknown>"
            layer_id = "<unknown>"

        try:
            is_valid = layer.isValid()
        except Exception:
            is_valid = False

        try:
            provider = layer.dataProvider()
            provider_ok = provider is not None and provider.isValid()
        except Exception:
            provider_ok = False

        if not is_valid or not provider_ok:
            result = _new_empty_result(
                layer_name,
                layer_id,
                "Unknown (layer unavailable / broken source)",
            )
            result["read_errors"] = 1
            result["read_error_ids"].append("<layer unavailable / broken source>")
            layer_results.append(result)

            processed += 1
            if progress_callback is not None:
                progress_callback(processed, total_layers, layer_name)
            continue

        try:
            if layer.wkbType() == QgsWkbTypes.NoGeometry:
                skipped_layers_info.append(f"{layer_name} (no geometry)")
                processed += 1
                if progress_callback is not None:
                    progress_callback(processed, total_layers, layer_name)
                continue
        except Exception as ex:
            result = _new_empty_result(layer_name, layer_id, "Unknown (wkbType failed)")
            result["read_errors"] = 1
            result["read_error_ids"].append(f"<wkbType error: {ex}>")
            layer_results.append(result)

            processed += 1
            if progress_callback is not None:
                progress_callback(processed, total_layers, layer_name)
            continue

        try:
            if layer_has_skip_variable(layer):
                skipped_layers_info.append(f"{layer_name} (skip_geometry_check = true)")
                processed += 1
                if progress_callback is not None:
                    progress_callback(processed, total_layers, layer_name)
                continue
        except Exception as ex:
            # Safer to report this layer as skipped than crash the whole run.
            skipped_layers_info.append(f"{layer_name} (skip var lookup failed: {ex})")
            processed += 1
            if progress_callback is not None:
                progress_callback(processed, total_layers, layer_name)
            continue

        result = check_vector_layer_geometries(
            layer,
            deep_validation=deep_validation,
            max_errors_to_log=max_errors_to_log,
        )
        layer_results.append(result)

        processed += 1
        if progress_callback is not None:
            progress_callback(processed, total_layers, layer_name)

    report_text = build_report_text(layer_results, skipped_layers_info)
    return layer_results, skipped_layers_info, report_text


# -----------------------------------------------------------------------------
# Dock widget class
# -----------------------------------------------------------------------------

class PCA_Geometry_Quality_ControlDockWidget(QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor."""
        super().__init__(parent)
        self.iface = iface
        self.setupUi(self)

        # Give the dock a stable object name so QGIS remembers its position.
        self.setObjectName("PCA_Geometry_Quality_ControlDockWidget")

        self.treeSummary.setContextMenuPolicy(CUSTOM_CONTEXT_MENU)
        self.treeSummary.customContextMenuRequested.connect(self.on_summary_context_menu)

        self._last_layer_results = []
        self._last_skipped_layers = []
        self._last_full_report_text = ""

        self.btnRunCheck.clicked.connect(self.on_run_check)
        self.btnCopySummary.clicked.connect(self.on_copy_summary)
        self.btnExportReport.clicked.connect(self.on_export_report)
        self.helpButton.clicked.connect(self.open_help)

        if self.treeSummary.columnCount() < 6:
            self.treeSummary.setColumnCount(6)
            self.treeSummary.setHeaderLabels(
                ["Layer", "Null", "Empty", "Invalid", "Suspected", "Read errors"]
            )

        self._configure_summary_tree()

        self.lblStatus.setText("Status: idle")
        self.progressBar.setVisible(False)
        self.btnCopySummary.setEnabled(False)
        self.btnExportReport.setEnabled(False)

        project = QgsProject.instance()
        connect_unique(project.cleared, self._on_project_changed)
        connect_unique(project.readProject, self._on_project_changed)

    # ------------------------------------------------------------------ UI hooks

    def closeEvent(self, event):
        """Emit signal when dock widget is closed."""
        self.closingPlugin.emit()
        event.accept()

    def on_run_check(self):
        """Run geometry check and update UI."""
        self.lblStatus.setText("Status: running geometry checks...")
        self.btnRunCheck.setEnabled(False)
        self.btnCopySummary.setEnabled(False)
        self.btnExportReport.setEnabled(False)
        self.progressBar.setValue(0)
        self.progressBar.setVisible(True)

        try:
            layer_results, skipped, report_text = run_geometry_check_on_project(
                deep_validation=DEEP_VALIDATION,
                max_errors_to_log=MAX_ERRORS_TO_LIST,
                progress_callback=self._progress_callback,
            )

            self._last_layer_results = layer_results
            self._last_skipped_layers = skipped
            self._last_full_report_text = report_text

            self.populate_summary_tree(layer_results)
            self.textFullReport.setPlainText(report_text)

            if not any(_is_problematic_result(result) for result in layer_results):
                self.lblStatus.setText("Status: completed - no geometry issues found.")
            else:
                self.lblStatus.setText("Status: completed - issues detected.")

        except Exception as ex:
            self.lblStatus.setText("Status: error during geometry check.")
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                f"An error occurred while running the geometry check:\n{ex}",
            )

        finally:
            self.btnRunCheck.setEnabled(True)
            self.btnCopySummary.setEnabled(bool(self._last_layer_results))
            self.btnExportReport.setEnabled(bool(self._last_full_report_text))
            self.progressBar.setValue(self.progressBar.maximum())
            self.progressBar.setVisible(False)

    def on_copy_summary(self):
        """Copy a compact summary to the clipboard."""
        if not self._last_layer_results:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No results available yet. Please run the geometry check first.",
            )
            return

        text = build_summary_text(self._last_layer_results)
        QGuiApplication.clipboard().setText(text)
        self.lblStatus.setText("Status: summary copied to clipboard.")

    def on_export_report(self):
        """Export the full report to a text file."""
        if not self._last_full_report_text:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No report available yet. Please run the geometry check first.",
            )
            return

        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export Geometry Check Report",
            "",
            "Text files (*.txt);;All files (*)",
        )
        if not filename:
            return

        try:
            with open(filename, "w", encoding="utf-8") as handle:
                handle.write(self._last_full_report_text)
            self.lblStatus.setText(f"Status: report exported to {filename}")
        except Exception as ex:
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                f"Could not export report:\n{ex}",
            )

    # ------------------------------------------------------------------ helpers

    def _configure_summary_tree(self):
        """Apply stable and efficient column behaviour to the summary tree."""
        header = self.treeSummary.header()
        if header is None:
            return

        # Layer names should take the spare horizontal space; count columns remain compact.
        header.setSectionResizeMode(0, SECTION_RESIZE_STRETCH)
        for column in range(1, self.treeSummary.columnCount()):
            header.setSectionResizeMode(column, SECTION_RESIZE_RESIZE_TO_CONTENTS)

    def populate_summary_tree(self, layer_results):
        """Populate the Simple Summary tree with layers that have issues."""
        self.treeSummary.setUpdatesEnabled(False)
        self.treeSummary.clear()

        try:
            problematic_layers = [r for r in layer_results if _is_problematic_result(r)]
            if not problematic_layers:
                return

            for result in problematic_layers:
                item = QTreeWidgetItem(self.treeSummary)
                item.setText(0, result["layer_name"])
                item.setText(1, str(result["null_geometries"]))
                item.setText(2, str(result["empty_geometries"]))
                item.setText(3, str(result["invalid_geometries"]))
                item.setText(4, str(result["suspected_geometries"]))
                item.setText(5, str(result["read_errors"]))
                item.setData(0, USER_ROLE, result["layer_id"])

                columns = {
                    1: result["null_geometries"],
                    2: result["empty_geometries"],
                    3: result["invalid_geometries"],
                    4: result["suspected_geometries"],
                    5: result["read_errors"],
                }
                for column, value in columns.items():
                    if value > 0:
                        item.setForeground(column, RED_COLOR)
        finally:
            self.treeSummary.setUpdatesEnabled(True)

    def _progress_callback(self, processed, total, layer_name):
        """Update progress bar and status label during checks."""
        if total <= 0:
            return

        self.progressBar.setVisible(True)
        self.progressBar.setMaximum(total)
        self.progressBar.setValue(processed)
        self.lblStatus.setText(f"Status: checking layer {processed}/{total} - {layer_name}")

        # Keep the dock responsive without aggressively re-entering the event loop.
        if processed == total or processed % 5 == 0:
            QApplication.processEvents()

    def _get_layer_and_result(self, layer_id):
        """Return (layer, result_dict), or (None, None) if unavailable."""
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            QMessageBox.warning(
                self,
                "Geometry Quality Control",
                "Layer not found. It may have been removed from the project.",
            )
            return None, None

        result = next(
            (entry for entry in self._last_layer_results if entry["layer_id"] == layer_id),
            None,
        )
        if result is None:
            QMessageBox.warning(
                self,
                "Geometry Quality Control",
                "No stored results for this layer. Please run the check again.",
            )
            return None, None

        return layer, result

    def on_summary_context_menu(self, pos):
        """Show a context menu when right-clicking a layer row in the summary."""
        item = self.treeSummary.itemAt(pos)
        if item is None:
            return

        layer_id = item.data(0, USER_ROLE)
        if layer_id is None:
            return

        menu = QMenu(self)
        action_select_null = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/select.png"),
            "Select null geometries",
        )
        action_select_empty = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/select.png"),
            "Select empty geometries",
        )
        action_select_invalid = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/select.png"),
            "Select invalid geometries",
        )
        action_suspect_select = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/select.png"),
            "Select suspected geometries",
        )
        menu.addSeparator()
        action_delete_null_empty = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/bin_red.png"),
            "Delete null or empty geometries",
        )
        menu.addSeparator()
        action_fix_invalid = menu.addAction(
            QIcon(":/plugins/PCA_geometry_quality_control/icons/repair.svg"),
            "Attempt to fix invalid geometries"
        )

        chosen = menu_exec(menu, self.treeSummary.viewport().mapToGlobal(pos))
        if chosen is None:
            return

        if chosen == action_select_null:
            self.select_null_geometries(layer_id)
        elif chosen == action_select_empty:
            self.select_empty_geometries(layer_id)
        elif chosen == action_select_invalid:
            self.select_invalid_geometries(layer_id)
        elif chosen == action_suspect_select:
            self.select_suspect_geometries(layer_id)
        elif chosen == action_delete_null_empty:
            self.delete_null_or_empty_geometries(layer_id)
        elif chosen == action_fix_invalid:
            self.fix_invalid_geometries(layer_id)

    def _select_and_zoom(self, layer, ids, status_label):
        """Select feature IDs, make the layer active, zoom and flash them."""
        ids = list(ids)
        layer.removeSelection()
        layer.selectByIds(ids)

        self.iface.setActiveLayer(layer)
        canvas = self.iface.mapCanvas()
        canvas.zoomToSelected(layer)
        canvas.flashFeatureIds(layer, ids)
        self.lblStatus.setText(status_label)

    def _select_result_ids(self, layer_id, result_key, empty_message, status_template):
        """Select one specific stored geometry issue type for a layer."""
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = set(result.get(result_key, []))
        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                empty_message,
            )
            return

        self._select_and_zoom(
            layer,
            ids,
            status_template.format(count=len(ids), layer_name=layer.name()),
        )

    def select_null_geometries(self, layer_id):
        """Select all features with null geometry in the given layer."""
        self._select_result_ids(
            layer_id,
            "all_null_ids",
            "No null geometries to select for this layer.",
            "Status: selected {count} null-geometry feature(s) in '{layer_name}'.",
        )

    def select_empty_geometries(self, layer_id):
        """Select all features with empty geometry in the given layer."""
        self._select_result_ids(
            layer_id,
            "all_empty_ids",
            "No empty geometries to select for this layer.",
            "Status: selected {count} empty-geometry feature(s) in '{layer_name}'.",
        )

    def select_invalid_geometries(self, layer_id):
        """Select all features with invalid geometry in the given layer."""
        self._select_result_ids(
            layer_id,
            "all_invalid_ids",
            "No invalid geometries to select for this layer.",
            "Status: selected {count} invalid-geometry feature(s) in '{layer_name}'.",
        )

    def select_problem_geometries(self, layer_id):
        """Compatibility wrapper: select all null, empty and invalid geometries."""
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = (
            set(result.get("all_invalid_ids", [])) |
            set(result.get("all_null_ids", [])) |
            set(result.get("all_empty_ids", []))
        )
        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No null, empty or invalid geometries to select for this layer.",
            )
            return

        self._select_and_zoom(
            layer,
            ids,
            f"Status: selected {len(ids)} null, empty or invalid features in '{layer.name()}'.",
        )

    def select_suspect_geometries(self, layer_id):
        """Select all suspected geometries in the given layer."""
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = set(result.get("all_suspected_ids", []))
        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "No suspected geometries to select for this layer.",
            )
            return

        self._select_and_zoom(
            layer,
            ids,
            f"Status: selected {len(ids)} suspected features in '{layer.name()}'.",
        )

    def delete_null_or_empty_geometries(self, layer_id):
        """
        Delete features with null or empty geometry in the given layer.

        Changes are not committed automatically. The layer is left in edit mode
        so the user can review, commit or roll back manually.
        """
        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        ids = sorted(set(result.get("all_null_ids", [])) | set(result.get("all_empty_ids", [])))
        if not ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "This layer has no null or empty geometries to delete.",
            )
            return

        provider = layer.dataProvider()
        if provider is None or not (provider.capabilities() & QgsVectorDataProvider.DeleteFeatures):
            QMessageBox.warning(
                self,
                "Geometry Quality Control",
                "This layer provider does not support feature deletion.",
            )
            return

        reply = QMessageBox.question(
            self,
            "Delete null or empty geometries",
            (
                f"Layer '{layer.name()}' has {len(ids)} feature(s) with null or empty geometry.\n\n"
                "Do you want to delete these features?\n\n"
                "The layer will remain in edit mode so you may commit or roll back the changes manually."
            ),
            MB_YES | MB_NO,
            MB_NO,
        )
        if reply != MB_YES:
            return

        if not layer.isEditable():
            if not layer.startEditing():
                QMessageBox.critical(
                    self,
                    "Geometry Quality Control",
                    "Could not start editing on this layer.",
                )
                return

        layer.beginEditCommand("Delete null or empty geometries")
        failed_ids = []

        try:
            for fid in ids:
                if not layer.deleteFeature(fid):
                    failed_ids.append(fid)

            if failed_ids:
                layer.destroyEditCommand()
                QMessageBox.warning(
                    self,
                    "Geometry Quality Control",
                    (
                        "Some features could not be deleted. No changes were applied.\n\n"
                        f"Failed feature IDs: {failed_ids[:20]}"
                        + (" ..." if len(failed_ids) > 20 else "")
                    ),
                )
                return

            layer.endEditCommand()
        except Exception as ex:
            layer.destroyEditCommand()
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                f"Error deleting null or empty geometries. No changes were applied.\n\n{ex}",
            )
            return

        layer.triggerRepaint()
        self.lblStatus.setText(
            f"Status: deleted {len(ids)} null/empty-geometry features in '{layer.name()}'. "
            "Layer is in EDIT MODE — commit or rollback manually."
        )

        # Refresh QC results after deletion so the panel reflects the current layer state.
        self.on_run_check()

    # Backwards-compatible alias in case any other plugin code calls the old name.
    def delete_null_geometries(self, layer_id):
        """Compatibility wrapper for older internal calls."""
        self.delete_null_or_empty_geometries(layer_id)

    def _on_project_changed(self):
        """
        Clear cached results and UI when the QGIS project changes.
        """
        self._last_layer_results = []
        self._last_skipped_layers = []
        self._last_full_report_text = ""

        self.treeSummary.clear()
        self.textFullReport.clear()
        self.btnCopySummary.setEnabled(False)
        self.btnExportReport.setEnabled(False)
        self.progressBar.setVisible(False)
        self.lblStatus.setText("Status: project changed – please run a new geometry check.")

    def open_help(self):
        """Open the plugin help/index.html file in the default browser."""
        plugin_dir = os.path.dirname(__file__)
        help_path = os.path.join(plugin_dir, "help", "index.html")

        if not os.path.exists(help_path):
            QMessageBox.warning(
                self,
                "Help file not found",
                f"Could not find the help documentation at:\n{help_path}",
            )
            return

        url = QUrl.fromLocalFile(help_path)
        if not QDesktopServices.openUrl(url):
            QMessageBox.warning(
                self,
                "Help file could not be opened",
                f"The help file exists but could not be opened:\n{help_path}",
            )


    def fix_invalid_geometries(self, layer_id):
        """
        Attempt to fix invalid geometries using QgsGeometry.makeValid().

        The operation:
        - only uses invalid feature IDs found by the last geometry check
        - rejects null/empty results
        - rejects results that are still invalid
        - rejects results that change main geometry type
        - keeps the layer in edit mode
        - never commits automatically
        """

        layer, result = self._get_layer_and_result(layer_id)
        if layer is None:
            return

        invalid_ids = list(result.get("all_invalid_ids", []))

        if not invalid_ids:
            QMessageBox.information(
                self,
                "Geometry Quality Control",
                "This layer has no invalid geometries to fix."
            )
            return

        reply = QMessageBox.question(
            self,
            "Attempt to fix invalid geometries",
            (
                f"This will attempt to fix {len(invalid_ids)} invalid geometries in:\n\n"
                f"{layer.name()}\n\n"
                "Important:\n"
                "- fixed geometries may change shape\n"
                "- single geometries may become multipart geometries\n"
                "- collapsed or unsafe results will be skipped\n"
                "- changes will NOT be committed automatically\n\n"
                "The layer will remain in edit mode so you can review, commit, "
                "or roll back manually.\n\n"
                "Continue?"
            ),
            MB_YES | MB_NO,
            MB_NO
        )

        if reply != MB_YES:
            return

        if not layer.isEditable():
            if not layer.startEditing():
                QMessageBox.critical(
                    self,
                    "Geometry Quality Control",
                    "Could not start editing on this layer."
                )
                return

        layer_geom_type = QgsWkbTypes.geometryType(layer.wkbType())

        fixed_count = 0
        skipped = []

        layer.beginEditCommand("Attempt to fix invalid geometries")

        try:
            for fid in invalid_ids:
                feat = layer.getFeature(fid)

                if not feat.isValid():
                    skipped.append((fid, "Feature could not be read."))
                    continue

                geom = feat.geometry()

                if geom is None or geom.isNull() or geom.isEmpty():
                    skipped.append((fid, "Original geometry is null or empty."))
                    continue

                fixed_geom = geom.makeValid()

                if fixed_geom is None or fixed_geom.isNull() or fixed_geom.isEmpty():
                    skipped.append((fid, "makeValid() returned null or empty geometry."))
                    continue

                if not fixed_geom.isGeosValid():
                    skipped.append((fid, "Fixed geometry is still invalid."))
                    continue

                fixed_geom_type = QgsWkbTypes.geometryType(fixed_geom.wkbType())

                if fixed_geom_type != layer_geom_type:
                    skipped.append(
                        (fid, "Fixed geometry has an incompatible geometry type.")
                    )
                    continue

                if not layer.changeGeometry(fid, fixed_geom):
                    skipped.append((fid, "The layer refused the geometry change."))
                    continue

                fixed_count += 1

            if fixed_count == 0:
                layer.destroyEditCommand()
                QMessageBox.warning(
                    self,
                    "Geometry Quality Control",
                    (
                        "No invalid geometries could be safely fixed.\n\n"
                        "No changes were applied."
                    )
                )
                return

            if skipped:
                reply = QMessageBox.question(
                    self,
                    "Partial geometry fix",
                    (
                        f"{fixed_count} geometries were fixed.\n"
                        f"{len(skipped)} geometries could not be safely fixed.\n\n"
                        "Do you want to keep the successful fixes?\n\n"
                        "Choose No to roll back all fixes from this operation."
                    ),
                    MB_YES | MB_NO,
                    MB_NO
                )

                if reply != MB_YES:
                    layer.destroyEditCommand()
                    self.lblStatus.setText(
                        "Status: geometry fix rolled back. No changes were kept."
                    )
                    return

            layer.endEditCommand()
            layer.triggerRepaint()

            self.lblStatus.setText(
                f"Status: fixed {fixed_count} invalid geometries in '{layer.name()}'. "
                "Layer is in EDIT MODE — review, then commit or rollback manually."
            )

            self.on_run_check()

        except Exception as ex:
            layer.destroyEditCommand()
            QMessageBox.critical(
                self,
                "Geometry Quality Control",
                (
                    "An error occurred while fixing geometries.\n\n"
                    "The operation was rolled back.\n\n"
                    f"{ex}"
                )
            )