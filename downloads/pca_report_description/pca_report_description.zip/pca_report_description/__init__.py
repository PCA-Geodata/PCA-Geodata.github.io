# -*- coding: utf-8 -*-
"""QGIS plugin entry point for PCA Report Description Generator."""


def classFactory(iface):  # pylint: disable=invalid-name
    """Return the plugin instance used by QGIS."""
    from .pca_report_description import PCAReportDescriptionGenerator
    return PCAReportDescriptionGenerator(iface)
