# -*- coding: utf-8 -*-
"""Cut, group and context sentence generation engine."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Iterable, List, Sequence, Tuple

from qgis.core import QgsFeature

from .qgis_access import LayerRepository
from .text_utils import (
    clean_sides,
    colour_phrase,
    context_label,
    count_phrase,
    is_blank,
    join_human,
    lower_or,
    natural_sort,
    normalise_key,
    normalise_measure,
    orientation_phrase,
    value_or,
)


@dataclass(frozen=True)
class DescriptionOptions:
    include_dimensions: bool = True
    include_uncertainty_placeholders: bool = True
    include_review_notes: bool = True
    use_context_brackets: bool = True

    # For cuts, Length and Width often refer only to the investigated slot/portion,
    # not the full visible feature. Keep them as placeholders to avoid misleading
    # report text. Depth is normally safe because it comes from the recorded section.
    use_safe_cut_dimensions: bool = True

    # Summarise non-cut contexts linked to a cut, e.g. fills, masonry, skeletons.
    include_cut_contents_summary: bool = True

    # Historical UI option name retained. It now controls all associated context
    # descriptions in cut/group output, not only fill descriptions.
    include_fill_descriptions_in_cut: bool = True


@dataclass(frozen=True)
class DescriptionResult:
    ok: bool
    text: str = ""
    message: str = ""


@dataclass(frozen=True)
class ContextRecord:
    context: str
    cut: str
    context_type: str
    category: str = ""
    group: str = ""
    shape: str = ""
    sides: str = ""
    base: str = ""
    orientation: str = ""
    length: str = ""
    width: str = ""
    depth: str = ""
    compaction: str = ""
    composition: str = ""
    tone: str = ""
    hue: str = ""
    colour: str = ""
    inclusions: str = ""
    fill_sequence: str = ""
    formation: str = ""
    interpretation: str = ""
    cremation_type: str = ""
    cremation_truncation: str = ""
    urn_number: str = ""
    crem_grave_goods: str = ""
    head_at: str = ""
    skeleton_attitude: str = ""
    head: str = ""
    right_arm: str = ""
    left_arm: str = ""
    right_leg: str = ""
    left_leg: str = ""
    feet: str = ""
    skeleton_preservation: str = ""
    coffin: str = ""
    coffin_number: str = ""
    coffin_preservation: str = ""
    coffin_description: str = ""
    coffin_dimensions: str = ""
    masonry_structure: str = ""
    materials: str = ""
    materials_size: str = ""
    stones_finish: str = ""
    coursing: str = ""
    quoins: str = ""
    form: str = ""
    faces: str = ""
    bonding_material: str = ""
    pointing: str = ""
    masonry_dimensions: str = ""
    associated_contexts: str = ""
    timber_structure: str = ""
    timber_type: str = ""
    setting: str = ""
    timber_orientation: str = ""
    cross_section: str = ""
    conversion: str = ""
    condition: str = ""
    timber_dimensions: str = ""
    additional_comments: str = ""

    @classmethod
    def from_feature(cls, feature: QgsFeature) -> "ContextRecord":
        return cls(
            context=value_or(_safe_attr(feature, "Context")),
            cut=value_or(_safe_attr(feature, "Cut")),
            context_type=value_or(_safe_attr(feature, "Type")),
            category=value_or(_safe_attr(feature, "Category")),
            group=value_or(_safe_attr(feature, "Group")),
            shape=value_or(_safe_attr(feature, "Shape")),
            sides=value_or(_safe_attr(feature, "Sides")),
            base=value_or(_safe_attr(feature, "Base")),
            orientation=value_or(_safe_attr(feature, "Orientation")),
            length=normalise_measure(_safe_attr(feature, "Length")),
            width=normalise_measure(_safe_attr(feature, "Width")),
            depth=normalise_measure(_safe_attr(feature, "Depth")),
            compaction=value_or(_safe_attr(feature, "Compaction")),
            composition=value_or(_safe_attr(feature, "Composition")),
            tone=value_or(_safe_attr(feature, "Tone")),
            hue=value_or(_safe_attr(feature, "Hue")),
            colour=value_or(_safe_attr(feature, "Colour")),
            inclusions=value_or(_safe_attr(feature, "Significant_ Inclusions")),
            fill_sequence=value_or(_safe_attr(feature, "Fill_Sequence")),
            formation=value_or(_safe_attr(feature, "Formation")),
            interpretation=value_or(_safe_attr(feature, "Interpretation")),
            cremation_type=value_or(_safe_attr(feature, "Cremation_type")),
            cremation_truncation=value_or(_safe_attr(feature, "Cremation_truncation")),
            urn_number=value_or(_safe_attr(feature, "Urn_Number")),
            crem_grave_goods=value_or(_safe_attr(feature, "Crem_grave_goods")),
            head_at=value_or(_safe_attr(feature, "Head_at")),
            skeleton_attitude=value_or(_safe_attr(feature, "Skeleton_attitude")),
            head=value_or(_safe_attr(feature, "Head")),
            right_arm=value_or(_safe_attr(feature, "Right_arm")),
            left_arm=value_or(_safe_attr(feature, "Left_arm")),
            right_leg=value_or(_safe_attr(feature, "Right_leg")),
            left_leg=value_or(_safe_attr(feature, "Left_leg")),
            feet=value_or(_safe_attr(feature, "Feet")),
            skeleton_preservation=value_or(_safe_attr(feature, "Skeleton_preservation")),
            coffin=value_or(_safe_attr(feature, "Coffin")),
            coffin_number=value_or(_safe_attr(feature, "Coffin_number")),
            coffin_preservation=value_or(_safe_attr(feature, "Coffin_Preservation")),
            coffin_description=value_or(_safe_attr(feature, "Coffin_Description")),
            coffin_dimensions=value_or(_safe_attr(feature, "Coffin_Dimensions")),
            masonry_structure=value_or(_safe_attr(feature, "Masonry_structure")),
            materials=value_or(_safe_attr(feature, "Materials")),
            materials_size=value_or(_safe_attr(feature, "Materials_size")),
            stones_finish=value_or(_safe_attr(feature, "Stones_finish")),
            coursing=value_or(_safe_attr(feature, "Coursing")),
            quoins=value_or(_safe_attr(feature, "Quoins")),
            form=value_or(_safe_attr(feature, "Form")),
            faces=value_or(_safe_attr(feature, "Faces")),
            bonding_material=value_or(_safe_attr(feature, "Bonding_material")),
            pointing=value_or(_safe_attr(feature, "Pointing")),
            masonry_dimensions=value_or(_safe_attr(feature, "Masonry_dimensions")),
            associated_contexts=value_or(_safe_attr(feature, "Associated_contexts")),
            timber_structure=value_or(_safe_attr(feature, "Timber_structure")),
            timber_type=value_or(_safe_attr(feature, "Timber_type")),
            setting=value_or(_safe_attr(feature, "Setting")),
            timber_orientation=value_or(_safe_attr(feature, "Timber_orientation")),
            cross_section=value_or(_safe_attr(feature, "Cross_section")),
            conversion=value_or(_safe_attr(feature, "Conversion")),
            condition=value_or(_safe_attr(feature, "Condition")),
            timber_dimensions=value_or(_safe_attr(feature, "Timber_dimensions")),
            additional_comments=value_or(_safe_attr(feature, "Additional_comments")),
        )

    @property
    def type_key(self) -> str:
        return normalise_key(self.context_type)

    @property
    def category_key(self) -> str:
        return normalise_key(self.category)


class DescriptionEngine:
    """Create draft descriptions from DRS context records.

    The engine only uses information recorded on the context sheet. It does not
    add dating, phasing, interpretation or functional statements beyond what is
    present in the fields used by the templates.
    """

    def __init__(self, repository: LayerRepository):
        self.repository = repository

    def describe_context(
        self,
        context_value: str,
        options: DescriptionOptions,
    ) -> DescriptionResult:
        validation = self.repository.validate_drs_layer()
        if not validation.is_valid:
            return DescriptionResult(False, message=validation.message)

        records = [
            ContextRecord.from_feature(feature)
            for feature in self.repository.contexts_for_context_value(context_value)
        ]

        if not records:
            return DescriptionResult(
                False,
                message=f"No DRS record was found for context '{context_value}'.",
            )

        parts = [self._describe_record(record, options) for record in records]

        notes = self._review_notes(records, options)
        if notes:
            parts.append(notes)

        text = "\n\n".join(part for part in parts if part.strip())
        return DescriptionResult(
            True,
            text=text,
            message="Context description generated. Please review before use.",
        )

    def describe_cut(self, cut_value: str, options: DescriptionOptions) -> DescriptionResult:
        validation = self.repository.validate_drs_layer()
        if not validation.is_valid:
            return DescriptionResult(False, message=validation.message)

        records = [
            ContextRecord.from_feature(feature)
            for feature in self.repository.records_for_cut(cut_value)
        ]

        cut_records = [record for record in records if record.type_key == "cut"]

        if not records:
            return DescriptionResult(
                False,
                message=f"No DRS records were found for cut/context '{cut_value}'.",
            )

        parts: List[str] = []

        if cut_records:
            for record in cut_records:
                parts.append(self._describe_cut_record(record, records, options))
        else:
            parts.append(
                f"No cut record was found for {context_label(cut_value, options.use_context_brackets)}, "
                "but associated context records were found."
            )

        if options.include_cut_contents_summary:
            content_summary = self._cut_contents_summary(records)
            if content_summary:
                parts.append(content_summary)

        if options.include_fill_descriptions_in_cut:
            associated_text = self._associated_context_descriptions(records, options)
            if associated_text:
                parts.append(associated_text)

        notes = self._review_notes(records, options)
        if notes:
            parts.append(notes)

        text = "\n\n".join(part for part in parts if part.strip())
        return DescriptionResult(
            True,
            text=text,
            message="Cut description generated. Please review before use.",
        )

    def describe_group(self, group_value: str, options: DescriptionOptions) -> DescriptionResult:
        validation = self.repository.validate_drs_layer()
        if not validation.is_valid:
            return DescriptionResult(False, message=validation.message)

        cut_features = self.repository.cuts_for_group(group_value)
        cut_records = [ContextRecord.from_feature(feature) for feature in cut_features]

        if not cut_records:
            return DescriptionResult(
                False,
                message=f"No cut records were found for group '{group_value}'.",
            )

        if len(cut_records) == 1:
            return self.describe_cut(cut_records[0].cut, options)

        cut_numbers = natural_sort(
            [context_label(record.cut, options.use_context_brackets) for record in cut_records]
        )

        categories = sorted(
            set(lower_or(record.category, "feature") for record in cut_records if value_or(record.category))
        )
        shapes = sorted(set(lower_or(record.shape, "uncertain") for record in cut_records))
        sides = sorted(set(clean_sides(record.sides) for record in cut_records))
        bases = sorted(set(lower_or(record.base, "uncertain") for record in cut_records))
        orientations = sorted(
            set(filter(None, (self._format_orientation(record.orientation) for record in cut_records)))
        )
        depths = [record.depth for record in cut_records if record.depth and record.depth != "????"]

        title = f"{group_value} ({', '.join(cut_numbers)})"
        summary_subject = join_human(categories) if categories else "features"

        summary = (
            f"{group_value} comprised {len(cut_records)} recorded cuts "
            f"({summary_subject}). The cuts were {join_human(shapes)} in plan, "
            f"with {join_human(sides, 'to')} sloping sides and "
            f"{join_human(bases, 'to')} bases"
        )

        if orientations:
            summary += f", aligned {join_human(orientations)}"

        summary += "."

        if options.include_dimensions:
            if depths:
                summary += f" They measured up to {max(depths)}m deep."
            elif options.include_uncertainty_placeholders:
                summary += " Depth measurements require review."

        cut_sections: List[str] = []
        for cut in cut_records:
            result = self.describe_cut(cut.cut, options)
            if result.ok and result.text:
                cut_sections.append(
                    f"{context_label(cut.cut, options.use_context_brackets)}\n{result.text}"
                )

        notes = self._review_notes(cut_records, options)

        body_parts = [title, summary]
        if cut_sections:
            body_parts.extend(cut_sections)
        if notes:
            body_parts.append(notes)

        body = "\n\n".join(part for part in body_parts if part.strip())
        return DescriptionResult(
            True,
            text=body,
            message="Group description generated. Please review before use.",
        )

    def _describe_record(self, record: ContextRecord, options: DescriptionOptions) -> str:
        """Route any context to the correct dedicated template."""
        if self._is_cremation_record(record):
            return self._describe_cremation(record, options)

        if self._is_burial_cut(record):
            return self._describe_burial_cut(record, options)

        if record.type_key == "cut":
            return self._describe_cut_record(record, [record], options)

        if record.type_key == "fill":
            return self._describe_fill(record, options)

        if record.type_key == "layer":
            return self._describe_layer(record, options)

        if record.type_key == "masonry":
            return self._describe_masonry(record, options)

        if record.type_key == "skeleton":
            return self._describe_skeleton(record, options)

        if record.type_key in {"unexcavated feature", "void natural", "void"}:
            return self._describe_unexcavated_or_void(record, options)

        if record.type_key in {"structure", "timber", "wood"}:
            return self._describe_structure(record, options)

        return self._describe_generic_context(record, options)

    def _describe_cut_record(
        self,
        record: ContextRecord,
        all_cut_records: Iterable[ContextRecord],
        options: DescriptionOptions,
    ) -> str:
        cut_label = context_label(
            record.cut or record.context,
            options.use_context_brackets,
        )
        category = lower_or(record.category, "feature")
        shape = lower_or(record.shape, "uncertain")
        sides = clean_sides(record.sides)
        base = lower_or(record.base, "uncertain")
        orientation = self._format_orientation(record.orientation)

        text = f"The {category} {cut_label} was {shape} in plan"

        if orientation:
            text += (
                f" and was aligned {orientation}. "
                f"It had {sides} sloping sides and a {base} base."
            )
        else:
            text += f", with {sides} sloping sides and a {base} base."

        if options.include_dimensions:
            text += self._dimension_sentence(record, options)

        cremation_extra = self._cremation_extra_sentence(record)
        if cremation_extra:
            text += f" {cremation_extra}"

        return text

    def _cut_contents_summary(self, records: Iterable[ContextRecord]) -> str:
        contents = [record for record in records if record.type_key != "cut"]

        if not contents:
            return ""

        counter = Counter(self._content_label(record) for record in contents)
        phrases = [
            count_phrase(count, label)
            for label, count in sorted(counter.items())
        ]

        return f"It contained {join_human(phrases)}."

    def _content_label(self, record: ContextRecord) -> str:
        if self._is_cremation_record(record):
            return "cremation"

        if record.type_key == "fill":
            return "fill"

        if record.type_key == "skeleton":
            return "skeleton"

        if record.type_key == "masonry":
            if "wall" in record.category_key or "wall" in normalise_key(record.form):
                return "wall"
            return "masonry"

        if record.type_key == "layer":
            return "layer"

        if record.type_key in {"structure", "timber", "wood"}:
            return "structure"

        if record.type_key in {"unexcavated feature", "void natural", "void"}:
            return "context"

        if record.category:
            return lower_or(record.category, "context")

        return "context"

    def _associated_context_descriptions(
        self,
        records: Iterable[ContextRecord],
        options: DescriptionOptions,
    ) -> str:
        """Describe non-cut records associated with a cut.

        This expands all associated records using their own dedicated templates:
        fills, layers, masonry, skeletons, cremation records, structures and
        other context types.
        """
        associated = [record for record in records if record.type_key != "cut"]

        if not associated:
            return ""

        associated = sorted(associated, key=self._associated_sort_key)

        descriptions = []
        for record in associated:
            text = self._describe_record(record, options)
            if text:
                descriptions.append(text)

        return "\n".join(descriptions)

    def _describe_fill(self, record: ContextRecord, options: DescriptionOptions) -> str:
        fill_label = context_label(record.context, False)
        sequence = record.fill_sequence.replace("/", " of ") if record.fill_sequence else ""
        sequence_text = f" - {sequence} -" if sequence else ""

        colour = colour_phrase(record.tone, record.hue, record.colour)
        compaction = lower_or(record.compaction, "uncertain compaction")
        composition = lower_or(record.composition, "uncertain composition")

        text = (
            f"Fill {fill_label}{sequence_text} was {compaction}, "
            f"with a {colour} colour and {composition} composition."
        )

        if record.inclusions:
            text += f" Inclusions comprised {self._clean_terminal_punctuation(lower_or(record.inclusions))}."

        if record.formation:
            text += f" Formation was recorded as {self._clean_terminal_punctuation(lower_or(record.formation))}."

        cremation_extra = self._cremation_extra_sentence(record)
        if cremation_extra:
            text += f" {cremation_extra}"

        return text

    def _describe_layer(self, record: ContextRecord, options: DescriptionOptions) -> str:
        label = context_label(record.context, False)
        category = lower_or(record.category, "layer")
        colour = colour_phrase(record.tone, record.hue, record.colour)
        compaction = lower_or(record.compaction, "uncertain compaction")
        composition = lower_or(record.composition, "uncertain composition")

        text = (
            f"The {category} {label} was {compaction}, with a {colour} colour "
            f"and {composition} composition."
        )

        if record.inclusions:
            text += f" Inclusions comprised {self._clean_terminal_punctuation(lower_or(record.inclusions))}."

        if record.formation:
            text += f" Formation was recorded as {self._clean_terminal_punctuation(lower_or(record.formation))}."

        if options.include_dimensions:
            text += self._dimension_sentence(record, options)

        return text

    def _describe_masonry(self, record: ContextRecord, options: DescriptionOptions) -> str:
        """Dedicated masonry template using masonry-specific DRS fields."""
        label = context_label(record.context, False)

        # Prefer masonry Form where present because in the real table it often
        # holds the archaeological object, e.g. Wall, Wall foundation.
        form = lower_or(record.form)
        category = lower_or(record.category, "masonry")
        object_name = form if form else category

        subject = f"The {object_name} {label}"

        clauses = []

        if record.masonry_structure:
            clauses.append(f"formed part of {lower_or(record.masonry_structure)}")

        if record.materials:
            material = lower_or(record.materials)
            if record.materials_size:
                material += f" ({lower_or(record.materials_size)})"
            clauses.append(f"comprised {material}")

        if record.stones_finish:
            clauses.append(f"with {lower_or(record.stones_finish)} stone finish")

        if record.coursing:
            clauses.append(f"with {lower_or(record.coursing)} coursing")

        if record.faces:
            clauses.append(f"with {lower_or(record.faces)} faces")

        if record.bonding_material:
            clauses.append(f"bonded with {lower_or(record.bonding_material)}")

        if record.pointing:
            clauses.append(f"with {lower_or(record.pointing)} pointing")

        if record.quoins:
            clauses.append(f"quoins were recorded as {lower_or(record.quoins)}")

        if clauses:
            text = f"{subject} " + "; ".join(clauses) + "."
        else:
            text = f"{subject} was recorded as masonry."

        if record.masonry_dimensions:
            text += f" Dimensions were recorded as {self._clean_terminal_punctuation(record.masonry_dimensions)}."

        if record.associated_contexts:
            text += f" Associated contexts were recorded as {self._clean_terminal_punctuation(record.associated_contexts)}."

        if record.additional_comments:
            text += f" Additional comments: {self._clean_terminal_punctuation(record.additional_comments)}."

        return text

    def _describe_skeleton(self, record: ContextRecord, options: DescriptionOptions) -> str:
        label = context_label(record.context, False)
        category = lower_or(record.category, "skeleton")

        text = f"The {category} {label} was recorded"

        details = []

        if record.skeleton_attitude:
            details.append(f"in a {lower_or(record.skeleton_attitude)} attitude")

        if record.head_at:
            details.append(f"with the head at {lower_or(record.head_at)}")

        if details:
            text += " " + " and ".join(details)

        text += "."

        body_parts = []
        for label_text, value in (
            ("head", record.head),
            ("right arm", record.right_arm),
            ("left arm", record.left_arm),
            ("right leg", record.right_leg),
            ("left leg", record.left_leg),
            ("feet", record.feet),
        ):
            if value:
                body_parts.append(f"{label_text}: {lower_or(value)}")

        if body_parts:
            text += " Body position was recorded as " + "; ".join(body_parts) + "."

        if record.skeleton_preservation:
            text += f" Preservation was recorded as {lower_or(record.skeleton_preservation)}."

        if record.coffin:
            text += f" Coffin evidence was recorded as {lower_or(record.coffin)}."

        if record.coffin_number:
            text += f" Coffin number: {record.coffin_number}."

        if record.coffin_preservation:
            text += f" Coffin preservation was recorded as {lower_or(record.coffin_preservation)}."

        if record.coffin_description:
            text += f" Coffin description: {self._clean_terminal_punctuation(record.coffin_description)}."

        if record.coffin_dimensions:
            text += f" Coffin dimensions: {self._clean_terminal_punctuation(record.coffin_dimensions)}."

        return text

    def _describe_cremation(self, record: ContextRecord, options: DescriptionOptions) -> str:
        if record.type_key == "cut":
            text = self._describe_cut_record(record, [record], options)
        elif record.type_key == "fill":
            text = self._describe_fill(record, options)
        else:
            label = context_label(record.context, False)
            category = lower_or(record.category, "cremation")
            text = f"The {category} {label} was recorded."

        extra = self._cremation_extra_sentence(record)
        if extra and extra not in text:
            text += f" {extra}"

        return text

    def _describe_burial_cut(self, record: ContextRecord, options: DescriptionOptions) -> str:
        return self._describe_cut_record(record, [record], options)

    def _describe_structure(self, record: ContextRecord, options: DescriptionOptions) -> str:
        label = context_label(record.context, False)
        category = lower_or(record.category, "structure")

        parts = []
        if record.timber_structure:
            parts.append(f"formed part of {lower_or(record.timber_structure)}")
        if record.timber_type:
            parts.append(f"timber type was recorded as {lower_or(record.timber_type)}")
        if record.setting:
            parts.append(f"setting was recorded as {lower_or(record.setting)}")
        if record.timber_orientation:
            parts.append(f"orientation was {self._format_orientation(record.timber_orientation)}")
        if record.cross_section:
            parts.append(f"cross-section was {lower_or(record.cross_section)}")
        if record.condition:
            parts.append(f"condition was {lower_or(record.condition)}")

        if parts:
            text = f"The {category} {label} " + "; ".join(parts) + "."
        else:
            text = f"The {category} {label} was recorded as a structure."

        if record.timber_dimensions:
            text += f" Dimensions were recorded as {self._clean_terminal_punctuation(record.timber_dimensions)}."

        if record.additional_comments:
            text += f" Additional comments: {self._clean_terminal_punctuation(record.additional_comments)}."

        return text

    def _describe_unexcavated_or_void(self, record: ContextRecord, options: DescriptionOptions) -> str:
        label = context_label(record.context, False)
        record_type = lower_or(record.context_type, "context")
        category = lower_or(record.category, "feature")

        text = f"The {record_type} {label} was recorded as {category}."

        if record.shape:
            text += f" It was {lower_or(record.shape)} in plan."

        if record.orientation:
            text += f" It was aligned {self._format_orientation(record.orientation)}."

        if record.additional_comments:
            text += f" Additional comments: {self._clean_terminal_punctuation(record.additional_comments)}."

        return text

    def _describe_generic_context(self, record: ContextRecord, options: DescriptionOptions) -> str:
        label = context_label(record.context, False)
        record_type = lower_or(record.context_type, "context")
        category = lower_or(record.category, "context")

        text = f"The {record_type} {label} was recorded as {category}."

        if record.additional_comments:
            text += f" Additional comments: {self._clean_terminal_punctuation(record.additional_comments)}."

        return text

    def _dimension_sentence(self, record: ContextRecord, options: DescriptionOptions) -> str:
        record_type = record.type_key
        missing = "????" if options.include_uncertainty_placeholders else "uncertain"

        depth = record.depth if record.depth and record.depth != "????" else missing

        if record_type == "cut" and options.use_safe_cut_dimensions:
            return f" It measured c.????m long, ????m wide, and {depth}m deep."

        length = record.length if record.length and record.length != "????" else missing
        width = record.width if record.width and record.width != "????" else missing

        if not options.include_uncertainty_placeholders and length == width == depth == "uncertain":
            return " Its dimensions require review."

        return f" It measured c.{length}m long, {width}m wide, and {depth}m deep."

    def _review_notes(self, records: Iterable[ContextRecord], options: DescriptionOptions) -> str:
        if not options.include_review_notes:
            return ""

        notes = []

        for record in records:
            label = record.context or record.cut or "unknown context"
            required_fields = self._required_fields_for_review(record)
            missing = []

            for field_name, value in required_fields:
                if is_blank(value):
                    missing.append(field_name)

            if missing:
                notes.append(f"- {label}: check missing {', '.join(missing)}.")

        unique = []
        for note in notes:
            if note not in unique:
                unique.append(note)

        return "Review notes:\n" + "\n".join(unique) if unique else ""

    def _required_fields_for_review(self, record: ContextRecord) -> Sequence[Tuple[str, str]]:
        if self._is_cremation_record(record):
            if record.type_key == "cut":
                return (
                    ("shape", record.shape),
                    ("sides", record.sides),
                    ("base", record.base),
                    ("cremation type", record.cremation_type),
                )
            return (
                ("composition", record.composition),
                ("colour", record.colour),
                ("cremation type", record.cremation_type),
            )

        if record.type_key == "cut":
            return (
                ("shape", record.shape),
                ("sides", record.sides),
                ("base", record.base),
            )

        if record.type_key in {"fill", "layer"}:
            return (
                ("composition", record.composition),
                ("colour", record.colour),
            )

        if record.type_key == "masonry":
            return (
                ("materials", record.materials),
                ("form", record.form),
                ("bonding material", record.bonding_material),
            )

        if record.type_key == "skeleton":
            return (
                ("skeleton attitude", record.skeleton_attitude),
                ("head at", record.head_at),
                ("skeleton preservation", record.skeleton_preservation),
            )

        if record.type_key in {"structure", "timber", "wood"}:
            return (
                ("timber type", record.timber_type),
                ("setting", record.setting),
                ("condition", record.condition),
            )

        return ()

    def _cremation_extra_sentence(self, record: ContextRecord) -> str:
        parts = []

        if record.cremation_type:
            parts.append(f"cremation type was recorded as {lower_or(record.cremation_type)}")

        if record.cremation_truncation:
            parts.append(f"truncation was recorded as {lower_or(record.cremation_truncation)}")

        if record.urn_number:
            parts.append(f"urn number {record.urn_number} was recorded")

        if record.crem_grave_goods:
            parts.append(f"grave goods were recorded as {lower_or(record.crem_grave_goods)}")

        if not parts:
            return ""

        return "Cremation details: " + "; ".join(parts) + "."

    def _is_cremation_record(self, record: ContextRecord) -> bool:
        combined = f"{record.type_key} {record.category_key}"
        return (
            "cremation" in combined
            or "crem " in combined
            or bool(record.cremation_type)
            or bool(record.urn_number)
            or bool(record.crem_grave_goods)
        )

    def _is_burial_cut(self, record: ContextRecord) -> bool:
        if record.type_key != "cut":
            return False
        return any(term in record.category_key for term in ("burial", "grave", "inhumation"))

    def _fill_sort_key(self, record: ContextRecord):
        if record.fill_sequence:
            try:
                return (0, float(record.fill_sequence))
            except ValueError:
                return (0, record.fill_sequence)
        return (1, natural_sort([record.context])[0])

    def _associated_sort_key(self, record: ContextRecord):
        if self._is_cremation_record(record):
            base = 25
        else:
            order = {
                "fill": 10,
                "masonry": 20,
                "skeleton": 30,
                "layer": 40,
                "structure": 50,
                "timber": 50,
                "wood": 50,
            }
            base = order.get(record.type_key, 90)

        fill_sort = self._fill_sort_key(record)
        return (base, fill_sort, natural_sort([record.context])[0])

    def _format_orientation(self, value: str) -> str:
        raw = value_or(value)
        if not raw:
            return ""

        # Keep compact archaeological alignment notation readable.
        # Examples: NE-SW, N-S, ENE-WSW.
        compact = raw.strip().upper().replace(" ", "")
        if "-" in compact:
            return compact

        return orientation_phrase(raw)

    def _clean_terminal_punctuation(self, text: str) -> str:
        return value_or(text).rstrip(" .;:")


def _safe_attr(feature: QgsFeature, field_name: str):
    fields = feature.fields()

    if fields.indexFromName(field_name) != -1:
        return feature[field_name]

    # Some Google Forms exports contain accidental trailing spaces in headers.
    target = field_name.strip().lower()
    for field in fields:
        if field.name().strip().lower() == target:
            return feature[field.name()]

    return ""
