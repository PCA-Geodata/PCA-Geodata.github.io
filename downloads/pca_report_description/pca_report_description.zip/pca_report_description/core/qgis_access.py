# -*- coding: utf-8 -*-
"""QGIS layer access helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from qgis.core import (
    QgsExpression,
    QgsFeature,
    QgsFeatureRequest,
    QgsProject,
    QgsVectorLayer,
)

from .text_utils import is_blank, natural_sort


@dataclass(frozen=True)
class ValidationResult:
    is_valid: bool
    message: str = ""


class LayerRepository:
    """Read-only access to DRS and selection layers.

    Trench/LOE spatial logic has been removed until a company-wide trench
    description standard is agreed.
    """

    DRS_LAYER_NAMES: Sequence[str] = ("DRS_Context_Database", "DRS_Table")

    def layer_by_name(self, name: str) -> Optional[QgsVectorLayer]:
        layers = QgsProject.instance().mapLayersByName(name)
        if not layers:
            return None

        layer = layers[0]
        if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            return None

        return layer

    def first_layer_by_names(self, names: Sequence[str]) -> Optional[QgsVectorLayer]:
        for name in names:
            layer = self.layer_by_name(name)
            if layer is not None:
                return layer

        return None

    def drs_layer(self) -> Optional[QgsVectorLayer]:
        return self.first_layer_by_names(self.DRS_LAYER_NAMES)

    def validate_drs_layer(self) -> ValidationResult:
        layer = self.drs_layer()
        if layer is None:
            return ValidationResult(
                False,
                "No DRS context layer found. Expected 'DRS_Context_Database' or 'DRS_Table'.",
            )

        required = {"Context", "Type", "Cut"}
        missing = sorted(required.difference(self.field_names(layer)))

        if missing:
            return ValidationResult(
                False,
                "The DRS context layer is missing required fields: {}.".format(", ".join(missing)),
            )

        if layer.featureCount() == 0:
            return ValidationResult(False, "The DRS context layer is empty.")

        return ValidationResult(True, "DRS context layer found.")

    def field_names(self, layer: QgsVectorLayer) -> List[str]:
        return [field.name() for field in layer.fields()]

    def has_field(self, layer: QgsVectorLayer, field_name: str) -> bool:
        return layer.fields().indexFromName(field_name) != -1

    def first_existing_field_name(
        self,
        layer: QgsVectorLayer,
        candidates: Sequence[str],
    ) -> Optional[str]:
        """Return the actual layer field name matching one of the candidates.

        The comparison ignores case and leading/trailing spaces because the Google
        Forms exports sometimes contain small variations such as trailing spaces.
        """
        lookup = {
            field.name().strip().lower(): field.name()
            for field in layer.fields()
        }

        for candidate in candidates:
            existing = lookup.get(candidate.strip().lower())
            if existing:
                return existing

        return None

    def unique_values(self, field_name: str) -> List[str]:
        layer = self.drs_layer()
        if layer is None:
            return []

        actual_field = self.first_existing_field_name(layer, (field_name,))
        if actual_field is None:
            return []

        values = set()
        request = QgsFeatureRequest().setSubsetOfAttributes([actual_field], layer.fields())

        for feature in layer.getFeatures(request):
            value = feature[actual_field]
            if not is_blank(value):
                values.add(str(value).strip())

        return natural_sort(values)

    def features_by_field_value(self, field_name: str, value: str) -> List[QgsFeature]:
        layer = self.drs_layer()
        if layer is None:
            return []

        actual_field = self.first_existing_field_name(layer, (field_name,))
        if actual_field is None:
            return []

        expression = "{} = {}".format(
            QgsExpression.quotedColumnRef(actual_field),
            QgsExpression.quotedString(str(value)),
        )

        return list(
            layer.getFeatures(
                QgsFeatureRequest().setFilterExpression(expression)
            )
        )

    def features_by_type_and_value(
        self,
        value_field: str,
        value: str,
        type_value: str,
    ) -> List[QgsFeature]:
        layer = self.drs_layer()
        if layer is None:
            return []

        actual_value_field = self.first_existing_field_name(layer, (value_field,))
        actual_type_field = self.first_existing_field_name(layer, ("Type",))

        if actual_value_field is None or actual_type_field is None:
            return []

        expression = "lower(trim({type_col})) = lower({type_value}) AND {value_col} = {value}".format(
            type_col=QgsExpression.quotedColumnRef(actual_type_field),
            type_value=QgsExpression.quotedString(str(type_value).strip()),
            value_col=QgsExpression.quotedColumnRef(actual_value_field),
            value=QgsExpression.quotedString(str(value)),
        )

        return list(
            layer.getFeatures(
                QgsFeatureRequest().setFilterExpression(expression)
            )
        )

    def contexts_for_context_value(self, context_value: str) -> List[QgsFeature]:
        return self.features_by_field_value("Context", context_value)

    def records_for_cut(self, cut_value: str) -> List[QgsFeature]:
        return self.features_by_field_value("Cut", cut_value)

    def cuts_for_group(self, group_value: str) -> List[QgsFeature]:
        return self.features_by_type_and_value("Group", group_value, "Cut")

    def fills_for_cut(self, cut_value: str) -> List[QgsFeature]:
        return self.features_by_type_and_value("Cut", cut_value, "Fill")

    def cuts_for_cut_value(self, cut_value: str) -> List[QgsFeature]:
        return self.features_by_type_and_value("Cut", cut_value, "Cut")

    def layers_for_cut(self, cut_value: str) -> List[QgsFeature]:
        return self.features_by_type_and_value("Cut", cut_value, "Layer")

    def single_selected_value(self, layer_name: str, field_name: str) -> Optional[str]:
        layer = self.layer_by_name(layer_name)
        if layer is None:
            return None

        actual_field = self.first_existing_field_name(layer, (field_name,))
        if actual_field is None:
            return None

        selected = layer.selectedFeatures()
        if len(selected) != 1:
            return None

        value = selected[0][actual_field]
        return None if is_blank(value) else str(value).strip()
