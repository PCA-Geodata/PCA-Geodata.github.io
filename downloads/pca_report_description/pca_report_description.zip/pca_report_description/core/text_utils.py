# -*- coding: utf-8 -*-
"""Text and value helpers."""

from __future__ import annotations

import re
from typing import Iterable, List

from qgis.core import NULL


def is_blank(value) -> bool:
    return value is None or value == NULL or str(value).strip() == ""


def value_or(value, default: str = "") -> str:
    if is_blank(value):
        return default
    return str(value).strip()


def lower_or(value, default: str = "") -> str:
    return value_or(value, default).lower().strip()


def normalise_key(value) -> str:
    """Normalise a DRS Type/Category value for comparisons."""
    text = value_or(value)
    text = text.strip().lower()
    text = text.replace("_", " ")
    text = text.replace("-", " ")
    text = re.sub(r"\s+", " ", text)
    return text


def normalise_measure(value, missing: str = "????") -> str:
    text = value_or(value, missing)
    if not text or text == missing:
        return missing
    text = text.replace("m", "").strip()
    if text.startswith("."):
        return f"0{text}"
    return text


def natural_sort(values: Iterable[str]) -> List[str]:
    def convert(text: str):
        return int(text) if text.isdigit() else text.lower()

    def key(value: str):
        return [convert(chunk) for chunk in re.split(r"([0-9]+)", str(value))]

    return sorted(values, key=key)


def clean_sides(value) -> str:
    text = value_or(value, "uncertain")
    text = re.sub(r"\(.*?\)", "", text)
    text = text.replace(",", " and ")
    text = re.sub(r"\s+", " ", text).strip().lower()
    if text == "moderate":
        return "moderately"
    return text or "uncertain"


def colour_phrase(tone, hue, colour) -> str:
    parts = [lower_or(tone), lower_or(hue), lower_or(colour, "uncertain colour")]
    return " ".join(part for part in parts if part)


def orientation_phrase(value) -> str:
    text = value_or(value)
    if not text or text in {"-", "N/A", "n/a"}:
        return ""

    replacements = {
        "N": "north", "S": "south", "E": "east", "W": "west",
        "NE": "northeast", "NW": "northwest", "SE": "southeast", "SW": "southwest",
        "NNE": "north-northeast", "NNW": "north-northwest",
        "ENE": "east-northeast", "ESE": "east-southeast",
        "SSE": "south-southeast", "SSW": "south-southwest",
        "WSW": "west-southwest", "WNW": "west-northwest",
    }

    return replacements.get(text.upper().strip(), text.lower())


def join_human(values: Iterable[str], connector: str = "and") -> str:
    clean = [str(v).strip() for v in values if str(v).strip()]
    if not clean:
        return "uncertain"
    if len(clean) == 1:
        return clean[0]
    if len(clean) == 2:
        return f" {connector} ".join(clean)
    return f"{', '.join(clean[:-1])}, {connector} {clean[-1]}"


def pluralise(noun: str, count: int) -> str:
    if count == 1:
        return noun

    irregular = {
        "fill": "fills",
        "skeleton": "skeletons",
        "masonry": "masonry contexts",
        "wall": "walls",
        "cremation": "cremations",
        "layer": "layers",
        "deposit": "deposits",
        "context": "contexts",
    }

    if noun in irregular:
        return irregular[noun]

    if noun.endswith("y"):
        return noun[:-1] + "ies"

    if noun.endswith(("s", "x", "ch", "sh")):
        return noun + "es"

    return noun + "s"


def count_phrase(count: int, noun: str) -> str:
    numbers = {
        0: "no",
        1: "one",
        2: "two",
        3: "three",
        4: "four",
        5: "five",
        6: "six",
        7: "seven",
        8: "eight",
        9: "nine",
        10: "ten",
    }
    return f"{numbers.get(count, str(count))} {pluralise(noun, count)}"


def context_label(value, use_brackets: bool = True) -> str:
    text = value_or(value, "????")
    return f"[{text}]" if use_brackets else f"({text})"
