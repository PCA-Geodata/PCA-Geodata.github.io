# -*- coding: utf-8 -*-
"""Main QGIS plugin controller for PCA Report Description Generator."""

from __future__ import annotations

import os
from typing import List, Optional

from qgis.PyQt.QtCore import QCoreApplication, QEvent, QUrl
from qgis.PyQt.QtGui import QDesktopServices, QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QApplication,
    QDockWidget,
    QMessageBox,
    QToolBar,
)

from .core.description_engine import DescriptionEngine, DescriptionOptions
from .core.qgis_access import LayerRepository
from .pca_report_description_dockwidget import PCAReportDescriptionDockWidget
from .utils.qt_compat import right_dock_area

from .pca_menu_helper import (
    get_or_create_plugin_submenu,
    remove_empty_duplicate_pca_menus,
    remove_plugin_submenu_if_empty,
)


class PCAReportDescriptionGenerator:
    """Main plugin controller."""

    MENU_NAME = "&PCA Report Description Generator"
    TOOLBAR_NAME = "PCA Report Description Generator"

    DOCK_OBJECT_NAME = "PCA_Report_Description_Generator_DockWidget"
    DOCK_TITLE = "PCA Report Description Generator"

    TOOLBAR_OBJECT_NAME = "PCA_Report_Description_Generator_ToolBar"

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        self.actions: List[QAction] = []
        self.toolbar: Optional[QToolBar] = None
        self.plugin_menu = None
        self.dockwidget: Optional[PCAReportDescriptionDockWidget] = None

        self.repository = LayerRepository()
        self.description_engine = DescriptionEngine(self.repository)

        self._is_active = False
        self._selection_layers_connected = set()

        self.plugin_version = self._read_plugin_version()

    def tr(self, message: str) -> str:
        return QCoreApplication.translate(
            "PCA Report Description Generator",
            message,
        )

    def add_action(
        self,
        icon: QIcon,
        text: str,
        callback,
        enabled_flag: bool = True,
        add_to_menu: bool = True,
        add_to_toolbar: bool = True,
        status_tip: Optional[str] = None,
        whats_this: Optional[str] = None,
        parent=None,
    ) -> QAction:
        """Create an action and add it to the PCA submenu and/or toolbar."""
        if parent is None:
            parent = self.iface.mainWindow()

        action = QAction(icon, text, parent)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)

        if whats_this:
            action.setWhatsThis(whats_this)

        action.triggered.connect(callback)

        if add_to_toolbar and self.toolbar is not None:
            self.toolbar.addAction(action)

        if add_to_menu and self.plugin_menu is not None:
            self.plugin_menu.addAction(action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create plugin toolbar and PCA submenu action."""
        self._cleanup_owned_widgets()

        self.toolbar = self.iface.addToolBar(self.TOOLBAR_NAME)
        self.toolbar.setObjectName(self.TOOLBAR_OBJECT_NAME)
        self.toolbar.setWindowTitle(self.TOOLBAR_NAME)

        remove_empty_duplicate_pca_menus(self.iface)

        self.plugin_menu = get_or_create_plugin_submenu(
            self.iface,
            "PCA Report Description Generator",
            "PCA_Report_Description_Generator_Menu",
        )

        self.add_action(
            icon=self._icon("PCA_logo_square.png"),
            text=self.tr("PCA Report Description Generator") + f" - v.{self.plugin_version}",
            callback=self.noop,
            status_tip=self.tr("Open the PCA report description generator panel"),
            add_to_toolbar=True,
            add_to_menu=True,
        )

        self.add_action(
            icon=self._icon("PCA_report_generator_icon.png"),
            text=self.tr("PCA Report Description Generator"),
            callback=self.run,
            status_tip=self.tr("Open the PCA report description generator panel"),
            add_to_toolbar=True,
            add_to_menu=True,
        )

    def unload(self):
        """Remove plugin GUI elements and disconnect runtime signals."""
        self._disconnect_selection_signals()

        for action in self.actions:
            try:
                action.triggered.disconnect()
            except Exception:
                pass

            if self.plugin_menu is not None:
                try:
                    self.plugin_menu.removeAction(action)
                except Exception:
                    pass

            if self.toolbar is not None:
                try:
                    self.toolbar.removeAction(action)
                except Exception:
                    pass

            action.deleteLater()

        self.actions.clear()

        if self.plugin_menu is not None:
            remove_plugin_submenu_if_empty(
                self.iface,
                self.plugin_menu,
            )
            self.plugin_menu = None

        self._cleanup_owned_widgets()

        self.toolbar = None
        self.dockwidget = None
        self._is_active = False

    def _read_plugin_version(self):
        metadata_path = os.path.join(self.plugin_dir, "metadata.txt")

        if not os.path.exists(metadata_path):
            print("metadata.txt not found!")
            return "unknown"

        version = "unknown"

        try:
            with open(metadata_path, "r", encoding="utf-8") as file_obj:
                for line in file_obj:
                    if line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                        break
        except Exception as error:
            print(f"Could not read metadata.txt: {error}")

        return version

    def run(self):
        """Open or raise the dock widget."""
        if self.dockwidget is None:
            self.dockwidget = PCAReportDescriptionDockWidget(
                self.iface.mainWindow()
            )
            self.dockwidget.setObjectName(self.DOCK_OBJECT_NAME)
            self.dockwidget.setWindowTitle(self.DOCK_TITLE)
            self.dockwidget.closingPlugin.connect(self._on_dock_closed)
            self._connect_ui()

        if not self._is_active:
            self._add_dockwidget_to_right_panel()
            self._is_active = True

        self.dockwidget.show()
        self.dockwidget.raise_()
        self.refresh_values()
        self._connect_selection_signals()

    def _cleanup_owned_widgets(self):
        """Immediately remove plugin-owned dock widgets and toolbars."""
        self._remove_owned_dockwidgets()
        self._remove_owned_toolbars()
        self._flush_qt_deferred_deletes()

        self.dockwidget = None
        self.toolbar = None
        self._is_active = False

    def _remove_owned_dockwidgets(self):
        """Remove plugin dock widgets from the QGIS main window."""
        main_window = self.iface.mainWindow()

        docks = list(main_window.findChildren(QDockWidget))
        for dock in docks:
            if not self._is_plugin_dockwidget(dock):
                continue

            try:
                self.iface.removeDockWidget(dock)
            except Exception:
                pass

            try:
                dock.hide()
                dock.close()
                dock.setParent(None)
            except Exception:
                pass

            dock.deleteLater()

    def _remove_owned_toolbars(self):
        """Remove plugin toolbars from the QGIS main window."""
        main_window = self.iface.mainWindow()

        toolbars = list(main_window.findChildren(QToolBar))
        for toolbar in toolbars:
            if not self._is_plugin_toolbar(toolbar):
                continue

            try:
                main_window.removeToolBar(toolbar)
            except Exception:
                pass

            try:
                toolbar.hide()
                toolbar.close()
                toolbar.setParent(None)
            except Exception:
                pass

            toolbar.deleteLater()

    def _is_plugin_dockwidget(self, dock: QDockWidget) -> bool:
        """Return True when the dock belongs to this plugin."""
        return (
            dock is self.dockwidget
            or dock.objectName() == self.DOCK_OBJECT_NAME
            or dock.windowTitle() == self.DOCK_TITLE
        )

    def _is_plugin_toolbar(self, toolbar: QToolBar) -> bool:
        """Return True when the toolbar belongs to this plugin."""
        return (
            toolbar is self.toolbar
            or toolbar.objectName() == self.TOOLBAR_OBJECT_NAME
            or toolbar.windowTitle() == self.TOOLBAR_NAME
        )

    def _flush_qt_deferred_deletes(self):
        """Force Qt to process deleteLater calls before plugin reload checks."""
        app = QApplication.instance()
        if app is None:
            return

        try:
            app.sendPostedEvents(None, QEvent.DeferredDelete)
            app.processEvents()
        except Exception:
            pass

    def _add_dockwidget_to_right_panel(self):
        """Add the dock to the right side and tabify with existing right docks."""
        if self.dockwidget is None:
            return

        main_window = self.iface.mainWindow()
        dock_area = right_dock_area()

        self.dockwidget.setFloating(False)
        self.iface.addDockWidget(dock_area, self.dockwidget)

        try:
            for dock in main_window.findChildren(QDockWidget):
                if dock is self.dockwidget:
                    continue
                if dock.isFloating():
                    continue
                if not dock.isVisible():
                    continue
                if main_window.dockWidgetArea(dock) == dock_area:
                    main_window.tabifyDockWidget(dock, self.dockwidget)
                    self.dockwidget.raise_()
                    break
        except Exception:
            pass

    def _connect_ui(self):
        widget = self.dockwidget
        if widget is None:
            return

        widget.refreshRequested.connect(self.refresh_values)
        widget.generateCutRequested.connect(self.generate_cut_description)
        widget.generateGroupRequested.connect(self.generate_group_description)
        widget.generateContextRequested.connect(self.generate_context_description)
        widget.copyRequested.connect(self.copy_result_to_clipboard)
        widget.clearRequested.connect(widget.clear_result)
        widget.modeChanged.connect(self._on_mode_changed)
        widget.helpRequested.connect(self.open_help)

    def _on_dock_closed(self):
        self._is_active = False

    def _on_mode_changed(self, mode: str):
        if self.dockwidget is not None:
            self.dockwidget.set_status(f"{mode.capitalize()} mode selected.")

    def refresh_values(self):
        """Refresh cut/group/context lists."""
        if self.dockwidget is None:
            return

        self.dockwidget.set_cut_values(self.repository.unique_values("Cut"))
        self.dockwidget.set_group_values(self.repository.unique_values("Group"))
        self.dockwidget.set_context_values(self.repository.unique_values("Context"))

        validation = self.repository.validate_drs_layer()
        self.dockwidget.set_status(
            "Ready." if validation.is_valid else validation.message
        )

    def generate_cut_description(self):
        if self.dockwidget is None:
            return

        cut_value = self.dockwidget.current_cut()
        if not cut_value:
            self.dockwidget.set_status(
                "Choose a cut/context number before generating a description."
            )
            return

        result = self.description_engine.describe_cut(
            cut_value,
            self._description_options(),
        )
        self._show_generation_result(result)

    def generate_group_description(self):
        if self.dockwidget is None:
            return

        group_value = self.dockwidget.current_group()
        if not group_value:
            self.dockwidget.set_status(
                "Choose a group before generating a description."
            )
            return

        result = self.description_engine.describe_group(
            group_value,
            self._description_options(),
        )
        self._show_generation_result(result)

    def generate_context_description(self):
        if self.dockwidget is None:
            return

        context_value = self.dockwidget.current_context()
        if not context_value:
            self.dockwidget.set_status(
                "Choose a context number before generating a description."
            )
            return

        result = self.description_engine.describe_context(
            context_value,
            self._description_options(),
        )
        self._show_generation_result(result)

    def _show_generation_result(self, result):
        if self.dockwidget is None:
            return

        if not result.ok:
            self.dockwidget.set_result("")
            self.dockwidget.set_status(result.message)
            QMessageBox.warning(
                self.iface.mainWindow(),
                "PCA Report Description Generator",
                result.message,
            )
            return

        self.dockwidget.set_result(result.text)
        self.dockwidget.set_status(result.message)

    def copy_result_to_clipboard(self):
        if self.dockwidget is None:
            return

        text = self.dockwidget.result_text()
        if not text.strip():
            self.dockwidget.set_status("There is no text to copy.")
            return

        QCoreApplication.instance().clipboard().setText(text)
        self.dockwidget.set_status("Description copied to clipboard.")

    def _description_options(self) -> DescriptionOptions:
        if self.dockwidget is None:
            return DescriptionOptions()

        return DescriptionOptions(
            include_dimensions=self.dockwidget.include_dimensions(),
            include_uncertainty_placeholders=(
                self.dockwidget.include_uncertainty_placeholders()
            ),
            include_review_notes=self.dockwidget.include_review_notes(),
            use_context_brackets=self.dockwidget.use_context_brackets(),
            use_safe_cut_dimensions=True,
            include_cut_contents_summary=(
                self.dockwidget.include_cut_contents_summary()
            ),
            include_fill_descriptions_in_cut=(
                self.dockwidget.include_fill_descriptions_in_cut()
            ),
        )

    def _connect_selection_signals(self):
        """Connect selection helpers for Interventions and Features_for_PostEx."""
        interventions = self.repository.layer_by_name("Interventions")
        if (
            interventions is not None
            and interventions.id() not in self._selection_layers_connected
        ):
            interventions.selectionChanged.connect(self._sync_cut_from_selection)
            self._selection_layers_connected.add(interventions.id())

        postex = self.repository.layer_by_name("Features_for_PostEx")
        if (
            postex is not None
            and postex.id() not in self._selection_layers_connected
        ):
            postex.selectionChanged.connect(self._sync_group_from_selection)
            self._selection_layers_connected.add(postex.id())

    def _disconnect_selection_signals(self):
        disconnect_targets = [
            (
                self.repository.layer_by_name("Interventions"),
                self._sync_cut_from_selection,
            ),
            (
                self.repository.layer_by_name("Features_for_PostEx"),
                self._sync_group_from_selection,
            ),
        ]

        for layer, handler in disconnect_targets:
            if layer is None:
                continue

            try:
                layer.selectionChanged.disconnect(handler)
            except Exception:
                pass

        self._selection_layers_connected.clear()

    def _sync_cut_from_selection(self, *args):
        if self.dockwidget is None:
            return

        value = self.repository.single_selected_value(
            "Interventions",
            "context_no",
        )

        if value:
            self.dockwidget.set_current_cut(str(value))
            self.dockwidget.set_current_context(str(value))

    def _sync_group_from_selection(self, *args):
        if self.dockwidget is None:
            return

        value = self.repository.single_selected_value(
            "Features_for_PostEx",
            "Group",
        )

        if value:
            self.dockwidget.set_current_group(str(value))

    def _icon(self, filename: str) -> QIcon:
        path = os.path.join(self.plugin_dir, "icons", filename)

        if os.path.exists(path):
            return QIcon(path)

        return QIcon(f":/plugins/pca_report_description/icons/{filename}")

    def open_help(self):
        """Open local help page."""
        help_path = os.path.join(
            self.plugin_dir,
            "help",
            "help.html",
        )

        if os.path.isfile(help_path):
            QDesktopServices.openUrl(
                QUrl.fromLocalFile(os.path.abspath(help_path))
            )
        else:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Help",
                f"Help file not found:\n{help_path}",
            )

    def noop(self):
        pass
