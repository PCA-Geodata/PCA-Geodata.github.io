# -*- coding: utf-8 -*-
"""Compact dock widget for PCA Report Description Generator."""

from __future__ import annotations

import os
from typing import Iterable, List

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDockWidget,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QTabWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .core.text_utils import natural_sort
from .styles.dock_style import DOCK_QSS
from .utils.qt_compat import allowed_side_dock_areas, expanding_size_policy


def _align_center():
    try:
        return Qt.AlignmentFlag.AlignCenter
    except AttributeError:
        return Qt.AlignCenter


def _keep_aspect_ratio():
    try:
        return Qt.AspectRatioMode.KeepAspectRatio
    except AttributeError:
        return Qt.KeepAspectRatio


def _smooth_transformation():
    try:
        return Qt.TransformationMode.SmoothTransformation
    except AttributeError:
        return Qt.SmoothTransformation


class PCAReportDescriptionDockWidget(QDockWidget):
    """Compact dock panel with separate Cut, Group and Context tools."""

    closingPlugin = pyqtSignal()
    refreshRequested = pyqtSignal()
    generateCutRequested = pyqtSignal()
    generateGroupRequested = pyqtSignal()
    generateContextRequested = pyqtSignal()
    copyRequested = pyqtSignal()
    clearRequested = pyqtSignal()
    modeChanged = pyqtSignal(str)
    helpRequested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        self.plugin_dir = os.path.dirname(__file__)

        self.setObjectName("PCAReportDescriptionDockWidget")
        self.setWindowTitle("PCA Report Description")

        self.setMinimumWidth(360)
        self.setAllowedAreas(allowed_side_dock_areas())
        self.setFloating(False)

        self._build_ui()
        self._connect_signals()
        self._apply_style()

    def _apply_style(self):
        self.setStyleSheet(DOCK_QSS)
        if self.widget() is not None:
            self.widget().setStyleSheet(DOCK_QSS)

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def _build_ui(self):
        container = QWidget()
        container.setObjectName("mainContainer")

        root = QVBoxLayout(container)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        root.addWidget(self._build_header())

        self.tabs = QTabWidget()
        self.tabs.setObjectName("modeTabs")

        self.cut_tab = self._build_cut_tab()
        self.group_tab = self._build_group_tab()
        self.context_tab = self._build_context_tab()
        self.settings_tab = self._build_settings_tab()

        self.tabs.addTab(self.cut_tab, "Cut")
        self.tabs.addTab(self.group_tab, "Group")
        self.tabs.addTab(self.context_tab, "Context")
        self.tabs.addTab(self.settings_tab, "Options")
        self.tabs.setUsesScrollButtons(False)

        root.addWidget(self.tabs)

        result_box = QGroupBox("Result")
        result_box.setObjectName("resultBox")

        result_layout = QVBoxLayout(result_box)
        result_layout.setContentsMargins(12, 16, 12, 12)
        result_layout.setSpacing(10)

        self.result_edit = QPlainTextEdit()
        self.result_edit.setObjectName("resultEdit")
        self.result_edit.setPlaceholderText("Generated description will appear here.")
        self.result_edit.setMinimumHeight(190)
        self.result_edit.setSizePolicy(expanding_size_policy(), expanding_size_policy())

        result_layout.addWidget(self.result_edit)

        action_row = QHBoxLayout()
        action_row.setSpacing(8)

        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setObjectName("neutralButton")

        self.copy_btn = QPushButton("Copy")
        self.copy_btn.setObjectName("copyButton")

        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setObjectName("dangerButton")

        action_row.addWidget(self.refresh_btn)
        action_row.addStretch(1)
        action_row.addWidget(self.copy_btn)
        action_row.addWidget(self.clear_btn)

        result_layout.addLayout(action_row)
        root.addWidget(result_box, 1)

        self.status_label = QLabel("● Ready.")
        self.status_label.setObjectName("statusLabel")
        self.status_label.setWordWrap(True)
        root.addWidget(self.status_label)

        self.setWidget(container)

    def _build_header(self) -> QWidget:
        frame = QFrame()
        frame.setObjectName("heroFrame")

        layout = QHBoxLayout(frame)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        icon_label = QLabel()
        icon_label.setObjectName("heroIcon")
        icon_label.setFixedSize(52, 52)
        icon_label.setAlignment(_align_center())

        icon_path = os.path.join(
            self.plugin_dir,
            "icons",
            "PCA_report_generator_icon.png",
        )

        pixmap = QPixmap(icon_path)
        if not pixmap.isNull():
            icon_label.setPixmap(
                pixmap.scaled(
                    48,
                    48,
                    _keep_aspect_ratio(),
                    _smooth_transformation(),
                )
            )
        else:
            icon_label.setText("PCA")

        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(3)

        title = QLabel("PCA Report Description")
        title.setObjectName("titleLabel")

        subtitle = QLabel("Generate archaeological report text from DRS data.")
        subtitle.setObjectName("subtitleLabel")
        subtitle.setWordWrap(True)

        text_layout.addWidget(title)
        text_layout.addWidget(subtitle)

        self.help_btn = QToolButton()
        self.help_btn.setText("Help")
        self.help_btn.setObjectName("helpButton")
        self.help_btn.setToolTip("Open plugin help")
        self.help_btn.setMinimumWidth(64)

        layout.addWidget(icon_label)
        layout.addLayout(text_layout, 1)
        layout.addWidget(self.help_btn)

        return frame

    def _build_cut_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 14, 10, 10)
        layout.setSpacing(10)

        source_box = QGroupBox("Cut source")
        source_box.setObjectName("sourceBox")

        source_layout = QGridLayout(source_box)
        source_layout.setContentsMargins(12, 16, 12, 12)
        source_layout.setHorizontalSpacing(10)
        source_layout.setVerticalSpacing(10)

        self.cut_combo = QComboBox()
        self.cut_combo.setObjectName("cutCombo")
        self.cut_combo.setEditable(True)
        self.cut_combo.setMaxVisibleItems(25)
        self.cut_combo.setPlaceholderText("Select cut / context number...")

        source_layout.addWidget(QLabel("Cut"), 0, 0)
        source_layout.addWidget(self.cut_combo, 0, 1)

        self.generate_cut_btn = QPushButton("Describe cut")
        self.generate_cut_btn.setObjectName("primaryButton")
        source_layout.addWidget(self.generate_cut_btn, 1, 1)

        layout.addWidget(source_box)

        note = QLabel("Creates a draft cut description and summarises recorded contents.")
        note.setObjectName("hintLabel")
        note.setWordWrap(True)
        layout.addWidget(note)

        layout.addStretch(1)
        return tab

    def _build_group_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 14, 10, 10)
        layout.setSpacing(10)

        source_box = QGroupBox("Group source")
        source_box.setObjectName("sourceBox")

        source_layout = QGridLayout(source_box)
        source_layout.setContentsMargins(12, 16, 12, 12)
        source_layout.setHorizontalSpacing(10)
        source_layout.setVerticalSpacing(10)

        self.group_combo = QComboBox()
        self.group_combo.setObjectName("groupCombo")
        self.group_combo.setEditable(True)
        self.group_combo.setMaxVisibleItems(25)
        self.group_combo.setPlaceholderText("Select group...")

        source_layout.addWidget(QLabel("Group"), 0, 0)
        source_layout.addWidget(self.group_combo, 0, 1)

        self.generate_group_btn = QPushButton("Describe group")
        self.generate_group_btn.setObjectName("primaryButton")
        source_layout.addWidget(self.generate_group_btn, 1, 1)

        layout.addWidget(source_box)

        note = QLabel("Creates a draft description from grouped DRS cut records.")
        note.setObjectName("hintLabel")
        note.setWordWrap(True)
        layout.addWidget(note)

        layout.addStretch(1)
        return tab

    def _build_context_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 14, 10, 10)
        layout.setSpacing(10)

        source_box = QGroupBox("Context source")
        source_box.setObjectName("sourceBox")

        source_layout = QGridLayout(source_box)
        source_layout.setContentsMargins(12, 16, 12, 12)
        source_layout.setHorizontalSpacing(10)
        source_layout.setVerticalSpacing(10)

        self.context_combo = QComboBox()
        self.context_combo.setObjectName("contextCombo")
        self.context_combo.setEditable(True)
        self.context_combo.setMaxVisibleItems(25)
        self.context_combo.setPlaceholderText("Select context number...")

        source_layout.addWidget(QLabel("Context"), 0, 0)
        source_layout.addWidget(self.context_combo, 0, 1)

        self.generate_context_btn = QPushButton("Describe context")
        self.generate_context_btn.setObjectName("primaryButton")
        source_layout.addWidget(self.generate_context_btn, 1, 1)

        layout.addWidget(source_box)

        note = QLabel(
            "Creates a dedicated description for any context type, including fill, layer, masonry, skeleton, cremation and structure."
        )
        note.setObjectName("hintLabel")
        note.setWordWrap(True)
        layout.addWidget(note)

        layout.addStretch(1)
        return tab

    def _build_settings_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(12, 14, 12, 12)
        layout.setSpacing(10)

        self.include_dimensions_check = QCheckBox("Include dimensions")
        self.include_dimensions_check.setChecked(True)

        self.placeholder_check = QCheckBox("Use review placeholders")
        self.placeholder_check.setChecked(True)

        self.review_notes_check = QCheckBox("Add review notes")
        self.review_notes_check.setChecked(True)

        self.context_brackets_check = QCheckBox("Use square brackets for cuts")
        self.context_brackets_check.setChecked(True)

        self.cut_contents_summary_check = QCheckBox("Summarise cut contents")
        self.cut_contents_summary_check.setChecked(True)

        self.cut_fill_descriptions_check = QCheckBox(
            "Include associated context descriptions in cut output"
        )
        self.cut_fill_descriptions_check.setChecked(True)

        for widget in (
            self.include_dimensions_check,
            self.placeholder_check,
            self.review_notes_check,
            self.context_brackets_check,
            self.cut_contents_summary_check,
            self.cut_fill_descriptions_check,
        ):
            widget.setObjectName("optionCheck")
            layout.addWidget(widget)

        layout.addStretch(1)
        return tab

    def _connect_signals(self):
        self.refresh_btn.clicked.connect(self.refreshRequested.emit)
        self.generate_cut_btn.clicked.connect(self.generateCutRequested.emit)
        self.generate_group_btn.clicked.connect(self.generateGroupRequested.emit)
        self.generate_context_btn.clicked.connect(self.generateContextRequested.emit)
        self.copy_btn.clicked.connect(self.copyRequested.emit)
        self.clear_btn.clicked.connect(self.clearRequested.emit)
        self.help_btn.clicked.connect(self.helpRequested.emit)
        self.tabs.currentChanged.connect(self._emit_mode_change)

    def _emit_mode_change(self, index: int):
        modes = ["cut", "group", "context", "options"]
        self.modeChanged.emit(modes[index] if 0 <= index < len(modes) else "cut")

    def set_cut_values(self, values: Iterable[str]):
        self._replace_combo_items(self.cut_combo, values)

    def set_group_values(self, values: Iterable[str]):
        self._replace_combo_items(self.group_combo, values)

    def set_context_values(self, values: Iterable[str]):
        self._replace_combo_items(self.context_combo, values)

    def _replace_combo_items(self, combo: QComboBox, values: Iterable[str]):
        current = combo.currentText()
        combo.blockSignals(True)
        combo.clear()

        sorted_values: List[str] = natural_sort(
            [str(v) for v in values if str(v).strip()]
        )

        combo.addItems(sorted_values)
        combo.setCurrentText(current if current in sorted_values else "")
        combo.setEnabled(bool(sorted_values))
        combo.blockSignals(False)

    def current_cut(self) -> str:
        return self.cut_combo.currentText().strip()

    def current_group(self) -> str:
        return self.group_combo.currentText().strip()

    def current_context(self) -> str:
        return self.context_combo.currentText().strip()

    def set_current_cut(self, value: str):
        self.cut_combo.setCurrentText(value)

    def set_current_group(self, value: str):
        self.group_combo.setCurrentText(value)

    def set_current_context(self, value: str):
        self.context_combo.setCurrentText(value)

    def set_result(self, text: str):
        self.result_edit.setPlainText(text)

    def result_text(self) -> str:
        return self.result_edit.toPlainText()

    def clear_result(self):
        self.result_edit.clear()
        self.set_status("● Result cleared.")

    def set_status(self, message: str):
        if message.startswith("●"):
            self.status_label.setText(message)
        else:
            self.status_label.setText(f"● {message}")

    def include_dimensions(self) -> bool:
        return self.include_dimensions_check.isChecked()

    def include_uncertainty_placeholders(self) -> bool:
        return self.placeholder_check.isChecked()

    def include_review_notes(self) -> bool:
        return self.review_notes_check.isChecked()

    def use_context_brackets(self) -> bool:
        return self.context_brackets_check.isChecked()

    def include_cut_contents_summary(self) -> bool:
        return self.cut_contents_summary_check.isChecked()

    def include_fill_descriptions_in_cut(self) -> bool:
        return self.cut_fill_descriptions_check.isChecked()
