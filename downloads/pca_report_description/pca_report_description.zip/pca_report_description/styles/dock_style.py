# -*- coding: utf-8 -*-
"""Stylesheet for PCA Report Description Generator dock widget."""

DOCK_QSS = """
QWidget#mainContainer {
    background-color: #f6f7f7;
    color: #2f3430;
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 10pt;
}

QFrame#heroFrame {
    background-color: #ffffff;
    border: 1px solid #dedede;
    border-radius: 10px;
}

QLabel#heroIcon {
    background-color: transparent;
    border: none;
}

QLabel#titleLabel {
    color: #2f3430;
    font-size: 13pt;
    font-weight: 600;
}

QLabel#subtitleLabel {
    color: #68706a;
    font-size: 9pt;
}

QTabWidget#modeTabs::pane {
    border: none;
    background: transparent;
    margin-top: 6px;
}

QTabBar::tab {
    background: white;
    color: black;
    padding: 7px 12px;
    margin-right: 4px;
    border-radius: 25px 25px 0px 0px;
    border: none;
    width: 65px;
    border-bottom: 2px solid transparent;
}

QTabBar::tab:selected {
    color: black;
    font-weight: 600;
    border-bottom: 2px solid #d94b4b;
    border-radius: 25px 25px 0px 0px;
    background: rgba(201, 67, 67, 50);
}

QTabBar::tab:hover {
    color: #d94b4b;
}

QGroupBox {
    background-color: #ffffff;
    border: 1px solid #dedede;
    border-radius: 9px;
    margin-top: 12px;
    padding-top: 10px;
    font-weight: 600;
    color: #2f3430;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 0 4px;
    background-color: #ffffff;
}

QLabel {
    color: #3e453f;
}

QLabel#hintLabel {
    color: #68706a;
    font-size: 9pt;
    padding-left: 2px;
}

QLabel#statusLabel {
    color: #4f6f55;
    font-size: 9pt;
    padding: 4px 2px 0 2px;
}

QComboBox {
    background-color: #ffffff;
    color: #2f3430;
    border: 1px solid #cfd4d1;
    border-radius: 6px;
    padding: 5px 8px;
    min-height: 24px;
}

QComboBox:hover {
    border: 1px solid #b8bfbb;
}

QComboBox:focus {
    border: 1px solid #d94b4b;
}

QComboBox:disabled {
    background-color: #eeeeee;
    color: #8b908c;
}

QPlainTextEdit#resultEdit {
    background-color: #ffffff;
    color: #2f3430;
    border: 1px solid #cfd4d1;
    border-radius: 8px;
    padding: 8px;
    selection-background-color: #f2c4c4;
    selection-color: #2f3430;
}

QPlainTextEdit#resultEdit:focus {
    border: 1px solid #d94b4b;
}

QPushButton {
    border-radius: 7px;
    padding: 6px 12px;
    min-height: 24px;
    font-weight: 500;
}

QPushButton#primaryButton {
    background-color: #d94b4b;
    color: #ffffff;
    border: 1px solid #d94b4b;
}

QPushButton#primaryButton:hover {
    background-color: #c94343;
    border: 1px solid #c94343;
}

QPushButton#primaryButton:pressed {
    background-color: #b63a3a;
    border: 1px solid #b63a3a;
}

QPushButton#neutralButton,
QPushButton#copyButton {
    background-color: #ffffff;
    color: #2f3430;
    border: 1px solid #cfd4d1;
}

QPushButton#neutralButton:hover,
QPushButton#copyButton:hover {
    background-color: #f0f1f1;
    border: 1px solid #b8bfbb;
}

QPushButton#dangerButton {
    background-color: #ffffff;
    color: #b63a3a;
    border: 1px solid #e2c6c6;
}

QPushButton#dangerButton:hover {
    background-color: #fff4f4;
    border: 1px solid #d94b4b;
}

QCheckBox#optionCheck {
    color: #3e453f;
    spacing: 8px;
    padding: 3px 0;
}

QCheckBox#optionCheck::indicator {
    width: 15px;
    height: 15px;
}

QCheckBox#optionCheck::indicator:unchecked {
    border: 1px solid #b8bfbb;
    background-color: #ffffff;
    border-radius: 3px;
}

QCheckBox#optionCheck::indicator:checked {
    border: 1px solid #d94b4b;
    background-color: #d94b4b;
    border-radius: 3px;
}

QToolButton#helpButton {
    background-color: #ffffff;
    color: #5c625d;
    border: 1px solid #cfd4d1;
    border-radius: 6px;
    padding: 4px 10px;
    font-weight: 500;
    min-height: 24px;
}

QToolButton#helpButton:hover {
    background-color: #f4f4f4;
    border: 1px solid #d94b4b;
    color: #d94b4b;
}

QToolButton#helpButton:pressed {
    background-color: #ececec;
}

"""