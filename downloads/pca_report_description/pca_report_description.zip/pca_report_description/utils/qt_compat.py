# -*- coding: utf-8 -*-
"""Qt compatibility helpers for QGIS 3 / QGIS 4."""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QSizePolicy


def left_dock_area():
    try:
        return Qt.DockWidgetArea.LeftDockWidgetArea
    except AttributeError:
        return Qt.LeftDockWidgetArea


def right_dock_area():
    try:
        return Qt.DockWidgetArea.RightDockWidgetArea
    except AttributeError:
        return Qt.RightDockWidgetArea


def allowed_side_dock_areas():
    return left_dock_area() | right_dock_area()


def expanding_size_policy():
    try:
        return QSizePolicy.Policy.Expanding
    except AttributeError:
        return QSizePolicy.Expanding
