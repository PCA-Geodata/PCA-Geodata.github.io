# -*- coding: utf-8 -*-

import os
import re

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt, QSignalBlocker, QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from qgis.core import (
    NULL,
    QgsExpression,
    QgsFeatureRequest,
    QgsMapLayerProxyModel,
    QgsProject,
    QgsRectangle,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .resources import *
from .search_value_dockwidget import SearchValueDockWidget


class SearchValue:
    """Main plugin class for the Search Value plugin."""

    def __init__(self, iface):
        """
        Plugin constructor.

        Keep the constructor focused on:
        - QGIS interface reference
        - plugin paths
        - translation setup
        - plugin state variables
        - toolbar/menu setup
        - dockwidget creation
        """

        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # ------------------------------------------------------------------
        # Plugin state
        # ------------------------------------------------------------------

        self.pluginIsActive = False
        self.dockwidget = None

        # Internal list of matching feature IDs.
        # This is used by zoom, flash, and previous/next navigation.
        # It avoids relying on the current layer selection as plugin memory.
        self._matching_ids = []

        # Current position inside self._matching_ids for previous/next buttons.
        self.position = 0

        # Stores the layer currently connected to selectionChanged.
        # This avoids leaving old layer signals connected.
        self._selection_layer = None

        # ------------------------------------------------------------------
        # Translation setup
        # ------------------------------------------------------------------

        locale = QSettings().value("locale/userLocale", "")
        locale = locale[0:2] if locale else ""

        locale_path = os.path.join(
            self.plugin_dir,
            "i18n",
            f"SearchValue_{locale}.qm"
        )

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # ------------------------------------------------------------------
        # QGIS menu and toolbar
        # ------------------------------------------------------------------

        self.actions = []
        self.menu = self.tr("&Search Value")

        self.toolbar = self.iface.addToolBar("SearchValue")
        self.toolbar.setObjectName("SearchValue")
        
        # Read plugin version from metadata
        self.plugin_version = self._read_plugin_version()

        # Create the dockwidget once.
        # If later deleted, run() can recreate it.
        self._create_dockwidget()

    def tr(self, message):
        """Translate plugin strings."""
        return QCoreApplication.translate("SearchValue", message)

    # ----------------------------------------------------------------------
    # Dockwidget and signal setup
    # ----------------------------------------------------------------------

    def _create_dockwidget(self):
        """
        Create and initialise the dockwidget.

        Keeping this separate makes the plugin easier to maintain and makes
        recreating the dockwidget safer if needed.
        """

        self.dockwidget = SearchValueDockWidget()

        # Only list layers with geometry.
        self.dockwidget.mMapLayerComboBox.setFilters(
            QgsMapLayerProxyModel.HasGeometry
        )

        # Initial button/message state.
        self.dockwidget.next_pushButton.setVisible(False)
        self.dockwidget.previous_pushButton.setVisible(False)
        self.dockwidget.label_4.setVisible(False)

        self.dockwidget.flash_pushButton.setEnabled(False)
        self.dockwidget.zoom_pushButton.setEnabled(False)
        self.dockwidget.value_comboBox.setEnabled(False)

    def _safe_connect(self, signal, slot):
        """
        Safely connect a Qt signal.

        When the dockwidget is reopened, the same signal can accidentally be
        connected more than once. This helper disconnects first, then reconnects.
        """

        try:
            signal.disconnect(slot)
        except (TypeError, RuntimeError):
            pass

        signal.connect(slot)

    def _connect_dockwidget_signals(self):
        """
        Connect all dockwidget signals in one place.

        This makes it easier to add future buttons or extra functionality.
        """

        self._safe_connect(self.dockwidget.closingPlugin, self.onClosePlugin)

        self._safe_connect(
            self.dockwidget.mMapLayerComboBox.layerChanged,
            self.select_layer_fields
        )

        self._safe_connect(
            self.dockwidget.mFieldComboBox.fieldChanged,
            self.on_field_changed
        )

        self._safe_connect(
            self.dockwidget.value_comboBox.currentTextChanged,
            self.value_changed
        )

        self._safe_connect(
            self.dockwidget.zoom_pushButton.clicked,
            self.zoom_to_value
        )

        self._safe_connect(
            self.dockwidget.flash_pushButton.clicked,
            self.flash_value
        )

        self._safe_connect(
            self.dockwidget.next_pushButton.clicked,
            self.zoom_to_next
        )

        self._safe_connect(
            self.dockwidget.previous_pushButton.clicked,
            self.zoom_to_previous
        )

    # ----------------------------------------------------------------------
    # QGIS GUI integration
    # ----------------------------------------------------------------------

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None,
    ):
        """Add a toolbar/menu action to QGIS."""

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)

        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the plugin toolbar icon and menu entry."""

        icon_path = ":/plugins/search_value/icons/search_value_icon.png"

        self.add_action(
            icon_path,
            text=self.tr(f'Search a value ({self.plugin_version})'),
            callback=self.run,
            parent=self.iface.mainWindow(),
        )
    def unload(self):
        """Unload the plugin cleanly from QGIS."""

        # Disconnect layer selection tracking.
        self._disconnect_selection_layer()

        # Disconnect project-level signal used to refresh widgets after layer removal.
        try:
            QgsProject.instance().layersRemoved.disconnect(self._on_project_layers_removed)
        except (TypeError, RuntimeError):
            pass

        # Remove plugin actions from menu and toolbar.
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)

        self.actions.clear()

        # Remove and delete dockwidget.
        if self.dockwidget is not None:
            try:
                self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
            except (TypeError, RuntimeError):
                pass

            self.iface.removeDockWidget(self.dockwidget)
            self.dockwidget.deleteLater()
            self.dockwidget = None

        # Remove toolbar safely.
        if self.toolbar is not None:
            del self.toolbar
            self.toolbar = None

        self.pluginIsActive = False


    def onClosePlugin(self):
        """
        Called when the dockwidget is closed.

        The dockwidget is not destroyed here. We simply mark the plugin inactive.
        """

        if self.dockwidget is not None:
            try:
                self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
            except (TypeError, RuntimeError):
                pass

        self.pluginIsActive = False

    def _read_plugin_version(self):
        """
        Read plugin version directly from metadata.txt.
        Safe and works in QGIS 3 and QGIS 4.
        """
        metadata_path = os.path.join(self.plugin_dir, 'metadata.txt')

        if not os.path.exists(metadata_path):
            print("metadata.txt not found!")
            return "unknown"

        version = "unknown"

        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.lower().startswith("version="):
                        version = line.split("=", 1)[1].strip()
                        break
        except Exception as e:
            print(f"Could not read metadata.txt: {e}")

        return version


    def run(self):
        """Open and initialise the dockwidget."""

        if self.pluginIsActive:
            self.dockwidget.show()
            self.dockwidget.raise_()
            return

        self.pluginIsActive = True

        if self.dockwidget is None:
            self._create_dockwidget()

        self._connect_dockwidget_signals()

        ##self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dockwidget)
        # QT6
        self.iface.addDockWidget(self._left_dock_area(), self.dockwidget)

        # Reset widgets before applying the active layer.
        self.dockwidget.mMapLayerComboBox.setLayer(None)
        self.dockwidget.mFieldComboBox.setLayer(None)

        active_layer = self.iface.activeLayer()

        if self._is_valid_vector_layer(active_layer):
            self.dockwidget.mMapLayerComboBox.setLayer(active_layer)

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        self._connect_selection_layer(vlayer)
        self.dockwidget.mFieldComboBox.setLayer(vlayer)

        self.dockwidget.show()

    # ----------------------------------------------------------------------
    # Layer and field validation
    # ----------------------------------------------------------------------

    def _is_valid_vector_layer(self, layer):
        """
        Return True if the layer is usable by this plugin.

        Protects against:
        - no active layer
        - layer groups
        - raster/WMS/XYZ layers
        - invalid vector layers
        - geometryless tables
        """

        return (
            isinstance(layer, QgsVectorLayer)
            and layer.isValid()
            and layer.geometryType() != QgsWkbTypes.NullGeometry
        )

    def _disconnect_selection_layer(self):
        """Disconnect selectionChanged from the previously tracked layer."""

        if self._selection_layer is not None:
            try:
                self._selection_layer.selectionChanged.disconnect(self._external_selection_changed)
            except (TypeError, RuntimeError):
                pass

        self._selection_layer = None

    def _connect_selection_layer(self, layer):
        """
        Connect selectionChanged to the currently selected layer only.

        External selection changes should clear the internal navigation state,
        because the user has changed the map selection manually.
        """

        self._disconnect_selection_layer()

        if self._is_valid_vector_layer(layer):
            layer.selectionChanged.connect(self._external_selection_changed)
            self._selection_layer = layer

    def _external_selection_changed(self, *args):
        """
        Called when the layer selection changes outside this plugin.

        The plugin keeps its own matching IDs, so an external selection change
        should reset previous/next navigation.
        """

        self._matching_ids = []
        self.position = 0
        self._hide_navigation_controls()

    # ----------------------------------------------------------------------
    # Layer / field / value UI logic
    # ----------------------------------------------------------------------

    def select_layer_fields(self, vlayer):
        """
        Called when the selected layer changes.

        Sets the field combo box layer and tries to choose a useful default
        field based on common PCA/DRS field names.
        """

        self.dockwidget.mFieldComboBox.setLayer(vlayer)
        self._connect_selection_layer(vlayer)

        self._reset_search_ui(clear_values=True)

        if not self._is_valid_vector_layer(vlayer):
            return

        field_names = [field.name() for field in vlayer.fields()]

        preferred_fields = [
            "section_no",
            "context_no",
            "drawing_no",
            "sf_no",
            "sample_no",
            "targ_name",
        ]

        for field_name in preferred_fields:
            if field_name in field_names:
                self.dockwidget.mFieldComboBox.setField(field_name)
                break

        vfield = self.dockwidget.mFieldComboBox.currentField()
        self.on_field_changed(vfield)

    def on_field_changed(self, vfield):
        """
        Called when the selected field changes.

        Fills the value combo box with unique values from the selected field.

        uniqueValues() is more efficient than looping manually through every
        feature, especially on larger layers.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        self._reset_search_ui(clear_values=True)

        if not self._is_valid_vector_layer(vlayer):
            return

        if not vfield:
            return

        field_index = vlayer.fields().indexFromName(vfield)

        if field_index == -1:
            return

        raw_values = vlayer.uniqueValues(field_index)

        values = []

        for raw_value in raw_values:
            if raw_value is None or raw_value == NULL:
                continue

            display_value = str(raw_value)

            if display_value.strip() == "":
                continue

            # Store the display value and original raw value.
            # This prevents numeric fields being searched as strings.
            values.append((display_value, raw_value))

        if not values:
            return

        sorted_values = sorted(
            values,
            key=lambda item: self._natural_sort_key(item[0])
        )

        self.dockwidget.value_comboBox.setEnabled(True)

        # Block signals while populating the combo box.
        with QSignalBlocker(self.dockwidget.value_comboBox):
            for display_value, raw_value in sorted_values:
                self.dockwidget.value_comboBox.addItem(display_value, raw_value)

            self.dockwidget.value_comboBox.setCurrentIndex(-1)
            
    def value_changed(self):
        """
        Enable action buttons when a valid value is selected or typed manually.

        currentIndex() only works when the value comes from the dropdown.
        If the user types a value manually, currentIndex() can remain -1,
        so currentText() is the safer check.
        """

        value_text = self.dockwidget.value_comboBox.currentText().strip()
        has_value = value_text != ""

        self.dockwidget.zoom_pushButton.setEnabled(has_value)
        self.dockwidget.flash_pushButton.setEnabled(has_value)

        self._matching_ids = []
        self.position = 0
        self._hide_navigation_controls()

    def _refresh_layer_widgets_after_layer_removal(self):
        """
        Refresh layer-dependent widgets after a project layer has been removed.
        """

        if self.dockwidget is None:
            return

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        self._disconnect_selection_layer()
        self.dockwidget.mFieldComboBox.setLayer(None)
        self._reset_search_ui(clear_values=True)

        if not self._is_valid_vector_layer(vlayer):
            return

        self.dockwidget.mFieldComboBox.setLayer(vlayer)
        self._connect_selection_layer(vlayer)

        # Reapply default field logic and reload values.
        self.select_layer_fields(vlayer)


    def _on_project_layers_removed(self, layer_ids):
        """
        Called when one or more layers are removed from the project.

        QgsMapLayerComboBox updates itself automatically, but the field combo box
        and value list may not always refresh reliably after the current layer is
        removed. Use QTimer.singleShot(0, ...) so this runs after QGIS has finished
        updating the layer combo box internally.
        """

        QTimer.singleShot(0, self._refresh_layer_widgets_after_layer_removal)


    # ----------------------------------------------------------------------
    # Sorting and expression helpers
    # ----------------------------------------------------------------------

    def _natural_sort_key(self, text):
        """
        Natural sort key.

        Sorts like:
        1, 2, 3, 10

        instead of:
        1, 10, 2, 3
        """

        return [
            int(part) if part.isdigit() else part.lower()
            for part in re.split(r"([0-9]+)", text)
        ]

    def _build_expression(self):
        """
        Build a safe QGIS expression for the selected field/value.

        Supports both:
        - values selected from the dropdown, using currentData()
        - values typed manually by the user, using currentText()
        """

        vfield = self.dockwidget.mFieldComboBox.currentField()

        if not vfield:
            return None

        raw_value = self.dockwidget.value_comboBox.currentData()
        typed_value = self.dockwidget.value_comboBox.currentText().strip()

        if raw_value is None:
            if typed_value == "":
                return None

            raw_value = typed_value

        field_expr = QgsExpression.quotedColumnRef(vfield)
        value_expr = QgsExpression.quotedValue(raw_value)

        return f"{field_expr} = {value_expr}"

    def _matching_feature_ids(self):
        """
        Return feature IDs matching the selected field/value.

        This is the central search method used by:
        - zoom
        - flash
        - future select button
        - future export/copy functionality

        It does not change the layer selection.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not self._is_valid_vector_layer(vlayer):
            return []

        expression = self._build_expression()

        if not expression:
            return []

        request = QgsFeatureRequest()
        request.setFilterExpression(expression)
        request.setNoAttributes()

        return [feature.id() for feature in vlayer.getFeatures(request)]

    # ----------------------------------------------------------------------
    # UI state helpers
    # ----------------------------------------------------------------------

    def _reset_search_ui(self, clear_values=False):
        """
        Reset the search-related UI.

        Used when:
        - layer changes
        - field changes
        - invalid layer is selected
        """

        self._matching_ids = []
        self.position = 0

        if clear_values:
            with QSignalBlocker(self.dockwidget.value_comboBox):
                self.dockwidget.value_comboBox.clear()

        self.dockwidget.value_comboBox.setEnabled(False)
        self.dockwidget.zoom_pushButton.setEnabled(False)
        self.dockwidget.flash_pushButton.setEnabled(False)

        self._hide_navigation_controls()
        self._clear_status_message()

    def _hide_navigation_controls(self):
        """Hide Previous/Next navigation controls."""

        self.dockwidget.next_pushButton.setVisible(False)
        self.dockwidget.previous_pushButton.setVisible(False)

    def _show_navigation_controls(self):
        """Show Previous/Next navigation controls."""

        self.dockwidget.next_pushButton.setVisible(True)
        self.dockwidget.previous_pushButton.setVisible(True)

    def _clear_status_message(self):
        """Clear and hide the status label."""

        self.dockwidget.label_4.setText("")
        self.dockwidget.label_4.setStyleSheet("")
        self.dockwidget.label_4.setVisible(False)
        
    def _set_status_message(self, text, status="info"):
        label = self.dockwidget.label_4
        label.setText(text)
        label.setProperty("status", status)
        label.style().unpolish(label)
        label.style().polish(label)
        label.setVisible(True)

    # ----------------------------------------------------------------------
    # Search actions
    # ----------------------------------------------------------------------

    def flash_value(self):
        """
        Select and flash matching features on the map canvas.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not self._is_valid_vector_layer(vlayer):
            return

        ids = self._matching_feature_ids()

        if not ids:
            self._set_status_message("No object with this value", "error")
            self._matching_ids = []
            self.position = 0
            self._hide_navigation_controls()
            vlayer.removeSelection()
            return

        self._matching_ids = ids
        self.position = 0

        self._select_matching_ids(ids)
        self.iface.mapCanvas().flashFeatureIds(vlayer, ids)

        if len(ids) == 1:
            self._set_status_message("1 object with this value", "info")
        else:
            self._set_status_message(f"{len(ids)} objects with this value", "info")

    def zoom_to_value(self):
        """
        Find, select, and zoom to matching features.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not self._is_valid_vector_layer(vlayer):
            return

        ids = self._matching_feature_ids()

        self._matching_ids = ids
        self.position = 0

        if not ids:
            self._set_status_message("No object with this value", "error")
            self._hide_navigation_controls()
            vlayer.removeSelection()
            return

        self._select_matching_ids(ids)

        if len(ids) == 1:
            self._clear_status_message()
            self._hide_navigation_controls()
            self._zoom_to_feature_id(ids[0])
            return

        self._set_status_message(f"{len(ids)} objects with this value", "info")
        self._show_navigation_controls()
        self._zoom_to_feature_ids(ids)

    # ----------------------------------------------------------------------
    # Map zoom helpers
    # ----------------------------------------------------------------------

    def _zoom_to_feature_id(self, fid):
        """
        Zoom to a single feature by feature ID.

        Uses QgsFeatureRequest().setFilterFid() to retrieve only one feature.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not self._is_valid_vector_layer(vlayer):
            return

        request = QgsFeatureRequest()
        request.setFilterFid(fid)
        request.setNoAttributes()

        for feature in vlayer.getFeatures(request):
            geometry = feature.geometry()

            if geometry is None or geometry.isEmpty():
                return

            box = geometry.boundingBox()

            if box.isNull():
                return

            self.iface.mapCanvas().setExtent(box.buffered(0.3))
            self.iface.mapCanvas().refresh()
            return

    def _zoom_to_feature_ids(self, ids):
        """
        Zoom to the combined extent of several feature IDs.

        This avoids selecting features just to calculate the extent.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not self._is_valid_vector_layer(vlayer):
            return

        if not ids:
            return

        request = QgsFeatureRequest()
        request.setFilterFids(ids)
        request.setNoAttributes()

        extent = QgsRectangle()
        extent.setMinimal()

        found_geometry = False

        for feature in vlayer.getFeatures(request):
            geometry = feature.geometry()

            if geometry is None or geometry.isEmpty():
                continue

            box = geometry.boundingBox()

            if box.isNull():
                continue

            extent.combineExtentWith(box)
            found_geometry = True

        if not found_geometry or extent.isNull():
            return

        self.iface.mapCanvas().setExtent(extent.buffered(0.3))
        self.iface.mapCanvas().refresh()

    # ----------------------------------------------------------------------
    # Previous / Next navigation
    # ----------------------------------------------------------------------

    def zoom_to_next(self):
        """
        Zoom to the next matching feature.

        Uses self._matching_ids instead of layer.selectedFeatures().
        """

        if not self._matching_ids:
            return

        self.position += 1

        if self.position >= len(self._matching_ids):
            self.position = 0

        self._zoom_to_feature_id(self._matching_ids[self.position])

    def zoom_to_previous(self):
        """
        Zoom to the previous matching feature.

        Uses self._matching_ids instead of layer.selectedFeatures().
        """

        if not self._matching_ids:
            return

        self.position -= 1

        if self.position < 0:
            self.position = len(self._matching_ids) - 1

        self._zoom_to_feature_id(self._matching_ids[self.position])

    def _left_dock_area(self):
        """Return correct LeftDockWidgetArea for Qt5 / Qt6."""
        try:
            return Qt.LeftDockWidgetArea
        except AttributeError:
            return Qt.DockWidgetArea.LeftDockWidgetArea
            
            
    def _select_matching_ids(self, ids):
        """
        Select matching features in the layer.

        This makes the result visible in the attribute table and in the map canvas.
        """

        vlayer = self.dockwidget.mMapLayerComboBox.currentLayer()

        if not self._is_valid_vector_layer(vlayer):
            return

        if not ids:
            vlayer.removeSelection()
            return

        vlayer.selectByIds(ids)